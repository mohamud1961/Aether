# Aether-Next Harness Evaluation Report

Source commit: ``
Source tree: ``
Source clean at start: `False`

| Case | Layer | Required | Status | Duration | Scorecard |
|---|---|---:|---|---:|---|
| provider_protocol | component | true | passed | 3.715s | P1, P2, P3 |
| solver_causal_loop | component | true | passed | 0.946s | S1, S2, S3, W3 |
| architect_ir_compiler | component | true | passed | 1.085s | R1, R2, R3, A1 |
| evidence_proof_completion | component | true | passed | 0.872s | E1, E2, E3, C1, V1 |
| verifier_findings_ownership | component | true | passed | 1.225s | V1, V2, V3, X3 |
| workspace_process_service_truth | component | true | passed | 1.808s | W1, W2, W3 |
| security_isolation_provenance | component | true | passed | 0.888s | X1, X2, X3, G1, G2, G3 |
| context_output_retention | component | true | passed | 2.879s | O1, O2, S2 |
| architecture_purity | component | true | passed | 0.301s | A1, A2 |
| context_growth_probe | component | true | passed | 0.017s | O1, O2 |
| official_task_board_integrity | task_corpus | true | passed | 0.000s | T1 |
| archetype_matrix_coverage | task_corpus | true | passed | 0.001s | T1 |
| scorecard_eval_coverage | meta | true | passed | 0.000s | T1 |
| deterministic_system_scenarios | system | true | passed | 0.022s | S1, S2, S3, R1, R2, E1, E2, C1, V1, V2, V3, W1, T1 |
| official_archetype_system_contracts | system | true | passed | 4.083s | S1, S2, E1, E2, C1, V1, W1, W2, X1, O1, T1 |
| known_bad_replay | system | true | passed | 2.855s | C1, V1, V2, V3, T1 |
| canonical_current_suite | system | true | passed | 22.228s | T1, T2 |

## Verdict

**DETERMINISTIC GATES PASS for the selected manifest scope.** Model and VM plans remain separate gates.
