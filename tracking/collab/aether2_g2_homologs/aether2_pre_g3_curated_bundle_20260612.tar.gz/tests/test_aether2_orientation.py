from __future__ import annotations

from dataclasses import dataclass

from runner.aether2.orientation import NETWORK_PROBE_COMMANDS, OrientationSnapshot, orient


@dataclass
class FakeResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


class FakeExecutor:
    def __init__(self, mapping: dict[str, FakeResult | str]) -> None:
        self.mapping = mapping
        self.calls: list[str] = []

    def run(self, cmd: str, timeout_sec: int = 10, cwd: str | None = None) -> FakeResult | str:
        self.calls.append(cmd)
        result = self.mapping.get(cmd)
        if result is not None:
            return result
        return FakeResult(stderr="command not found", exit_code=1)


def _build_reachable_executor() -> FakeExecutor:
    return FakeExecutor(
        {
            "pwd": FakeResult(stdout="/work/subdir"),
            "id -un": FakeResult(stdout="builder"),
            "id -u": FakeResult(stdout="1000"),
            "git rev-parse --show-toplevel": FakeResult(stdout="/work"),
            'sh -lc \'[ -w "$PWD" ] && printf writable || printf read-only\'': FakeResult(stdout="writable"),
            'python3 -c "import os; print(\'\\n\'.join(sorted(os.listdir(\'.\'))[:40]))"': FakeResult(
                stdout="alpha.txt\nbeta.txt"
            ),
            "command -v git": FakeResult(stdout="/usr/bin/git"),
            "command -v curl": FakeResult(stdout="/usr/bin/curl"),
            "command -v python3": FakeResult(stdout="/usr/bin/python3"),
            "command -v gcc": FakeResult(stdout="/usr/bin/gcc"),
            "command -v make": FakeResult(stdout="/usr/bin/make"),
            "command -v tmux": FakeResult(stdout="/usr/bin/tmux"),
            "command -v node": FakeResult(stdout="/usr/bin/node"),
            "command -v npm": FakeResult(stdout="/usr/bin/npm"),
            "command -v pip": FakeResult(stdout="/usr/bin/pip"),
            "pip --version": FakeResult(stdout="pip 24.0"),
            "python3 -m pip --version": FakeResult(stdout="pip 24.0"),
            "python3 --version": FakeResult(stdout="Python 3.14.2"),
            "python --version": FakeResult(stdout="Python 3.11.0"),
            "node --version": FakeResult(stdout="v22.0.0"),
            "npm --version": FakeResult(stdout="10.0.0"),
            "ps -eo comm= | head -n 20": FakeResult(stdout="python\nbash\ntmux"),
            "ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null || true": FakeResult(
                stdout="State Recv-Q Send-Q Local Address:Port Peer Address:Port"
            ),
            NETWORK_PROBE_COMMANDS[0][0]: FakeResult(stdout="reachable: pypi.org:443"),
        }
    )


def _build_blocked_executor() -> FakeExecutor:
    return FakeExecutor(
        {
            "pwd": FakeResult(stdout="/work/subdir"),
            "id -un": FakeResult(stdout="builder"),
            "id -u": FakeResult(stdout="0"),
            "git rev-parse --show-toplevel": FakeResult(stdout="/work"),
            'sh -lc \'[ -w "$PWD" ] && printf writable || printf read-only\'': FakeResult(stdout="read-only"),
            "command -v git": FakeResult(stdout="/usr/bin/git"),
            "command -v curl": FakeResult(stdout="/usr/bin/curl"),
            "command -v python3": FakeResult(stdout="/usr/bin/python3"),
            "command -v gcc": FakeResult(stdout="/usr/bin/gcc"),
            "command -v make": FakeResult(stdout="/usr/bin/make"),
            "command -v tmux": FakeResult(stdout="/usr/bin/tmux"),
            "command -v node": FakeResult(stdout="/usr/bin/node"),
            "command -v npm": FakeResult(stdout="/usr/bin/npm"),
            "command -v pip": FakeResult(stdout="/usr/bin/pip"),
            "pip --version": FakeResult(stdout="pip 24.0"),
            "python3 -m pip --version": FakeResult(stdout="pip 24.0"),
            "python3 --version": FakeResult(stdout="Python 3.14.2"),
            "python --version": FakeResult(stdout="Python 3.11.0"),
            "node --version": FakeResult(stdout="v22.0.0"),
            "npm --version": FakeResult(stdout="10.0.0"),
            "ps -eo comm= | head -n 20": FakeResult(stdout="python\nbash"),
            "ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null || true": FakeResult(stdout=""),
            NETWORK_PROBE_COMMANDS[0][0]: FakeResult(stderr="blocked: timeout", exit_code=1),
        }
    )


def test_orient_probes_facts_and_never_uses_unknown_network() -> None:
    executor = _build_reachable_executor()

    snapshot = orient(executor)

    assert isinstance(snapshot, OrientationSnapshot)
    assert snapshot.cwd == "/work/subdir"
    assert snapshot.workspace_root == "/work"
    assert snapshot.user == "builder"
    assert snapshot.is_root is False
    assert snapshot.network != "unknown"
    assert snapshot.network == "reachable"
    assert snapshot.network_reachable is True
    assert snapshot.network_evidence == "reachable: pypi.org:443"
    assert snapshot.safe_file_listing == ["alpha.txt", "beta.txt"]
    assert snapshot.writable_paths == ["/work/subdir", "/work"]
    assert snapshot.package_managers == {
        "apt": "missing",
        "pip": "/usr/bin/pip",
        "npm": "/usr/bin/npm",
        "uv": "missing",
    }
    assert snapshot.tool_presence == {
        "git": "/usr/bin/git",
        "curl": "/usr/bin/curl",
        "python3": "/usr/bin/python3",
        "gcc": "/usr/bin/gcc",
        "make": "/usr/bin/make",
        "tmux": "/usr/bin/tmux",
        "node": "/usr/bin/node",
        "npm": "/usr/bin/npm",
        "uv": "missing",
        "pip": "/usr/bin/pip",
    }
    assert snapshot.runtimes == {
        "python3": "Python 3.14.2",
        "python": "Python 3.11.0",
        "node": "v22.0.0",
        "npm": "10.0.0",
    }
    assert "task" not in snapshot.as_dict()
    assert "difficulty" not in snapshot.as_dict()
    assert "category" not in snapshot.as_dict()
    assert "tags" not in snapshot.as_dict()


def test_orient_payload_has_no_task_metadata_keys_and_handles_missing_tools() -> None:
    executor = _build_blocked_executor()

    snapshot = orient(executor)
    payload = snapshot.as_dict()

    assert snapshot.network != "unknown"
    assert snapshot.network == "blocked"
    assert snapshot.network_reachable is False
    assert snapshot.network_evidence == "blocked: timeout"
    assert snapshot.is_root is True
    assert snapshot.package_managers["uv"] == "missing"
    assert snapshot.tool_presence["uv"] == "missing"
    assert "task" not in payload
    assert "difficulty" not in payload
    assert "category" not in payload
    assert "tags" not in payload
    assert set(payload) == {
        "cwd",
        "user",
        "is_root",
        "workspace_root",
        "writable_paths",
        "safe_file_listing",
        "tool_presence",
        "package_managers",
        "network",
        "network_reachable",
        "network_evidence",
        "runtimes",
        "processes",
        "ports",
    }


def test_orientation_module_has_generic_one_sentence_description() -> None:
    assert orient.__module__ == "runner.aether2.orientation"
    from runner.aether2 import orientation as orientation_module

    assert orientation_module.__doc__ is not None
    assert orientation_module.__doc__.strip() == (
        "Probe the local workspace and runtime into a compact, factual snapshot."
    )
