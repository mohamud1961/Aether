import json
from types import SimpleNamespace

from runner.aether2.verify import DiscrepancyReport, RequirementResult, replay_checks, verify_fresh_context


class FakeExecutor:
    def __init__(self) -> None:
        self.commands: list[str] = []

    def run(self, cmd, timeout_sec, cwd):
        self.commands.append(cmd)
        return SimpleNamespace(
            exit_code=0,
            stdout=f"ran {cmd}",
            stderr="",
            cwd=cwd or "/tmp/work",
            duration_sec=0.2,
        )


class FakeModelClient:
    def __init__(self) -> None:
        self.messages = None

    def call(self, messages, tools, *, cache_prefix_len):
        self.messages = messages
        assert tools == []
        assert cache_prefix_len == 0
        return {
            "output_text": json.dumps(
                {
                    "requirements": [
                        {
                            "requirement": "artifact exists",
                            "verdict": "satisfied",
                            "evidence": "artifact.txt present",
                        },
                        {
                            "requirement": "service alive",
                            "verdict": "unverifiable",
                            "evidence": "no service evidence",
                        },
                    ],
                    "reason_codes": ["service_unverifiable"],
                    "summary": "Artifact looks good; service evidence is missing.",
                }
            )
        }


def test_replay_checks_replays_commands_through_executor() -> None:
    executor = FakeExecutor()

    results = replay_checks(["pwd", "ls"], executor)

    assert executor.commands == ["pwd", "ls"]
    assert results[0].command == "pwd"
    assert results[1].stdout == "ran ls"


def test_replay_checks_preserves_timeout_and_error_truthfulness() -> None:
    class TruthfulExecutor:
        def __init__(self) -> None:
            self.calls = 0

        def run(self, cmd, timeout_sec, cwd):
            self.calls += 1
            if self.calls == 1:
                return SimpleNamespace(
                    exit_code=1,
                    stdout="",
                    stderr="failed",
                    cwd="/tmp/work",
                    duration_sec=0.1,
                    timed_out=False,
                    error=SimpleNamespace(kind="nonzero_exit", reason_code="nonzero_exit"),
                )
            return SimpleNamespace(
                exit_code=124,
                stdout="",
                stderr="",
                cwd="/tmp/work",
                duration_sec=1.0,
                timed_out=True,
                error=SimpleNamespace(kind="timeout", reason_code="timeout"),
            )

    results = replay_checks(["false", "sleep 5"], TruthfulExecutor())

    assert results[0].exit_code == 1
    assert results[0].timed_out is False
    assert results[0].error_kind == "nonzero_exit"
    assert results[0].error_reason_code == "nonzero_exit"
    assert results[1].exit_code == 124
    assert results[1].timed_out is True
    assert results[1].error_kind == "timeout"
    assert results[1].error_reason_code == "timeout"


def test_verify_fresh_context_cleans_hidden_refs_and_avoids_transcript_injection() -> None:
    model_client = FakeModelClient()
    report = verify_fresh_context(
        task="complete the task",
        orientation={
            "cwd": "/tmp/work",
            "hidden_answer": "secret",
            "details": {
                "artifact": "artifact.txt",
                "transcript": "orientation transcript should not leak",
            },
        },
        diff={
            "artifact.txt": "sha",
            "grader_secret": "nope",
            "details": {
                "status": "clean",
                "transcript": "diff transcript should not leak",
            },
        },
        claim={
            "summary": "done",
            "expected_output": "hidden",
            "details": {
                "summary": "visible",
                "transcript": "claim transcript should not leak",
            },
        },
        checks_results=[
            SimpleNamespace(
                command="pwd",
                exit_code=0,
                stdout="ok",
                stderr="",
                cwd="/tmp/work",
                duration_sec=0.1,
                hidden_answer="check-secret",
                transcript="executor transcript should not leak",
                metadata={
                    "visible": "ok",
                    "transcript": "check transcript should not leak",
                },
            )
        ],
        action_digest={
            "commands": ["ls"],
            "full_transcript": "should stay out",
            "trail": {
                "visible": "yes",
                "nested_transcript": "digest transcript should not leak",
            },
        },
        model_client=model_client,
    )

    assert report.summary == "Artifact looks good; service evidence is missing."
    assert report.reason_codes == ("service_unverifiable",)
    assert report.requirements[0].verdict == "satisfied"
    payload = json.loads(model_client.messages[1]["content"])
    assert "hidden_answer" not in json.dumps(payload)
    assert "grader_secret" not in json.dumps(payload)
    assert "expected_output" not in json.dumps(payload)
    assert "check-secret" not in json.dumps(payload)
    assert "executor transcript should not leak" not in json.dumps(payload)
    assert "orientation transcript should not leak" not in json.dumps(payload)
    assert "diff transcript should not leak" not in json.dumps(payload)
    assert "claim transcript should not leak" not in json.dumps(payload)
    assert "check transcript should not leak" not in json.dumps(payload)
    assert "digest transcript should not leak" not in json.dumps(payload)
    assert '"full_transcript"' not in model_client.messages[1]["content"]
    assert "full_transcript" not in payload["action_digest"]
    assert payload["orientation"]["details"] == {"artifact": "artifact.txt"}
    assert payload["workspace_diff"]["details"] == {"status": "clean"}
    assert payload["claim"]["details"] == {"summary": "visible"}
    assert payload["checks_results"][0]["metadata"] == {"visible": "ok"}
    assert payload["action_digest"]["trail"] == {"visible": "yes"}


def test_verify_fresh_context_validates_report_schema() -> None:
    class BadModelClient:
        def call(self, messages, tools, *, cache_prefix_len):
            return {"output_text": '{"oops": true}'}

    report = verify_fresh_context(
        task="task",
        orientation={},
        diff={},
        claim={"summary": "done"},
        checks_results=[],
        action_digest={},
        model_client=BadModelClient(),
    )

    assert report.reason_codes == ("verifier_parse_failed",)
    assert report.requirements[0].requirement == "verification_output_parse"
    assert report.requirements[0].verdict == "unverifiable"
    assert report.has_discrepancies is True
    assert report.summary == "Verifier output could not be parsed."


def test_has_discrepancies_ignores_unverifiable_but_not_unsatisfied() -> None:
    # All-satisfied + unverifiable: not a discrepancy (G2 fix-round-5: the
    # advisory verifier frequently cannot confirm interactive-session/job
    # internals it has no transcript access to; that must not block
    # finalization on tasks that are otherwise correct).
    report = DiscrepancyReport(
        requirements=(
            RequirementResult(requirement="r1", verdict="satisfied", evidence="e1"),
            RequirementResult(requirement="r2", verdict="unverifiable", evidence="e2"),
        ),
        reason_codes=(),
        summary="mostly fine",
        raw_response="{}",
    )
    assert report.has_discrepancies is False

    # A genuinely unsatisfied requirement IS a discrepancy.
    report_bad = DiscrepancyReport(
        requirements=(
            RequirementResult(requirement="r1", verdict="satisfied", evidence="e1"),
            RequirementResult(requirement="r2", verdict="unsatisfied", evidence="e2"),
        ),
        reason_codes=(),
        summary="something wrong",
        raw_response="{}",
    )
    assert report_bad.has_discrepancies is True

    # A schema/parse failure (reason_codes contains verifier_parse_failed)
    # still counts as a discrepancy even if the fallback requirement is
    # only "unverifiable".
    report_parse_failed = DiscrepancyReport(
        requirements=(
            RequirementResult(requirement="verification_output_parse", verdict="unverifiable", evidence="e"),
        ),
        reason_codes=("verifier_parse_failed",),
        summary="could not parse",
        raw_response="{}",
    )
    assert report_parse_failed.has_discrepancies is True
