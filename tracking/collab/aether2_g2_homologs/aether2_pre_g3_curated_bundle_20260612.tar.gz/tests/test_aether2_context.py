from runner.aether2.context import ContextManager


def test_prefix_bytes_stay_identical_across_appends() -> None:
    context = ContextManager()
    prefix = context.build_prefix(
        system_prompt="system",
        task_instruction="do the thing",
        orientation={"cwd": "/tmp/work"},
        tool_schemas=[{"function": {"name": "run_command"}}],
    )

    context.append_turn({"role": "assistant", "content": "plan"})
    context.append_turn({"role": "tool", "content": "ok", "name": "run_command"})
    context.assert_prefix_unchanged()

    assert prefix.frozen_bytes == context.prefix.frozen_bytes


def test_tail_only_rerenders_on_change() -> None:
    context = ContextManager()
    context.build_prefix(
        system_prompt="system",
        task_instruction="task",
        orientation={"cwd": "/tmp/work"},
        tool_schemas=[],
    )

    first = context.render_tail({"plan": "inspect", "streak": 0})
    second = context.render_tail({"plan": "inspect", "streak": 0})
    third = context.render_tail({"plan": "edit", "streak": 1})

    assert first == second
    assert third != second


def test_tail_render_is_stable_for_semantically_equal_payloads() -> None:
    context = ContextManager()
    context.build_prefix(
        system_prompt="system",
        task_instruction="task",
        orientation={"cwd": "/tmp/work"},
        tool_schemas=[],
    )

    first = context.render_tail({"plan": "inspect", "streak": 0, "fuel": {"elapsed": 1, "remaining": 2}})
    second = context.render_tail({"fuel": {"remaining": 2, "elapsed": 1}, "streak": 0, "plan": "inspect"})

    assert first == second


def test_prefix_token_estimate_stays_under_8k_for_synthetic_start_state() -> None:
    context = ContextManager()
    prefix = context.build_prefix(
        system_prompt="system " * 400,
        task_instruction="task " * 1200,
        orientation={"cwd": "/tmp/work", "listing": ["a", "b", "c"]},
        tool_schemas=[{"function": {"name": f"tool_{idx}"}} for idx in range(10)],
    )

    assert prefix.token_estimate <= 8000


def test_message_history_preserves_assistant_tool_calls() -> None:
    context = ContextManager()
    context.build_prefix(
        system_prompt="system",
        task_instruction="task",
        orientation={"cwd": "/tmp/work"},
        tool_schemas=[],
    )

    context.append_turn(
        {
            "role": "assistant",
            "content": "",
            "tool_calls": [{"id": "call-1", "name": "run_command", "arguments": "{\"cmd\":\"pwd\"}"}],
        }
    )

    history = context.message_history()
    assert history[-1]["tool_calls"][0]["name"] == "run_command"
    assert history[-1]["tool_calls"][0]["arguments"] == "{\"cmd\":\"pwd\"}"
