from __future__ import annotations

from runner.aether2.delta import DeltaReport, FileDelta, diff, snapshot


def test_snapshot_and_diff_detect_file_modification(tmp_path):
    target = tmp_path / "artifact.txt"
    target.write_text("alpha\n", encoding="utf-8")

    before = snapshot(tmp_path)

    target.write_text("beta\n", encoding="utf-8")

    after = snapshot(tmp_path)
    report = diff(before, after)

    assert isinstance(report, DeltaReport)
    assert report.files_changed == [
        FileDelta(
            path="artifact.txt",
            hash_before=before.files["artifact.txt"],
            hash_after=after.files["artifact.txt"],
            change_type="modified",
        )
    ]
    assert report.modified_paths == ("artifact.txt",)
    assert report.added_paths == ()
    assert report.deleted_paths == ()
    assert report.is_empty is False


def test_snapshot_and_diff_report_no_op_as_empty(tmp_path):
    (tmp_path / "nested").mkdir()
    (tmp_path / "nested" / "note.txt").write_text("steady state\n", encoding="utf-8")

    before = snapshot(tmp_path)
    after = snapshot(tmp_path)
    report = diff(before, after)

    assert report.files_changed == []
    assert report.added_paths == ()
    assert report.modified_paths == ()
    assert report.deleted_paths == ()
    assert report.is_empty is True
