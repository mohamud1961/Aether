from runner.aether2.prompts import DOCTRINE_LINES, SYSTEM_PROMPT


def test_prompt_exports_doctrine_lines_verbatim() -> None:
    assert len(DOCTRINE_LINES) == 2
    assert (
        "Missing tools can usually be installed (apt/pip/npm); prefer installing or bootstrapping over abandoning."
        in DOCTRINE_LINES
    )
    assert (
        "A request for a brief written plan before acting — the plan is **model-owned and model-updatable** (it lives in the tail telemetry, §6.3, and the model edits it whenever it wants)."
        in DOCTRINE_LINES
    )
    for line in DOCTRINE_LINES:
        assert line in SYSTEM_PROMPT


def test_system_prompt_contains_aether2_role_boundaries() -> None:
    assert "The model pilots." in SYSTEM_PROMPT
    assert "The harness instruments." in SYSTEM_PROMPT
    assert "The verifier reflects." in SYSTEM_PROMPT
    assert "The ledger remembers." in SYSTEM_PROMPT
    assert "The grader decides." in SYSTEM_PROMPT
    assert "You choose the task strategy." in SYSTEM_PROMPT
    assert "Verify cheaply as you go." in SYSTEM_PROMPT
    assert "Do not read hidden tests or hidden grader files." in SYSTEM_PROMPT


def test_prompt_is_generic_and_avoids_benchmark_vocabulary() -> None:
    prompt_text = "\n".join([SYSTEM_PROMPT, *DOCTRINE_LINES]).lower()
    banned_terms = [
        "terminal-bench",
        "terminalbench",
        "harbor",
        "tb2",
        "tb2.0",
        "extract-moves-from-video",
        "install-windows-3.11",
        "difficulty",
        "category",
        "tags",
        "search_receipts",
        "view_receipt",
        "view_file_cache",
        "search_files",
        "probe_service",
    ]

    for term in banned_terms:
        assert term not in prompt_text
