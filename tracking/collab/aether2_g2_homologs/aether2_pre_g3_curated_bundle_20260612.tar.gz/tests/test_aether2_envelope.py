from __future__ import annotations

import sys
from importlib import util
import json
from pathlib import Path
from types import SimpleNamespace


def _load_module():
    module_path = Path(__file__).resolve().parents[1] / "runner" / "aether2" / "envelope.py"
    spec = util.spec_from_file_location("aether2_envelope", module_path)
    assert spec is not None and spec.loader is not None
    module = util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


ENV = _load_module()


def test_collapse_cr_ansi_keeps_final_visible_state():
    text = "progress 10%\rprogress 20%\rdone\x1b[31m!\x1b[0m\nline two\rfinal two"
    assert ENV.collapse_cr_ansi(text) == "done!\nfinal two"


def test_build_envelope_bounds_and_raw_log(tmp_path):
    stdout = "A" * 2048 + "M" * 1000 + "B" * 2048
    stderr = "C" * 2048 + "N" * 1000 + "D" * 2048
    raw = SimpleNamespace(
        tool="run_command",
        exit_code=0,
        duration_sec=1.25,
        cwd="/tmp/work",
        stdout=stdout,
        stderr=stderr,
    )

    envelope = ENV.build_envelope(raw, raw_log_dir=tmp_path)

    assert envelope.tool == "run_command"
    assert envelope.exit_code == 0
    assert envelope.duration_sec == 1.25
    assert envelope.cwd == "/tmp/work"
    assert envelope.stdout_head == "A" * 2048
    assert envelope.stdout_tail == "B" * 2048
    assert envelope.stderr_head == "C" * 2048
    assert envelope.stderr_tail == "D" * 2048
    assert envelope.truncated is True
    assert envelope.raw_log_path

    raw_log_path = Path(envelope.raw_log_path)
    assert raw_log_path.exists()
    raw_log = raw_log_path.read_text(encoding="utf-8")
    assert stdout in raw_log
    assert stderr in raw_log


def test_build_envelope_exact_boundary_is_not_truncated(tmp_path):
    stdout = "x" * 4096
    stderr = "y" * 4096
    raw = SimpleNamespace(
        tool="session_read",
        exit_code=None,
        duration_sec=0.0,
        cwd="/tmp/work",
        stdout=stdout,
        stderr=stderr,
    )

    envelope = ENV.build_envelope(raw, raw_log_dir=tmp_path)

    assert envelope.truncated is False
    assert envelope.stdout_head == "x" * 2048
    assert envelope.stdout_tail == "x" * 2048
    assert envelope.stderr_head == "y" * 2048
    assert envelope.stderr_tail == "y" * 2048
    assert envelope.stdout_head + envelope.stdout_tail == stdout
    assert envelope.stderr_head + envelope.stderr_tail == stderr


def test_build_envelope_coerces_process_and_error_metadata(tmp_path):
    raw = SimpleNamespace(
        tool="run_command",
        exit_code=1,
        duration_sec=2.0,
        cwd="/tmp/work",
        stdout="ok",
        stderr="bad",
        process_delta={
            "started": ["proc-1"],
            "exited": ["proc-2"],
            "log_growth": {"proc.log": 10},
            "jobs_started": ["job-1"],
            "jobs_exited": ["job-2"],
            "sessions_started": ["session-1"],
            "sessions_exited": ["session-2"],
            "services_started": ["service-1"],
            "services_exited": ["service-2"],
            "job_log_growth": {"job.log": 11},
            "session_log_growth": {"session.log": 12},
            "service_log_growth": {"service.log": 13},
        },
        error={
            "kind": "refusal",
            "message": "already failed",
            "reason_code": "blind_retry_blocked_same_failed_command",
            "failure_class": "retry_guard",
            "details": "same command",
            "tool_name": "run_command",
            "command": "echo bad",
            "exit_code": 1,
            "timed_out": False,
        },
    )

    envelope = ENV.build_envelope(raw, raw_log_dir=tmp_path)

    assert envelope.blind_retry_blocked is True
    assert envelope.process_delta.started == ["proc-1"]
    assert envelope.process_delta.exited == ["proc-2"]
    assert envelope.process_delta.log_growth == {"proc.log": 10}
    assert envelope.process_delta.jobs_started == ["job-1"]
    assert envelope.process_delta.jobs_exited == ["job-2"]
    assert envelope.process_delta.sessions_started == ["session-1"]
    assert envelope.process_delta.sessions_exited == ["session-2"]
    assert envelope.process_delta.services_started == ["service-1"]
    assert envelope.process_delta.services_exited == ["service-2"]
    assert envelope.process_delta.job_log_growth == {"job.log": 11}
    assert envelope.process_delta.session_log_growth == {"session.log": 12}
    assert envelope.process_delta.service_log_growth == {"service.log": 13}
    assert envelope.error is not None
    assert envelope.error.reason_code == "blind_retry_blocked_same_failed_command"
    assert envelope.error.failure_class == "retry_guard"
    assert envelope.error.command == "echo bad"
    assert envelope.error.exit_code == 1
    assert envelope.error.timed_out is False

    raw_log = json.loads(Path(envelope.raw_log_path).read_text(encoding="utf-8"))
    assert raw_log["process_delta"]["jobs_started"] == ["job-1"]
    assert raw_log["process_delta"]["session_log_growth"] == {"session.log": 12}
    assert raw_log["error"]["reason_code"] == "blind_retry_blocked_same_failed_command"
    assert raw_log["error"]["command"] == "echo bad"
