import inspect

from runner.aether2.delta import DeltaReport
from runner.aether2 import mirror as mirror_module
from runner.aether2.mirror import Mirror, MirrorNote


def _empty_delta() -> DeltaReport:
    return DeltaReport(
        workspace_root="/workspace",
        captured_at=0.0,
        files_changed=[],
        artifact_registry_changed=False,
        service_registry_changed=False,
        process_registry_changed=False,
        job_registry_changed=False,
        session_registry_changed=False,
        added_paths=(),
        modified_paths=(),
        deleted_paths=(),
    )


def _changed_delta() -> DeltaReport:
    return DeltaReport(
        workspace_root="/workspace",
        captured_at=1.0,
        files_changed=[],
        artifact_registry_changed=True,
        service_registry_changed=False,
        process_registry_changed=False,
        job_registry_changed=False,
        session_registry_changed=False,
        added_paths=(),
        modified_paths=(),
        deleted_paths=(),
    )


def test_mirror_emits_on_third_identical_zero_delta_action() -> None:
    mirror = Mirror()
    delta = _empty_delta()

    assert mirror.observe("run_command:echo", delta) is None
    assert mirror.observe("run_command:echo", delta) is None

    note = mirror.observe("run_command:echo", delta)
    assert isinstance(note, MirrorNote)
    assert note.streak == 3
    assert note.action_signature == "run_command:echo"
    assert note.fuel_gauge_text is None
    assert note.note_type == "no_delta_progress"
    assert note.text == (
        "Steps in this streak produced no state change. "
        "Already established: none recorded. "
        "Not yet tried: none recorded."
    )
    assert "should" not in note.text.lower()
    assert "next" not in note.text.lower()


def test_mirror_emits_on_sixth_identical_zero_delta_action_with_fuel_gauge() -> None:
    mirror = Mirror()
    delta = _empty_delta()

    notes = [mirror.observe("run_command:echo", delta) for _ in range(6)]
    third_note = notes[2]
    sixth_note = notes[5]

    assert isinstance(third_note, MirrorNote)
    assert third_note.streak == 3
    assert third_note.fuel_gauge_text is None

    assert isinstance(sixth_note, MirrorNote)
    assert sixth_note.streak == 6
    assert sixth_note.action_signature == "run_command:echo"
    assert sixth_note.fuel_gauge_text == "elapsed/remaining time"
    assert sixth_note.text == (
        "Steps in this streak produced no state change. "
        "Already established: none recorded. "
        "Not yet tried: none recorded."
    )
    assert "should" not in sixth_note.text.lower()
    assert "next" not in sixth_note.text.lower()


def test_mirror_resets_on_delta() -> None:
    mirror = Mirror()
    empty = _empty_delta()
    changed = _changed_delta()

    assert mirror.observe("run_command:echo", empty) is None
    assert mirror.observe("run_command:echo", empty) is None
    assert mirror.observe("run_command:echo", changed) is None
    assert mirror.observe("run_command:echo", empty) is None
    assert mirror.observe("run_command:echo", empty) is None

    note = mirror.observe("run_command:echo", empty)
    assert isinstance(note, MirrorNote)
    assert note.streak == 3


def test_mirror_resets_on_action_change() -> None:
    mirror = Mirror()
    delta = _empty_delta()

    assert mirror.observe("run_command:echo", delta) is None
    assert mirror.observe("run_command:echo", delta) is None
    assert mirror.observe("run_command:printf", delta) is None
    assert mirror.observe("run_command:printf", delta) is None

    note = mirror.observe("run_command:printf", delta)
    assert isinstance(note, MirrorNote)
    assert note.streak == 3
    assert note.action_signature == "run_command:printf"


def test_mirror_module_is_generic_and_model_invisible() -> None:
    source = inspect.getsource(mirror_module).lower()
    banned_terms = {
        "terminal-bench",
        "terminalbench",
        "tb2",
        "tb2.0",
        "search_receipts",
        "view_receipt",
        "view_file_cache",
        "search_files",
        "probe_service",
    }

    assert set(getattr(mirror_module, "__all__", ())) == {"Mirror", "MirrorNote"}
    for term in banned_terms:
        assert term not in source
