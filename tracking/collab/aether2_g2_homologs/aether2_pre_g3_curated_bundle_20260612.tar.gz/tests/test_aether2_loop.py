from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from runner.aether2 import loop as loop_module
from runner.aether2.bridge_harbor import TaskSpec
from runner.aether2.executor import ContainerExecutor
from runner.aether2.loop import RunResult, run_aether2_loop
from runner.aether2.model_client import ModelResponse
from runner.aether2.sessions import SessionRegistry


def _response(text: str = "", tool_calls: tuple[dict, ...] = ()) -> ModelResponse:
    return ModelResponse(
        text=text,
        tool_calls=tool_calls,
        usage={"cached_input_tokens": 0, "fresh_input_tokens": 0},
        status="completed",
        raw_response={},
    )


def _tool_call(name: str, arguments: dict, call_id: str = "call-1") -> dict:
    return {"id": call_id, "type": "function", "name": name, "arguments": json.dumps(arguments)}


def _verify_response(satisfied: bool = True) -> ModelResponse:
    payload = {
        "requirements": [
            {
                "requirement": "task complete",
                "verdict": "satisfied" if satisfied else "unsatisfied",
                "evidence": "checked",
            }
        ],
        "reason_codes": [],
        "summary": "ok" if satisfied else "missing evidence",
    }
    return _response(text=json.dumps(payload))


class ScriptedModelClient:
    """Replays a fixed sequence of tool-call turns; non-tool calls (verify/compaction) get a separate queue."""

    def __init__(self, turns, side_responses=None):
        self.turns = list(turns)
        self.side_responses = list(side_responses or [])
        self.calls: list[tuple[list[dict], list[dict], int]] = []

    def call(self, messages, tools, *, cache_prefix_len):
        self.calls.append((list(messages), list(tools), cache_prefix_len))
        tool_names = {
            tool.get("function", {}).get("name")
            for tool in tools
            if isinstance(tool, dict)
        }
        if tool_names and tool_names.issubset({"run_command", "read_file", "job_status", "session_read"}):
            if self.side_responses:
                return self.side_responses.pop(0)
            return _verify_response(True)
        if not tools:
            if self.side_responses:
                return self.side_responses.pop(0)
            return _verify_response(True)
        if self.turns:
            return self.turns.pop(0)
        return _response(text="done")


def _make_task(tmp_path: Path, instruction: str = "do the thing") -> TaskSpec:
    task_dir = tmp_path / "task"
    workspace_root = task_dir / "workspace"
    artifacts_dir = task_dir / "artifacts"
    workspace_root.mkdir(parents=True)
    artifacts_dir.mkdir(parents=True)
    return TaskSpec(
        task_id="synthetic-task",
        instruction=instruction,
        task_dir=task_dir,
        workspace_root=workspace_root,
        artifacts_dir=artifacts_dir,
    )


def _make_executor(task: TaskSpec) -> ContainerExecutor:
    return ContainerExecutor(workspace_root=task.workspace_root)


def test_loop_terminates_on_task_done_and_runs_finalize(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="writing the file",
            tool_calls=(_tool_call("write_file", {"path": "out.txt", "content": "hello"}),),
        ),
        _response(
            text="done",
            tool_calls=(
                _tool_call("task_done", {"summary": "wrote out.txt", "checks": ["cat out.txt"]}, call_id="call-2"),
            ),
        ),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert isinstance(result, RunResult)
    assert result.finalize_reason == "task_done"
    assert result.pass_ is True
    assert result.verification_rounds == 1
    assert (task.workspace_root / "out.txt").read_text(encoding="utf-8") == "hello"
    verifier_calls = [
        call
        for call in client.calls
        if {
            tool.get("function", {}).get("name")
            for tool in call[1]
            if isinstance(tool, dict)
        }.issubset({"run_command", "read_file", "job_status", "session_read"})
        and call[1]
    ]
    assert verifier_calls


def test_loop_terminates_on_implicit_stop(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [_response(text="I believe this is complete.", tool_calls=())]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert result.finalize_reason == "implicit_stop"
    assert result.steps == 1
    verifier_calls = [
        call
        for call in client.calls
        if {
            tool.get("function", {}).get("name")
            for tool in call[1]
            if isinstance(tool, dict)
        }.issubset({"run_command", "read_file", "job_status", "session_read"})
        and call[1]
    ]
    assert verifier_calls


def test_loop_terminates_on_deadline_with_forced_path(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    # No turns ever consumed because the deadline has already passed.
    client = ScriptedModelClient(turns=[], side_responses=[_response(text="closing turn")])

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() - 1)

    assert result.finalize_reason == "budget_exhaustion"
    assert result.steps == 0
    assert result.summary == "closing turn"
    # exactly one closing-turn call with empty tools
    closing_calls = [call for call in client.calls if call[1] == []]
    assert len(closing_calls) == 1


def test_loop_runs_declared_checks_on_deadline_forced_path(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    # First turn declares task_done with checks but the loop's deadline check happens
    # before the *next* model call, so give it just enough budget for one step.
    turns = [
        _response(
            text="claiming done",
            tool_calls=(
                _tool_call(
                    "task_done",
                    {"summary": "all done", "checks": ["echo deadline-check"]},
                    call_id="call-1",
                ),
            ),
        ),
    ]
    client = ScriptedModelClient(turns, side_responses=[_response(text="closing turn")])

    # Deadline is far enough away for step 1, but task_done routes to the normal
    # finalize flow, not the deadline-forced path, when time remains. To exercise the
    # deadline-forced path with declared checks, call the loop with an already-past
    # deadline but pre-seed the most recently declared checks via a first pass.
    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)
    assert result.finalize_reason == "task_done"
    assert result.verification_rounds >= 1


def test_blind_retry_guard_fires_once_for_identical_failed_repeat(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    failing_call = _tool_call("run_command", {"cmd": "false"}, call_id="call-1")
    turns = [
        _response(text="trying", tool_calls=(failing_call,)),
        _response(text="retrying", tool_calls=(_tool_call("run_command", {"cmd": "false"}, call_id="call-2"),)),
        _response(text="trying something else", tool_calls=(_tool_call("run_command", {"cmd": "true"}, call_id="call-3"),)),
        _response(text="done", tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-4"),)),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    blind_retry_envelopes = [
        record.envelope for record in result.tool_invocations if record.envelope.blind_retry_blocked
    ]
    assert len(blind_retry_envelopes) == 1
    assert blind_retry_envelopes[0].error is not None
    assert blind_retry_envelopes[0].error.reason_code == "blind_retry_blocked_same_failed_command"

    # the second identical "false" call was blocked, not re-executed
    run_command_records = [r for r in result.tool_invocations if r.tool_name == "run_command"]
    assert len(run_command_records) == 3


def test_mirror_note_after_three_identical_zero_delta_actions(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    no_op_call = lambda call_id: _tool_call("run_command", {"cmd": "true"}, call_id=call_id)
    turns = [
        _response(text="step1", tool_calls=(no_op_call("call-1"),)),
        _response(text="step2", tool_calls=(no_op_call("call-2"),)),
        _response(text="step3", tool_calls=(no_op_call("call-3"),)),
        _response(text="done", tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-4"),)),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert len(result.mirror_notes) == 1
    assert result.mirror_notes[0].streak == 3
    assert result.no_delta_streaks == 1


def test_step_cap_is_a_safety_rail(tmp_path: Path, monkeypatch) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    monkeypatch.setattr(loop_module, "STEP_CAP", 2)

    # The model never calls task_done and never stops; the step cap must end the run.
    def infinite_turns():
        counter = 0
        while True:
            counter += 1
            yield _response(
                text=f"step {counter}",
                tool_calls=(_tool_call("run_command", {"cmd": f"echo {counter}"}, call_id=f"call-{counter}"),),
            )

    gen = infinite_turns()

    class InfiniteScriptedClient(ScriptedModelClient):
        def call(self, messages, tools, *, cache_prefix_len):
            self.calls.append((list(messages), list(tools), cache_prefix_len))
            if not tools:
                if self.side_responses:
                    return self.side_responses.pop(0)
                return _verify_response(True)
            return next(gen)

    client = InfiniteScriptedClient(turns=[])

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 600)

    assert result.steps == 2
    assert result.finalize_reason == "budget_exhaustion"
    closing_calls = [call for call in client.calls if call[1] == []]
    assert len(closing_calls) == 1


def test_max_three_verification_rounds_enforced(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="done",
            tool_calls=(_tool_call("task_done", {"summary": "first claim", "checks": ["false"]}, call_id="call-1"),),
        ),
        # Round 2: model responds to discrepancy with another task_done claim.
        _response(
            text="done again",
            tool_calls=(_tool_call("task_done", {"summary": "second claim", "checks": ["false"]}, call_id="call-2"),),
        ),
        # Round 3: model responds again.
        _response(
            text="done again again",
            tool_calls=(_tool_call("task_done", {"summary": "third claim", "checks": ["false"]}, call_id="call-3"),),
        ),
    ]
    # Verifier always reports a discrepancy so all 3 rounds are consumed.
    side_responses = [_verify_response(False), _verify_response(False), _verify_response(False)]
    client = ScriptedModelClient(turns, side_responses=side_responses)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert result.verification_rounds == 3
    assert result.pass_ is False


def test_g2_row_serialization_roundtrips_verification_fields(tmp_path: Path) -> None:
    """Regression for V1: the G2 runner's `run_result` row must include
    verification_rounds, discrepancy_reports, and verifier_clean -- not just
    a hand-picked subset -- so live-run forensics can see whether Layer-2
    finalize verification actually ran."""
    from dataclasses import asdict

    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="writing the file",
            tool_calls=(_tool_call("write_file", {"path": "out.txt", "content": "hello"}),),
        ),
        _response(
            text="done",
            tool_calls=(
                _tool_call("task_done", {"summary": "wrote out.txt", "checks": ["cat out.txt"]}, call_id="call-2"),
            ),
        ),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert result.verification_rounds >= 1
    assert len(result.discrepancy_reports) >= 1
    assert result.verifier_clean is True

    # Mirror tools/run_aether2_g2.py's row["run_result"] construction.
    row_run_result = {
        "verifier_clean": result.verifier_clean,
        "finalize_reason": result.finalize_reason,
        "summary": result.summary,
        "steps": result.steps,
        "model_calls": result.model_calls,
        "tokens_cached": result.tokens_cached,
        "tokens_fresh": result.tokens_fresh,
        "cost": result.cost,
        "wall_time": result.wall_time,
        "no_delta_streaks": result.no_delta_streaks,
        "verification_rounds": result.verification_rounds,
        "recoveries": result.recoveries,
        "compaction_count": result.compaction_count,
        "job_survival": result.job_survival,
        "session_survival": result.session_survival,
        "grader_reward": result.grader_reward,
        "discrepancy_reports": [asdict(report) for report in result.discrepancy_reports],
    }

    for field_name in (
        "verification_rounds",
        "discrepancy_reports",
        "verifier_clean",
        "no_delta_streaks",
        "recoveries",
        "compaction_count",
        "cost",
    ):
        assert field_name in row_run_result

    assert row_run_result["verification_rounds"] >= 1
    assert isinstance(row_run_result["discrepancy_reports"], list)
    assert len(row_run_result["discrepancy_reports"]) >= 1
    assert row_run_result["verifier_clean"] is True


def _tail_plan_from_messages(messages: list[dict]) -> str | None:
    for message in messages:
        if message.get("role") != "system":
            continue
        content = message.get("content", "")
        if not content.startswith("[tail_telemetry]\n"):
            continue
        payload = json.loads(content[len("[tail_telemetry]\n") :])
        return payload.get("plan")
    return None


def test_plan_text_captured_from_first_turn_and_replaced_by_plan_prefixed_turn(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="Working on it: read the file first.",
            tool_calls=(_tool_call("run_command", {"cmd": "true"}, call_id="call-1"),),
        ),
        _response(
            text="PLAN: write out.txt then verify\nMore detail here.",
            tool_calls=(_tool_call("run_command", {"cmd": "true"}, call_id="call-2"),),
        ),
        _response(
            text="done",
            tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-3"),),
        ),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert isinstance(result, RunResult)

    tool_calls_only = [call for call in client.calls if call[1] != []]
    assert len(tool_calls_only) >= 3

    # The second model call's tail telemetry carries the first turn's text as the plan.
    plan_after_first_turn = _tail_plan_from_messages(tool_calls_only[1][0])
    assert plan_after_first_turn == "Working on it: read the file first."

    # The third model call's tail telemetry carries the full "PLAN:" turn as the plan.
    plan_after_plan_turn = _tail_plan_from_messages(tool_calls_only[2][0])
    assert plan_after_plan_turn == "PLAN: write out.txt then verify\nMore detail here."


def _write_fake_tmux(root: Path) -> Path:
    script = root / "tmux"
    script.write_text(
        "\n".join(
            [
                "#!/usr/bin/env python3",
                "import json, sys",
                "from pathlib import Path",
                f"root = Path({str(root)!r})",
                "state = root / 'fake_tmux_state'",
                "state.mkdir(exist_ok=True)",
                "args = sys.argv[1:]",
                "cmd = args[0]",
                "if cmd == 'new-session':",
                "    session_id = args[3]",
                "    (state / f'{session_id}.json').write_text('{}', encoding='utf-8')",
                "    sys.exit(0)",
                "if cmd == 'send-keys':",
                "    sys.exit(0)",
                "if cmd == 'capture-pane':",
                "    sys.stdout.write('')",
                "    sys.exit(0)",
                "if cmd == 'kill-session':",
                "    session_id = args[2]",
                "    path = state / f'{session_id}.json'",
                "    if path.exists():",
                "        path.unlink()",
                "    sys.exit(0)",
                "sys.exit(1)",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    return script


def test_session_survival_true_when_session_remains_registered(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, retrying_subprocess
) -> None:
    from runner.aether2 import sessions as sessions_module

    retrying_subprocess(sessions_module)
    _write_fake_tmux(tmp_path)
    monkeypatch.setenv("PATH", f"{tmp_path}{os.pathsep}{os.environ['PATH']}")

    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="starting a session",
            tool_calls=(_tool_call("session_start", {"session_id": "shell", "command": "bash"}, call_id="call-1"),),
        ),
        _response(
            text="done",
            tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-2"),),
        ),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert result.session_survival is True


def test_session_survival_false_when_session_disappears_from_registry(tmp_path: Path) -> None:
    state_dir = tmp_path / ".aether2" / "state"
    registry = SessionRegistry(state_dir)

    session_ids = ["shell"]
    # Simulate a session that the loop tracked but that no longer appears in the
    # registry (e.g. it was killed/cleaned up out from under the loop).
    assert registry.list_session_ids() == []

    session_survival = (
        all(sid in registry.list_session_ids() for sid in session_ids) if session_ids else True
    )
    assert session_survival is False


def test_prefix_bytes_identical_across_appends_until_rebase(tmp_path: Path) -> None:
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(text="step1", tool_calls=(_tool_call("run_command", {"cmd": "true"}, call_id="call-1"),)),
        _response(text="done", tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-2"),)),
    ]
    client = ScriptedModelClient(turns)

    from runner.aether2.context import ContextManager

    context = ContextManager()
    prefix = context.build_prefix(
        system_prompt="system",
        task_instruction=task.instruction,
        orientation={"cwd": str(task.workspace_root)},
        tool_schemas=[{"function": {"name": "run_command"}}],
    )
    context.append_turn({"role": "assistant", "content": "plan"})
    context.append_turn({"role": "tool", "content": "ok", "name": "run_command"})
    context.assert_prefix_unchanged()
    assert prefix.frozen_bytes == context.prefix.frozen_bytes

    # The loop itself must not mutate its own immutable prefix either.
    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)
    assert isinstance(result, RunResult)


def test_write_file_surfaces_artifact_event_in_next_tail_and_does_not_re_render_when_unchanged(tmp_path: Path) -> None:
    """C4: a write_file step surfaces an artifact_written event in the next tail
    render; once consumed, an unchanged state does not repeat it."""
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="step1",
            tool_calls=(_tool_call("write_file", {"path": "art.txt", "content": "hi"}, call_id="call-1"),),
        ),
        _response(
            text="step2",
            tool_calls=(_tool_call("run_command", {"cmd": "true"}, call_id="call-2"),),
        ),
        _response(
            text="done",
            tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-3"),),
        ),
    ]
    client = ScriptedModelClient(turns)

    run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    # Step 1's call has no events yet (nothing written before it).
    # Step 2's tail (rendered before the 2nd model call) must include the
    # artifact_written event from step 1's write_file.
    tail_messages = []
    for messages, tools, _ in client.calls:
        if not tools:
            continue
        last = messages[-1]
        content = str(last.get("content", ""))
        if last.get("role") == "system" and "derived_state" in content:
            _, _, json_part = content.partition("\n")
            tail_messages.append(json.loads(json_part))

    assert len(tail_messages) >= 2
    second_tail = tail_messages[1]
    events = second_tail["derived_state"].get("events", [])
    assert any("artifact_written:art.txt" in event for event in events)

    # Step 3's tail must NOT repeat the same event (unchanged state -> no re-render).
    if len(tail_messages) >= 3:
        third_tail = tail_messages[2]
        third_events = third_tail["derived_state"].get("events", [])
        assert not any("artifact_written:art.txt" in event for event in third_events)


def test_run_completion_does_not_stop_registered_jobs(tmp_path: Path, retrying_subprocess) -> None:
    """C2: completing a run must not kill jobs the model started via start_job."""
    from runner.aether2 import jobs as jobs_module

    retrying_subprocess(jobs_module)

    task = _make_task(tmp_path)
    executor = _make_executor(task)

    turns = [
        _response(
            text="start the job",
            tool_calls=(
                _tool_call(
                    "start_job",
                    {"cmd": "sleep 5", "job_id": "long-runner"},
                    call_id="call-1",
                ),
            ),
        ),
        _response(
            text="done",
            tool_calls=(_tool_call("task_done", {"summary": "started job", "checks": ["true"]}, call_id="call-2"),),
        ),
    ]
    client = ScriptedModelClient(turns)

    result = run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert result.job_survival is True

    from runner.aether2.jobs import JobRegistry

    state_dir = task.workspace_root / ".aether2" / "state"
    status = JobRegistry(state_dir).status("long-runner")
    assert status.alive is True


def test_rebase_fact_ledger_includes_installed_packages_and_nonzero_exits(tmp_path: Path, monkeypatch) -> None:
    """C5: the §6.5 fact ledger built at rebase time includes installed_packages
    (derived generically from package-manager command successes) and
    nonzero_exits (from failed run_command invocations)."""
    task = _make_task(tmp_path)
    executor = _make_executor(task)

    captured_ledgers = []
    from runner.aether2 import compactor as compactor_module

    original_build_fact_ledger = compactor_module.build_fact_ledger

    def spy_build_fact_ledger(delta_state):
        ledger = original_build_fact_ledger(delta_state)
        captured_ledgers.append(ledger)
        return ledger

    monkeypatch.setattr(compactor_module, "build_fact_ledger", spy_build_fact_ledger)
    monkeypatch.setattr(loop_module, "CONTEXT_WINDOW_TOKENS", 1)  # force rebase every step

    turns = [
        _response(text="install", tool_calls=(_tool_call("run_command", {"cmd": "pip install requests"}, call_id="call-1"),)),
        _response(text="fail", tool_calls=(_tool_call("run_command", {"cmd": "false"}, call_id="call-2"),)),
        _response(text="done", tool_calls=(_tool_call("task_done", {"summary": "ok", "checks": ["true"]}, call_id="call-3"),)),
    ]
    client = ScriptedModelClient(turns)

    run_aether2_loop(task, client, executor, deadline_ts=time.time() + 60)

    assert captured_ledgers, "expected at least one rebase to occur"
    last_ledger = captured_ledgers[-1]
    assert "pip install requests" in last_ledger["installed_packages"]
    assert any(item["command"] == "false" and item["exit_code"] != 0 for item in last_ledger["nonzero_exits"])


def test_read_only_verification_context_allows_safe_and_rejects_unsafe_commands(tmp_path: Path) -> None:
    """C7: deny-by-default allowlist for verifier inspection commands."""
    from runner.aether2.loop import ExecutionContext, _ReadOnlyVerificationContext
    from runner.aether2.jobs import JobRegistry
    from runner.aether2.receipts import ReceiptWriter

    task = _make_task(tmp_path)
    executor = _make_executor(task)
    (task.workspace_root / "out.txt").write_text("hello\n", encoding="utf-8")

    state_dir = task.workspace_root / ".aether2" / "state"
    ctx = ExecutionContext(
        executor=executor,
        job_registry=JobRegistry(state_dir),
        session_registry=SessionRegistry(state_dir),
        raw_log_dir=task.workspace_root / ".aether2" / "raw_logs",
    )
    receipts = ReceiptWriter(task.task_dir / ".aether2" / "host_receipts")
    verifier_ctx = _ReadOnlyVerificationContext(ctx, receipts)

    allowed = verifier_ctx.run_command("cat out.txt")
    assert allowed.error is None
    assert "hello" in allowed.stdout_head

    rejected_rm = verifier_ctx.run_command("rm out.txt")
    assert rejected_rm.error is not None
    assert rejected_rm.error.reason_code == "verification_read_only_violation"
    assert (task.workspace_root / "out.txt").exists()

    rejected_redirect = verifier_ctx.run_command("cat out.txt > clobber.txt")
    assert rejected_redirect.error is not None
    assert not (task.workspace_root / "clobber.txt").exists()

    allowed_pipe = verifier_ctx.run_command("cat out.txt | grep hello")
    assert allowed_pipe.error is None

    receipt_files = list((task.task_dir / ".aether2" / "host_receipts").rglob("verifier_inspection_*.json"))
    assert len(receipt_files) == 4
