"""No-delta progress mirror for Aether-2."""

from __future__ import annotations

from dataclasses import dataclass

from runner.aether2.delta import DeltaReport

__all__ = ["Mirror", "MirrorNote"]


@dataclass(frozen=True)
class MirrorNote:
    """Factual no-delta observation surfaced to the model."""

    action_signature: str
    streak: int
    text: str
    fuel_gauge_text: str | None = None
    note_type: str = "no_delta_progress"


class Mirror:
    """Track identical zero-delta streaks and emit factual observations."""

    def __init__(self) -> None:
        self._last_action_signature: str | None = None
        self._streak = 0

    @property
    def streak(self) -> int:
        return self._streak

    def observe(
        self,
        action_signature: str,
        delta: DeltaReport,
        *,
        established_facts: list[str] | None = None,
        unused_affordances: list[str] | None = None,
        fuel_gauge_text: str | None = None,
    ) -> MirrorNote | None:
        if action_signature != self._last_action_signature:
            self._last_action_signature = action_signature
            self._streak = 0

        if not delta.is_empty:
            self._streak = 0
            return None

        self._streak += 1
        if self._streak == 3:
            return self._build_note(
                include_fuel_gauge=False,
                established_facts=established_facts or [],
                unused_affordances=unused_affordances or [],
                fuel_gauge_text=fuel_gauge_text,
            )
        if self._streak == 6:
            return self._build_note(
                include_fuel_gauge=True,
                established_facts=established_facts or [],
                unused_affordances=unused_affordances or [],
                fuel_gauge_text=fuel_gauge_text,
            )
        return None

    def _build_note(
        self,
        *,
        include_fuel_gauge: bool,
        established_facts: list[str],
        unused_affordances: list[str],
        fuel_gauge_text: str | None,
    ) -> MirrorNote:
        facts_text = ", ".join(established_facts) if established_facts else "none recorded"
        affordances_text = ", ".join(unused_affordances) if unused_affordances else "none recorded"
        text = (
            f"Steps in this streak produced no state change. "
            f"Already established: {facts_text}. "
            f"Not yet tried: {affordances_text}."
        )
        return MirrorNote(
            action_signature="" if self._last_action_signature is None else self._last_action_signature,
            streak=self._streak,
            text=text,
            fuel_gauge_text=(fuel_gauge_text or "elapsed/remaining time") if include_fuel_gauge else None,
        )
