"""Continuous executor loop composing tools, context, mirror, and verification into one run."""

from __future__ import annotations

from dataclasses import dataclass, field, replace as dataclass_replace
from pathlib import Path
from typing import Any, Mapping
import json
import shlex
import time

from runner.aether2.bridge_harbor import TaskSpec
from runner.aether2.compactor import rebase, should_rebase
from runner.aether2.context import ContextManager
from runner.aether2.delta import StateSnapshot, diff as delta_diff, snapshot as delta_snapshot
from runner.aether2.envelope import ObservationEnvelope, build_envelope
from runner.aether2.envelope import FileDelta as EnvelopeFileDelta
from runner.aether2.envelope import ProcessDelta
from runner.aether2.executor import ContainerExecutor
from runner.aether2.jobs import JobRegistry
from runner.aether2.mirror import Mirror, MirrorNote
from runner.aether2.orientation import orient
from runner.aether2.prompts import SYSTEM_PROMPT
from runner.aether2.receipts import ReceiptWriter
from runner.aether2.sessions import SessionRegistry
from runner.aether2.tools import TOOL_SCHEMAS, dispatch
from runner.aether2.verify import replay_checks, verify_fresh_context
from runner.kernel_layer2_audit import _clean_hidden_refs


STEP_CAP = 120
MAX_VERIFICATION_ROUNDS = 3
CONTEXT_WINDOW_TOKENS = 128_000

# Generic package-manager invocations (first 1-2 shell tokens). Used only to
# detect "this run_command was a package install" for the §6.5 fact ledger's
# `installed_packages` entry -- no task-specific package names or logic.
_PACKAGE_MANAGER_PREFIXES: tuple[tuple[str, ...], ...] = (
    ("apt-get", "install"),
    ("apt", "install"),
    ("pip", "install"),
    ("pip3", "install"),
    ("python", "-m", "pip", "install"),
    ("python3", "-m", "pip", "install"),
    ("npm", "install"),
    ("npm", "i"),
    ("yarn", "add"),
    ("cargo", "install"),
    ("gem", "install"),
    ("go", "install"),
    ("brew", "install"),
    ("conda", "install"),
    ("apk", "add"),
    ("dnf", "install"),
    ("yum", "install"),
)


def _is_package_manager_install(command: str) -> bool:
    try:
        tokens = shlex.split(command, posix=True)
    except ValueError:
        return False
    for prefix in _PACKAGE_MANAGER_PREFIXES:
        if tuple(tokens[: len(prefix)]) == prefix:
            return True
    return False


@dataclass(frozen=True)
class ToolInvocationRecord:
    """One dispatched tool call, its arguments, and the resulting envelope."""

    step: int
    tool_name: str
    arguments: dict[str, Any]
    envelope: ObservationEnvelope


@dataclass(frozen=True)
class RunResult:
    """The outcome of one continuity-loop run, carrying everything the scorecard needs."""

    verifier_clean: bool
    finalize_reason: str
    summary: str
    steps: int
    model_calls: int
    tokens_cached: int
    tokens_fresh: int
    cost: float
    wall_time: float
    no_delta_streaks: int
    verification_rounds: int
    recoveries: int
    compaction_count: int
    job_survival: bool
    session_survival: bool
    grader_reward: float | None = None
    tool_invocations: list[ToolInvocationRecord] = field(default_factory=list)
    mirror_notes: list[MirrorNote] = field(default_factory=list)
    discrepancy_reports: list[Any] = field(default_factory=list)

    @property
    def pass_(self) -> bool:
        """Deprecated alias for `verifier_clean` (advisory verifier signal, not grader authority)."""
        return self.verifier_clean


class ExecutionContext:
    """Adapts the container executor, job registry, and session registry to the dispatch surface."""

    def __init__(
        self,
        *,
        executor: ContainerExecutor,
        job_registry: JobRegistry,
        session_registry: SessionRegistry,
        raw_log_dir: Path,
    ) -> None:
        self.executor = executor
        self.job_registry = job_registry
        self.session_registry = session_registry
        self.raw_log_dir = raw_log_dir
        self.workspace_root = executor.workspace_root
        self.last_snapshot: StateSnapshot = delta_snapshot(self.workspace_root)
        self.last_delta_report = delta_diff(self.last_snapshot, self.last_snapshot)
        # Cumulative run-level facts for the §6.5 fact ledger (not derivable from
        # a single filesystem snapshot).
        self.installed_packages: list[str] = []
        self.nonzero_exits: list[dict[str, Any]] = []

    def run_command(self, cmd: str, timeout_sec: int = 120, cwd: str | None = None) -> ObservationEnvelope:
        raw = self.executor.run(cmd, timeout_sec=timeout_sec, cwd=cwd)
        exit_code = getattr(raw, "exit_code", None)
        if exit_code == 0 and _is_package_manager_install(cmd):
            self.installed_packages.append(cmd)
        elif exit_code is not None and exit_code != 0:
            self.nonzero_exits.append({"command": cmd, "exit_code": exit_code, "stderr": (getattr(raw, "stderr", "") or "")[-2048:]})
        return self._observe_raw(raw)

    def start_job(self, cmd: str, job_id: str | None = None, cwd: str | None = None) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            resolved_job_id = self.job_registry.start(cmd, job_id=job_id, cwd=cwd)
            status = self.job_registry.status(resolved_job_id)
            raw = {
                "tool": "start_job",
                "exit_code": 0,
                "duration_sec": time.monotonic() - started_at,
                "cwd": status.cwd,
                "stdout": f"started job {resolved_job_id} (pid {status.pid})",
                "stderr": "",
            }
        except Exception as exc:  # noqa: BLE001 - surfaced as a truthful error envelope
            raw = _error_raw("start_job", exc, started_at=started_at, cwd=str(self.executor.workspace_root))
        return self._observe_raw(raw)

    def job_status(self, job_id: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            status = self.job_registry.status(job_id)
            raw = {
                "tool": "job_status",
                "exit_code": status.exit_code if status.exit_code is not None else (0 if status.alive else None),
                "duration_sec": time.monotonic() - started_at,
                "cwd": status.cwd,
                "stdout": (
                    f"job {job_id}: alive={status.alive} exit_code={status.exit_code}\n--- log tail ---\n{status.tail}"
                ),
                "stderr": "",
            }
        except Exception as exc:  # noqa: BLE001
            raw = _error_raw("job_status", exc, started_at=started_at, cwd=str(self.executor.workspace_root))
        return self._observe_raw(raw)

    def session_start(self, session_id: str, command: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            self.session_registry.start(session_id, command)
            raw = {
                "tool": "session_start",
                "exit_code": 0,
                "duration_sec": time.monotonic() - started_at,
                "cwd": str(self.executor.workspace_root),
                "stdout": f"started session {session_id}",
                "stderr": "",
            }
        except Exception as exc:  # noqa: BLE001
            raw = _error_raw("session_start", exc, started_at=started_at, cwd=str(self.executor.workspace_root))
        return self._observe_raw(raw)

    def session_send(self, session_id: str, keys: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            self.session_registry.send(session_id, keys)
            raw = {
                "tool": "session_send",
                "exit_code": 0,
                "duration_sec": time.monotonic() - started_at,
                "cwd": str(self.executor.workspace_root),
                "stdout": f"sent keys to session {session_id}",
                "stderr": "",
            }
        except Exception as exc:  # noqa: BLE001
            raw = _error_raw("session_send", exc, started_at=started_at, cwd=str(self.executor.workspace_root))
        return self._observe_raw(raw)

    def session_read(self, session_id: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            screen = self.session_registry.read(session_id)
            raw = {
                "tool": "session_read",
                "exit_code": None,
                "duration_sec": time.monotonic() - started_at,
                "cwd": str(self.executor.workspace_root),
                "stdout": screen,
                "stderr": "",
            }
        except Exception as exc:  # noqa: BLE001
            raw = _error_raw("session_read", exc, started_at=started_at, cwd=str(self.executor.workspace_root))
        return self._observe_raw(raw)

    def read_file(self, path: str, offset: int | None = None, limit: int | None = None) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            target = self.executor.resolve_workspace_path(path)
            text = target.read_text(encoding="utf-8", errors="replace")
            lines = text.splitlines(keepends=True)
            start = offset or 0
            if limit is not None:
                selected = lines[start : start + limit]
            else:
                selected = lines[start:]
            content = "".join(selected)
            truncated_note = ""
            if start > 0 or (limit is not None and start + limit < len(lines)):
                truncated_note = f"\n...[showing lines {start}:{start + len(selected)} of {len(lines)}]"
            raw = {
                "tool": "read_file",
                "exit_code": 0,
                "duration_sec": time.monotonic() - started_at,
                "cwd": str(self.executor.workspace_root),
                "stdout": content + truncated_note,
                "stderr": "",
            }
        except ValueError as exc:
            raw = _error_raw(
                "read_file",
                exc,
                started_at=started_at,
                cwd=str(self.executor.workspace_root),
                kind="workspace_boundary_violation",
            )
        except FileNotFoundError as exc:
            raw = _error_raw("read_file", exc, started_at=started_at, cwd=str(self.executor.workspace_root), kind="file_not_found")
        except OSError as exc:
            raw = _error_raw("read_file", exc, started_at=started_at, cwd=str(self.executor.workspace_root), kind="io_error")
        return self._observe_raw(raw)

    def write_file(self, path: str, content: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        try:
            target = self.executor.resolve_workspace_path(path)
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = target.with_name(target.name + ".aether2_tmp")
            tmp_path.write_text(content, encoding="utf-8")
            tmp_path.replace(target)
            raw = {
                "tool": "write_file",
                "exit_code": 0,
                "duration_sec": time.monotonic() - started_at,
                "cwd": str(self.executor.workspace_root),
                "stdout": f"wrote {len(content)} bytes to {path}",
                "stderr": "",
            }
        except ValueError as exc:
            raw = _error_raw(
                "write_file",
                exc,
                started_at=started_at,
                cwd=str(self.executor.workspace_root),
                kind="workspace_boundary_violation",
            )
        except OSError as exc:
            raw = _error_raw("write_file", exc, started_at=started_at, cwd=str(self.executor.workspace_root), kind="io_error")
        return self._observe_raw(raw)

    def wait(self, seconds: int, reason: str) -> ObservationEnvelope:
        started_at = time.monotonic()
        bounded_seconds = max(0, min(int(seconds), 300))
        time.sleep(bounded_seconds)
        raw = {
            "tool": "wait",
            "exit_code": 0,
            "duration_sec": time.monotonic() - started_at,
            "cwd": str(self.executor.workspace_root),
            "stdout": f"waited {bounded_seconds}s ({reason})",
            "stderr": "",
        }
        return self._observe_raw(raw)

    def task_done(self, summary: str, checks: list[str]) -> ObservationEnvelope:
        raw = {
            "tool": "task_done",
            "exit_code": 0,
            "duration_sec": 0.0,
            "cwd": str(self.executor.workspace_root),
            "stdout": summary,
            "stderr": "",
        }
        return self._observe_raw(raw)

    def _observe_raw(self, raw: Any) -> ObservationEnvelope:
        current_snapshot = delta_snapshot(self.workspace_root)
        delta_report = delta_diff(self.last_snapshot, current_snapshot)
        raw_payload = dict(raw) if isinstance(raw, Mapping) else raw.__dict__.copy()
        raw_payload["files_changed"] = [
            EnvelopeFileDelta(
                path=item.path,
                hash_before=item.hash_before,
                hash_after=item.hash_after,
                change_type=item.change_type,
            )
            for item in delta_report.files_changed
        ]
        raw_payload["process_delta"] = self._build_process_delta(self.last_snapshot, current_snapshot)
        envelope = build_envelope(raw_payload, raw_log_dir=self.raw_log_dir)
        self.last_snapshot = current_snapshot
        self.last_delta_report = delta_report
        return envelope

    def _build_process_delta(self, prev: StateSnapshot, curr: StateSnapshot) -> ProcessDelta:
        process_delta = ProcessDelta()

        prev_jobs = prev.job_registry
        curr_jobs = curr.job_registry
        prev_sessions = prev.session_registry
        curr_sessions = curr.session_registry
        prev_services = prev.service_registry
        curr_services = curr.service_registry
        prev_processes = prev.process_registry
        curr_processes = curr.process_registry

        for job_id in sorted(set(prev_jobs) | set(curr_jobs)):
            before = prev_jobs.get(job_id)
            after = curr_jobs.get(job_id)
            if before is None and after is not None:
                process_delta.jobs_started.append(job_id)
            elif before is not None and after is None:
                process_delta.jobs_exited.append(job_id)
            elif before is not None and after is not None:
                if bool(before.get("alive")) and not bool(after.get("alive")):
                    process_delta.jobs_exited.append(job_id)
                growth = int(after.get("log_size", 0)) - int(before.get("log_size", 0))
                if growth > 0:
                    process_delta.job_log_growth[job_id] = growth

        for session_id in sorted(set(prev_sessions) | set(curr_sessions)):
            before = prev_sessions.get(session_id)
            after = curr_sessions.get(session_id)
            if before is None and after is not None:
                process_delta.sessions_started.append(session_id)
            elif before is not None and after is None:
                process_delta.sessions_exited.append(session_id)

        for service_id in sorted(set(prev_services) | set(curr_services)):
            before = prev_services.get(service_id)
            after = curr_services.get(service_id)
            if before is None and after is not None:
                process_delta.services_started.append(service_id)
            elif before is not None and after is None:
                process_delta.services_exited.append(service_id)

        for process_id in sorted(set(prev_processes) | set(curr_processes)):
            before = prev_processes.get(process_id)
            after = curr_processes.get(process_id)
            if before is None and after is not None:
                process_delta.started.append(process_id)
            elif before is not None and after is None:
                process_delta.exited.append(process_id)

        return process_delta


def _error_raw(
    tool: str,
    exc: Exception,
    *,
    started_at: float,
    cwd: str,
    kind: str = "runtime_error",
) -> dict[str, Any]:
    return {
        "tool": tool,
        "exit_code": 1,
        "duration_sec": time.monotonic() - started_at,
        "cwd": cwd,
        "stdout": "",
        "stderr": str(exc),
        "error": {
            "kind": kind,
            "message": str(exc),
            "reason_code": kind,
            "tool_name": tool,
        },
    }


def _action_signature(tool_name: str, arguments: Mapping[str, Any]) -> str:
    return f"{tool_name}:" + json.dumps(arguments, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _envelope_failed(envelope: ObservationEnvelope) -> bool:
    if envelope.error is not None:
        return True
    if envelope.exit_code is not None and envelope.exit_code != 0:
        return True
    return False


def _build_blind_retry_blocked_envelope(
    tool_name: str, arguments: Mapping[str, Any], cwd: str, *, raw_log_dir: Path
) -> ObservationEnvelope:
    raw = {
        "tool": tool_name,
        "exit_code": 1,
        "duration_sec": 0.0,
        "cwd": cwd,
        "stdout": "",
        "stderr": "blind_retry_blocked_same_failed_command",
        "blind_retry_blocked": True,
        "error": {
            "kind": "blind_retry_blocked",
            "message": (
                "This exact action just failed and nothing has changed since. "
                "Try something different before repeating it."
            ),
            "reason_code": "blind_retry_blocked_same_failed_command",
            "tool_name": tool_name,
        },
    }
    return build_envelope(raw, raw_log_dir=raw_log_dir)


def _parse_tool_call_arguments(tool_call: Mapping[str, Any]) -> dict[str, Any]:
    arguments = tool_call.get("arguments")
    if isinstance(arguments, Mapping):
        return dict(arguments)
    if isinstance(arguments, str):
        if not arguments.strip():
            return {}
        try:
            parsed = json.loads(arguments)
        except (TypeError, ValueError):
            return {}
        if isinstance(parsed, dict):
            return parsed
    return {}


def _tool_call_name(tool_call: Mapping[str, Any]) -> str | None:
    name = tool_call.get("name")
    if isinstance(name, str) and name:
        return name
    function = tool_call.get("function")
    if isinstance(function, Mapping):
        nested_name = function.get("name")
        if isinstance(nested_name, str) and nested_name:
            return nested_name
    return None


def _envelope_to_message(tool_name: str, tool_call_id: Any, envelope: ObservationEnvelope) -> dict[str, Any]:
    payload = {
        "tool": envelope.tool,
        "exit_code": envelope.exit_code,
        "duration_sec": envelope.duration_sec,
        "cwd": envelope.cwd,
        "stdout_head": envelope.stdout_head,
        "stdout_tail": envelope.stdout_tail,
        "stderr_head": envelope.stderr_head,
        "stderr_tail": envelope.stderr_tail,
        "truncated": envelope.truncated,
        "raw_log_path": envelope.raw_log_path,
        "files_changed": [item.__dict__ for item in envelope.files_changed],
        "process_delta": envelope.process_delta.__dict__,
        "blind_retry_blocked": envelope.blind_retry_blocked,
        "error": None if envelope.error is None else envelope.error.__dict__,
    }
    return {
        "role": "tool",
        "name": tool_name,
        "tool_call_id": tool_call_id,
        "content": json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True),
    }


def _build_tail_state(
    *,
    plan_text: str | None,
    elapsed_sec: float,
    remaining_sec: float | None,
    mirror: Mirror,
    streak: int,
    job_registry: JobRegistry,
    session_registry: SessionRegistry,
    job_ids: list[str],
    session_ids: list[str],
    note: MirrorNote | None,
    events: list[str] | None = None,
) -> dict[str, Any]:
    fuel_gauge: dict[str, Any] = {"elapsed_sec": round(elapsed_sec, 3)}
    if remaining_sec is not None:
        fuel_gauge["remaining_sec"] = round(remaining_sec, 3)

    jobs_state: dict[str, Any] = {}
    for job_id in job_ids:
        try:
            status = job_registry.status(job_id)
            jobs_state[job_id] = {"alive": status.alive, "exit_code": status.exit_code}
        except KeyError:
            continue

    derived_state: dict[str, Any] = {
        "no_delta_streak": streak,
        "active_jobs": jobs_state,
        "active_sessions": list(session_ids),
    }
    if events:
        derived_state["events"] = list(events)

    tail: dict[str, Any] = {
        "plan": plan_text or "",
        "fuel_gauge": fuel_gauge,
        "derived_state": derived_state,
    }
    if note is not None:
        tail["mirror_note"] = note.text
        if note.fuel_gauge_text:
            tail["mirror_fuel_gauge"] = note.fuel_gauge_text
    return tail


def _response_usage(response: Any) -> Mapping[str, Any]:
    usage = getattr(response, "usage", {})
    if isinstance(usage, Mapping):
        return usage
    return {}


def _response_cost(response: Any) -> float:
    raw_response = getattr(response, "raw_response", {})
    if isinstance(raw_response, Mapping):
        direct = raw_response.get("cost")
        if isinstance(direct, (int, float)):
            return float(direct)
        usage = raw_response.get("usage")
        if isinstance(usage, Mapping):
            value = usage.get("cost")
            if isinstance(value, (int, float)):
                return float(value)
    return 0.0


def _model_requested_rebase(response_text: str, tool_calls: Any) -> bool:
    if tool_calls:
        return False
    first_line = response_text.splitlines()[0].strip().upper() if response_text.splitlines() else ""
    return first_line.startswith("REBASE_REQUEST:")


def _model_requested_verification(response_text: str, tool_calls: Any) -> bool:
    if tool_calls:
        return False
    first_line = response_text.splitlines()[0].strip().upper() if response_text.splitlines() else ""
    return first_line.startswith("VERIFY_REQUEST:")


def _collect_established_facts(context: ContextManager) -> list[str]:
    snapshot = context.delta_state
    if snapshot is None:
        return []
    facts: list[str] = []
    files = getattr(snapshot, "files", {}) or {}
    jobs = getattr(snapshot, "job_registry", {}) or {}
    sessions = getattr(snapshot, "session_registry", {}) or {}
    if files:
        facts.append(f"written files: {', '.join(sorted(files)[:5])}")
    if jobs:
        facts.append(f"jobs: {', '.join(sorted(jobs)[:5])}")
    if sessions:
        facts.append(f"sessions: {', '.join(sorted(sessions)[:5])}")
    return facts


def _unused_affordances() -> list[str]:
    return [
        "start_job",
        "job_status",
        "session_start",
        "session_send",
        "session_read",
        "read_file",
        "write_file",
        "wait",
    ]


class _ReadOnlyVerificationContext:
    """Expose only read-only inspection affordances during verifier probes (C7).

    Deny-by-default: `run_command` is rejected unless every pipe segment's first
    token is a conservative read-only binary AND no shell metacharacters other
    than `|` (pipe) appear anywhere in the command. Every attempt -- allowed or
    rejected -- is recorded via `receipts.record_verifier_command` for a full
    audit trail. Perfect read-only enforcement in a shell is not possible (e.g.
    a malicious `find -exec`); this is a best-effort structural guard plus a
    complete audit trail, per the spec's honest-engineering posture.
    """

    _ALLOWED_BINARIES = {
        "ls",
        "cat",
        "head",
        "tail",
        "grep",
        "find",
        "stat",
        "wc",
        "file",
        "ps",
        "df",
        "du",
        "sha256sum",
        "jq",
        "pwd",
    }
    # Any of these appearing as standalone tokens (other than "|") makes the
    # command rejected: redirects, command chaining/substitution, backgrounding.
    _DISALLOWED_TOKENS = {
        ">", ">>", "<", "<<", ";", "&", "&&", "||", "`", "$(",
        "rm", "mv", "cp", "tee", "chmod", "chown", "mkdir", "touch", "kill",
        "dd", "truncate", "sed", "-exec", "-delete", "-ok",
    }

    def __init__(self, ctx: ExecutionContext, receipts: "ReceiptWriter | None" = None) -> None:
        self._ctx = ctx
        self._receipts = receipts
        self._call_idx = 0

    def _record(self, tool_name: str, arguments: dict[str, Any], envelope: ObservationEnvelope) -> ObservationEnvelope:
        self._call_idx += 1
        if self._receipts is not None:
            try:
                self._receipts.record_verifier_command(self._call_idx, tool_name, arguments, envelope)
            except Exception:  # noqa: BLE001 - receipts must never break verification
                pass
        return envelope

    def _rejected(self, cmd: str, message: str) -> ObservationEnvelope:
        return build_envelope(
            {
                "tool": "run_command",
                "exit_code": 1,
                "duration_sec": 0.0,
                "cwd": str(self._ctx.executor.workspace_root),
                "stdout": "",
                "stderr": message,
                "error": {
                    "kind": "verification_read_only_violation",
                    "message": message,
                    "reason_code": "verification_read_only_violation",
                    "command": cmd,
                },
            },
            raw_log_dir=self._ctx.raw_log_dir,
        )

    def run_command(self, cmd: str, timeout_sec: int = 120, cwd: str | None = None) -> ObservationEnvelope:
        try:
            tokens = shlex.split(cmd, posix=True)
        except ValueError:
            envelope = self._rejected(cmd, "verifier inspection command could not be parsed")
            return self._record("run_command", {"cmd": cmd, "timeout_sec": timeout_sec, "cwd": cwd}, envelope)

        if not tokens or any(token in self._DISALLOWED_TOKENS for token in tokens):
            envelope = self._rejected(cmd, "verifier inspection is read-only; command rejected")
            return self._record("run_command", {"cmd": cmd, "timeout_sec": timeout_sec, "cwd": cwd}, envelope)

        # Split on pipe tokens into segments; each segment's leading token must
        # be an allowed read-only binary.
        segments: list[list[str]] = [[]]
        for token in tokens:
            if token == "|":
                segments.append([])
            else:
                segments[-1].append(token)
        if any(not segment or segment[0] not in self._ALLOWED_BINARIES for segment in segments):
            envelope = self._rejected(cmd, "verifier inspection is read-only; command rejected")
            return self._record("run_command", {"cmd": cmd, "timeout_sec": timeout_sec, "cwd": cwd}, envelope)

        envelope = self._ctx.run_command(cmd, timeout_sec=timeout_sec, cwd=cwd)
        return self._record("run_command", {"cmd": cmd, "timeout_sec": timeout_sec, "cwd": cwd}, envelope)

    def read_file(self, path: str, offset: int | None = None, limit: int | None = None) -> ObservationEnvelope:
        envelope = self._ctx.read_file(path, offset=offset, limit=limit)
        return self._record("read_file", {"path": path, "offset": offset, "limit": limit}, envelope)

    def job_status(self, job_id: str) -> ObservationEnvelope:
        envelope = self._ctx.job_status(job_id)
        return self._record("job_status", {"job_id": job_id}, envelope)

    def session_read(self, session_id: str) -> ObservationEnvelope:
        envelope = self._ctx.session_read(session_id)
        return self._record("session_read", {"session_id": session_id}, envelope)


def _execute_tool_calls(
    *,
    response: Any,
    response_messages: list[dict[str, Any]],
    step: int,
    executor: ContainerExecutor,
    ctx: ExecutionContext,
    context: ContextManager,
    receipts: ReceiptWriter,
    mirror: Mirror,
    tool_invocations: list[ToolInvocationRecord],
    mirror_notes: list[MirrorNote],
    failure_tracker: dict[str, Any],
    recoveries: int,
    no_delta_streaks: int,
    job_ids: list[str],
    session_ids: list[str],
    plan_text: str | None,
    elapsed_sec: float,
    remaining_sec: float | None,
    model_request_index: int,
) -> tuple[dict[str, Any], int, int, list[str], tuple[dict[str, Any], ObservationEnvelope] | None]:
    most_recent_checks: list[str] = []
    task_done_call: tuple[dict[str, Any], ObservationEnvelope] | None = None

    for tool_call in getattr(response, "tool_calls", ()) or ():
        tool_name = _tool_call_name(tool_call)
        tool_call_id = tool_call.get("id")
        if tool_name is None:
            envelope = build_envelope(
                {
                    "tool": "unknown",
                    "exit_code": 1,
                    "duration_sec": 0.0,
                    "cwd": str(executor.workspace_root),
                    "stdout": "",
                    "stderr": "malformed tool call: missing name",
                    "error": {
                        "kind": "malformed_tool_call",
                        "message": "tool call is missing a name",
                        "reason_code": "malformed_tool_call",
                    },
                },
                raw_log_dir=ctx.raw_log_dir,
            )
            context.append_turn(_envelope_to_message("unknown", tool_call_id, envelope))
            continue

        arguments = _parse_tool_call_arguments(tool_call)
        signature = _action_signature(tool_name, arguments)
        blind_retry = tool_name == "run_command" and failure_tracker.get("last_failure_signature") == signature
        if blind_retry:
            envelope = _build_blind_retry_blocked_envelope(
                tool_name, arguments, str(executor.workspace_root), raw_log_dir=ctx.raw_log_dir
            )
            failure_tracker = {"last_failure_signature": None, "streak": 0}
        else:
            try:
                envelope = dispatch(tool_name, arguments, ctx)
            except Exception as exc:  # noqa: BLE001
                envelope = build_envelope(
                    {
                        "tool": tool_name,
                        "exit_code": 1,
                        "duration_sec": 0.0,
                        "cwd": str(executor.workspace_root),
                        "stdout": "",
                        "stderr": str(exc),
                        "error": {
                            "kind": "dispatch_error",
                            "message": str(exc),
                            "reason_code": "dispatch_error",
                            "tool_name": tool_name,
                        },
                    },
                    raw_log_dir=ctx.raw_log_dir,
                )

        failed = _envelope_failed(envelope)
        if failed:
            prior_signature = failure_tracker.get("last_failure_signature")
            streak = failure_tracker.get("streak", 0) + 1 if prior_signature == signature else 1
            failure_tracker = {"last_failure_signature": signature, "streak": streak}
        else:
            if failure_tracker.get("last_failure_signature") is not None:
                recoveries += 1
            failure_tracker = {"last_failure_signature": None, "streak": 0}

        context.append_turn(_envelope_to_message(tool_name, tool_call_id, envelope))
        tool_invocations.append(ToolInvocationRecord(step=step, tool_name=tool_name, arguments=arguments, envelope=envelope))
        receipts.record_step(
            len(tool_invocations),
            request={"messages_len": len(response_messages)},
            response={"text": getattr(response, "text", "")},
            action={"tool": tool_name, "arguments": arguments},
            raw_output=_envelope_to_message(tool_name, tool_call_id, envelope),
        )

        if tool_name == "start_job":
            job_id_arg = arguments.get("job_id")
            stdout = envelope.stdout_head
            started_job_id = job_id_arg
            if started_job_id is None and "started job " in stdout:
                started_job_id = stdout.split("started job ", 1)[1].split(" ", 1)[0]
            if started_job_id and started_job_id not in job_ids:
                job_ids.append(started_job_id)
        if tool_name == "session_start":
            session_id_arg = arguments.get("session_id")
            if session_id_arg and session_id_arg not in session_ids:
                session_ids.append(session_id_arg)

        context.delta_state = ctx.last_snapshot
        note = mirror.observe(
            signature,
            ctx.last_delta_report,
            established_facts=_collect_established_facts(context),
            unused_affordances=_unused_affordances(),
            fuel_gauge_text=(
                json.dumps(
                    {
                        "elapsed_sec": round(elapsed_sec, 3),
                        "remaining_sec": None if remaining_sec is None else round(remaining_sec, 3),
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=True,
                )
            ),
        )
        if note is not None:
            mirror_notes.append(note)
            no_delta_streaks += 1
            context.append_turn({"role": "system", "content": f"[mirror_note]\n{note.text}"})

        if tool_name == "task_done":
            task_done_call = (arguments, envelope)
            most_recent_checks = [str(item) for item in arguments.get("checks", [])]

    return failure_tracker, recoveries, no_delta_streaks, most_recent_checks, task_done_call



def _collect_tail_events(
    *,
    ctx: "ExecutionContext",
    job_registry: JobRegistry,
    job_ids: list[str],
    seen_artifacts: set[str],
    known_job_status: dict[str, tuple[bool, int | None]],
) -> list[str]:
    """Spec §6.3: artifact/service events since the last tail render.

    New artifacts written and job started/died transitions. Mutates
    `seen_artifacts` / `known_job_status` to track what has already been
    surfaced.
    """
    events: list[str] = []
    for path in sorted(ctx.last_delta_report.added_paths):
        if path in seen_artifacts:
            continue
        seen_artifacts.add(path)
        events.append(f"artifact_written:{path}")

    for job_id in job_ids:
        try:
            status = job_registry.status(job_id)
        except KeyError:
            continue
        current = (status.alive, status.exit_code)
        previous = known_job_status.get(job_id)
        if previous is None:
            events.append(f"job_started:{job_id}")
        elif previous[0] and not current[0]:
            events.append(f"job_died:{job_id} exit_code={current[1]}")
        known_job_status[job_id] = current

    return events


def _sync_fact_ledger_state(context: ContextManager, ctx: "ExecutionContext") -> None:
    """Merge ExecutionContext's cumulative run-level facts (installed packages,
    nonzero exits) into the delta state used by compactor.build_fact_ledger
    (spec §6.5)."""
    if context.delta_state is None:
        return
    context.delta_state = dataclass_replace(
        context.delta_state,
        installed_packages=tuple(ctx.installed_packages),
        nonzero_exits=tuple(ctx.nonzero_exits),
    )

def run_aether2_loop(task: TaskSpec, model_client: Any, executor: ContainerExecutor, *, deadline_ts: float) -> RunResult:
    """Run the orientation-to-finalize continuity loop for a single task against the live workspace."""

    if model_client is None:
        raise ValueError(
            "run_aether2_loop requires a model_client (e.g. runner.aether2.model_client.Aether2ModelClient); "
            "got None. Construct one from a model route before calling the loop."
        )

    started_at = time.monotonic()

    state_dir = task.workspace_root / ".aether2" / "state"
    raw_log_dir = task.workspace_root / ".aether2" / "raw_logs"
    receipts_root = task.task_dir / ".aether2" / "host_receipts"

    job_registry = JobRegistry(state_dir, backend=executor.backend, container_path_fn=executor.to_container_path)
    session_registry = SessionRegistry(state_dir, backend=executor.backend)
    ctx = ExecutionContext(
        executor=executor,
        job_registry=job_registry,
        session_registry=session_registry,
        raw_log_dir=raw_log_dir,
    )
    receipts = ReceiptWriter(receipts_root)

    orientation_snapshot = orient(executor)
    orientation_dict = orientation_snapshot.as_dict()

    context = ContextManager(delta_state=ctx.last_snapshot)
    context.build_prefix(
        system_prompt=SYSTEM_PROMPT,
        task_instruction=task.instruction,
        orientation=orientation_dict,
        tool_schemas=TOOL_SCHEMAS,
    )

    mirror = Mirror()
    failure_tracker: dict[str, Any] = {"last_failure_signature": None, "streak": 0}
    job_ids: list[str] = []
    session_ids: list[str] = []
    seen_artifacts: set[str] = set()
    known_job_status: dict[str, tuple[bool, int | None]] = {}
    pending_tail_events: list[str] = []
    tool_invocations: list[ToolInvocationRecord] = []
    mirror_notes: list[MirrorNote] = []
    discrepancy_reports: list[Any] = []

    model_calls = 0
    tokens_cached = 0
    tokens_fresh = 0
    total_cost = 0.0
    compaction_count = 0
    verification_rounds = 0
    recoveries = 0
    no_delta_streaks = 0

    finalize_reason: str | None = None
    finalize_summary = ""
    finalize_pass = False
    most_recent_checks: list[str] = []

    plan_text: str | None = None

    step = 0
    while step < STEP_CAP:
        elapsed_sec = time.monotonic() - started_at
        remaining_sec = deadline_ts - time.time()
        if remaining_sec <= 0:
            finalize_reason = "budget_exhaustion"
            break

        step += 1

        if context.transcript:
            window_used_frac = (context.prefix.token_estimate + _estimate_transcript_tokens(context)) / CONTEXT_WINDOW_TOKENS
            if should_rebase(window_used_frac, False):
                _sync_fact_ledger_state(context, ctx)
                context = rebase(context, model_client)
                compaction_count += 1
                # compactor.rebase() always issues exactly one model call (handoff summarization);
                # account for it in model_calls (and token counters, if usage is surfaced).
                model_calls += 1

        messages = [*context.message_history()]
        tail_text = context.render_tail(
            _build_tail_state(
                plan_text=plan_text,
                elapsed_sec=elapsed_sec,
                remaining_sec=remaining_sec,
                mirror=mirror,
                streak=mirror.streak,
                job_registry=job_registry,
                session_registry=session_registry,
                job_ids=job_ids,
                session_ids=session_ids,
                note=None,
                events=pending_tail_events,
            )
        )
        if tail_text:
            messages = [*messages, {"role": "system", "content": tail_text}]
        pending_tail_events = []

        response = model_client.call(messages, TOOL_SCHEMAS, cache_prefix_len=context.prefix.token_estimate)
        model_calls += 1
        receipts.record_model_exchange(model_calls, messages, response)
        usage = _response_usage(response)
        tokens_cached += int(usage.get("cached_input_tokens", 0))
        tokens_fresh += int(usage.get("fresh_input_tokens", 0))
        total_cost += _response_cost(response)

        assistant_message: dict[str, Any] = {"role": "assistant", "content": response.text}
        if response.tool_calls:
            assistant_message["tool_calls"] = [dict(tool_call) for tool_call in response.tool_calls]
        context.append_turn(assistant_message)

        plan_text = _update_plan_text(plan_text, response.text)

        if _model_requested_rebase(response.text, response.tool_calls):
            _sync_fact_ledger_state(context, ctx)
            context = rebase(context, model_client)
            compaction_count += 1
            model_calls += 1
            continue

        if _model_requested_verification(response.text, response.tool_calls):
            finalize_reason = "verification_requested"
            finalize_summary = response.text
            break

        if not response.tool_calls:
            finalize_reason = "implicit_stop"
            finalize_summary = response.text
            break

        failure_tracker, recoveries, no_delta_streaks, new_checks, task_done_call = _execute_tool_calls(
            response=response,
            response_messages=messages,
            step=step,
            executor=executor,
            ctx=ctx,
            context=context,
            receipts=receipts,
            mirror=mirror,
            tool_invocations=tool_invocations,
            mirror_notes=mirror_notes,
            failure_tracker=failure_tracker,
            recoveries=recoveries,
            no_delta_streaks=no_delta_streaks,
            job_ids=job_ids,
            session_ids=session_ids,
            plan_text=plan_text,
            elapsed_sec=elapsed_sec,
            remaining_sec=remaining_sec,
            model_request_index=model_calls,
        )
        if new_checks:
            most_recent_checks = new_checks

        pending_tail_events.extend(
            _collect_tail_events(
                ctx=ctx,
                job_registry=job_registry,
                job_ids=job_ids,
                seen_artifacts=seen_artifacts,
                known_job_status=known_job_status,
            )
        )

        if task_done_call is not None:
            finalize_reason = "task_done"
            finalize_summary = str(task_done_call[0].get("summary", ""))
            break

    if finalize_reason is None:
        finalize_reason = "budget_exhaustion"
        finalize_summary = "step cap safety rail reached before an explicit completion claim"

    if finalize_reason == "budget_exhaustion":
        check_results = replay_checks(most_recent_checks, executor) if most_recent_checks else []
        closing_messages = [
            *context.message_history(),
            {
                "role": "system",
                "content": (
                    "Wall-clock deadline reached. Here are the results of replaying your "
                    "most recently declared checks (if any). This is your final turn."
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"checks_results": [result.__dict__ for result in check_results]},
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=True,
                ),
            },
        ]
        response = model_client.call(closing_messages, [], cache_prefix_len=context.prefix.token_estimate)
        model_calls += 1
        receipts.record_model_exchange(model_calls, closing_messages, response)
        usage = _response_usage(response)
        tokens_cached += int(usage.get("cached_input_tokens", 0))
        tokens_fresh += int(usage.get("fresh_input_tokens", 0))
        total_cost += _response_cost(response)
        finalize_summary = response.text
        finalize_pass = bool(check_results) and all(
            result.exit_code == 0 for result in check_results
        )
    else:
        rounds = 0
        claim_summary = finalize_summary
        claim_checks = most_recent_checks
        while rounds < MAX_VERIFICATION_ROUNDS:
            rounds += 1
            verification_rounds += 1
            check_results = replay_checks(claim_checks, executor) if claim_checks else []
            curr_snapshot = delta_snapshot(task.workspace_root)
            workspace_diff = delta_diff(ctx.last_snapshot, curr_snapshot)
            ctx.last_snapshot = curr_snapshot
            context.delta_state = curr_snapshot

            action_digest = {
                "tool_calls": [
                    {"step": record.step, "tool": record.tool_name, "arguments": record.arguments}
                    for record in tool_invocations[-20:]
                ]
            }
            discrepancy_report = verify_fresh_context(
                task.instruction,
                orientation_dict,
                _diff_to_dict(workspace_diff),
                {"summary": claim_summary, "trigger": finalize_reason},
                check_results,
                action_digest,
                model_client,
                inspection_ctx=_ReadOnlyVerificationContext(ctx, receipts),
            )
            discrepancy_reports.append(discrepancy_report)

            remaining_sec = deadline_ts - time.time()
            if not discrepancy_report.has_discrepancies or remaining_sec <= 0 or rounds >= MAX_VERIFICATION_ROUNDS:
                finalize_pass = not discrepancy_report.has_discrepancies
                finalize_summary = claim_summary
                break

            report_message = {
                "role": "user",
                "content": json.dumps(
                    _clean_hidden_refs(
                        {
                            "verification_report": {
                                "requirements": [item.__dict__ for item in discrepancy_report.requirements],
                                "reason_codes": list(discrepancy_report.reason_codes),
                                "summary": discrepancy_report.summary,
                            },
                            "checks_results": [result.__dict__ for result in check_results],
                            "time_remaining_sec": remaining_sec,
                        }
                    ),
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=True,
                ),
            }
            context.append_turn(report_message)

            messages = [*context.message_history()]
            response = model_client.call(messages, TOOL_SCHEMAS, cache_prefix_len=context.prefix.token_estimate)
            model_calls += 1
            receipts.record_model_exchange(model_calls, messages, response)
            usage = _response_usage(response)
            tokens_cached += int(usage.get("cached_input_tokens", 0))
            tokens_fresh += int(usage.get("fresh_input_tokens", 0))
            total_cost += _response_cost(response)

            assistant_message = {"role": "assistant", "content": response.text}
            if response.tool_calls:
                assistant_message["tool_calls"] = [dict(tool_call) for tool_call in response.tool_calls]
            context.append_turn(assistant_message)

            claim_summary = response.text
            if _model_requested_rebase(response.text, response.tool_calls):
                _sync_fact_ledger_state(context, ctx)
                context = rebase(context, model_client)
                compaction_count += 1
                model_calls += 1
                continue

            failure_tracker, recoveries, no_delta_streaks, new_checks, new_task_done = _execute_tool_calls(
                response=response,
                response_messages=messages,
                step=step,
                executor=executor,
                ctx=ctx,
                context=context,
                receipts=receipts,
                mirror=mirror,
                tool_invocations=tool_invocations,
                mirror_notes=mirror_notes,
                failure_tracker=failure_tracker,
                recoveries=recoveries,
                no_delta_streaks=no_delta_streaks,
                job_ids=job_ids,
                session_ids=session_ids,
                plan_text=plan_text,
                elapsed_sec=time.monotonic() - started_at,
                remaining_sec=remaining_sec,
                model_request_index=model_calls,
            )
            if new_task_done is not None:
                claim_summary = str(new_task_done[0].get("summary", claim_summary))
            if new_checks:
                claim_checks = new_checks
            if new_task_done is None and not response.tool_calls:
                # implicit stop during a verification round: treat as resubmission with no new checks
                continue

    job_survival = all(_job_alive_safe(job_registry, job_id) for job_id in job_ids) if job_ids else True
    session_survival = (
        all(sid in session_registry.list_session_ids() for sid in session_ids) if session_ids else True
    )

    wall_time = time.monotonic() - started_at

    return RunResult(
        verifier_clean=finalize_pass,
        finalize_reason=finalize_reason,
        summary=finalize_summary,
        steps=step,
        model_calls=model_calls,
        tokens_cached=tokens_cached,
        tokens_fresh=tokens_fresh,
        cost=total_cost,
        wall_time=wall_time,
        no_delta_streaks=no_delta_streaks,
        verification_rounds=verification_rounds,
        recoveries=recoveries,
        compaction_count=compaction_count,
        job_survival=job_survival,
        session_survival=session_survival,
        tool_invocations=tool_invocations,
        mirror_notes=mirror_notes,
        discrepancy_reports=discrepancy_reports,
    )


def _update_plan_text(plan_text: str | None, response_text: str) -> str | None:
    """Track the model-owned plan (spec §6.3 tail telemetry).

    The first non-empty assistant `response.text` of the run becomes the initial plan.
    Thereafter, if an assistant turn's first line starts with "PLAN" (case-insensitive),
    its full text replaces the plan. No other parsing is performed.
    """
    if not response_text:
        return plan_text
    first_line = response_text.splitlines()[0] if response_text.splitlines() else ""
    if first_line.strip().upper().startswith("PLAN"):
        return response_text
    if plan_text is None:
        return response_text
    return plan_text


def _estimate_transcript_tokens(context: ContextManager) -> int:
    rendered = json.dumps(context.transcript, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return len(rendered.encode("utf-8")) // 4


def _diff_to_dict(report: Any) -> dict[str, Any]:
    return {
        "files_changed": [item.__dict__ for item in report.files_changed],
        "added_paths": list(report.added_paths),
        "modified_paths": list(report.modified_paths),
        "deleted_paths": list(report.deleted_paths),
        "artifact_registry_changed": report.artifact_registry_changed,
        "service_registry_changed": report.service_registry_changed,
        "process_registry_changed": report.process_registry_changed,
        "job_registry_changed": report.job_registry_changed,
        "session_registry_changed": report.session_registry_changed,
    }


def _job_alive_safe(job_registry: JobRegistry, job_id: str) -> bool:
    try:
        status = job_registry.status(job_id)
    except KeyError:
        return False
    return status.alive or status.exit_code == 0


__all__ = ["ExecutionContext", "RunResult", "ToolInvocationRecord", "run_aether2_loop"]
