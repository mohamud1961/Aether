"""Aether-2 continuity harness package."""

from runner.aether2.bridge_harbor import TaskSpec, run_task_via_harbor
from runner.aether2.compactor import build_fact_ledger, rebase, should_rebase
from runner.aether2.context import ContextManager, Prefix
from runner.aether2.delta import DeltaReport, StateSnapshot, diff, snapshot
from runner.aether2.envelope import ObservationEnvelope, build_envelope
from runner.aether2.executor import ContainerExecutor, RawResult
from runner.aether2.jobs import JobRegistry, JobStatus
from runner.aether2.loop import ExecutionContext, RunResult, ToolInvocationRecord, run_aether2_loop
from runner.aether2.metrics import Scorecard, build_scorecard
from runner.aether2.mirror import Mirror, MirrorNote
from runner.aether2.model_client import Aether2ModelClient, ModelResponse
from runner.aether2.orientation import OrientationSnapshot, orient
from runner.aether2.prompts import DOCTRINE_LINES, HANDOFF_TEMPLATE, SYSTEM_PROMPT
from runner.aether2.receipts import ReceiptWriter
from runner.aether2.sessions import SessionRegistry
from runner.aether2.tools import TOOL_NAMES, TOOL_SCHEMAS, dispatch
from runner.aether2.verify import CheckResult, DiscrepancyReport, replay_checks, verify_fresh_context

__all__ = [
    "Aether2ModelClient",
    "CheckResult",
    "ContainerExecutor",
    "ContextManager",
    "DOCTRINE_LINES",
    "DeltaReport",
    "DiscrepancyReport",
    "ExecutionContext",
    "HANDOFF_TEMPLATE",
    "JobRegistry",
    "JobStatus",
    "Mirror",
    "MirrorNote",
    "ModelResponse",
    "ObservationEnvelope",
    "OrientationSnapshot",
    "Prefix",
    "RawResult",
    "ReceiptWriter",
    "RunResult",
    "SYSTEM_PROMPT",
    "Scorecard",
    "SessionRegistry",
    "StateSnapshot",
    "TOOL_NAMES",
    "TOOL_SCHEMAS",
    "TaskSpec",
    "ToolInvocationRecord",
    "build_envelope",
    "build_fact_ledger",
    "build_scorecard",
    "diff",
    "dispatch",
    "orient",
    "rebase",
    "replay_checks",
    "run_aether2_loop",
    "run_task_via_harbor",
    "should_rebase",
    "snapshot",
    "verify_fresh_context",
]
