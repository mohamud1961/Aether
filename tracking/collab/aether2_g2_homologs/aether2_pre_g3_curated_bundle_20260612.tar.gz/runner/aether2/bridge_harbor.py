"""Harbor-style task mounting and production runtime wiring for Aether-2."""

from __future__ import annotations

from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
import json
import os
import shutil
import subprocess
import tomllib
import uuid

from runner.aether2.executor import ContainerBackend, ContainerExecutor
from runner.aether2.model_client import Aether2ModelClient
from runner.model_client import make_azure_gpt53_codex_route_from_env, make_azure_gpt54_mini_route_from_env


@dataclass(frozen=True)
class TaskSpec:
    task_id: str
    instruction: str
    task_dir: Path
    workspace_root: Path
    artifacts_dir: Path


@dataclass(frozen=True)
class HarborRuntime:
    """The live model client and executor mounted for one Harbor-style task run."""

    model_client: Any
    executor: ContainerExecutor


class HarborRuntimeHandle(AbstractContextManager["HarborRuntime"]):
    """Context manager that owns the container lifecycle for one Aether-2 task run."""

    def __init__(self, runtime: HarborRuntime, *, container_id: str | None = None) -> None:
        self.runtime = runtime
        self.container_id = container_id

    def __enter__(self) -> HarborRuntime:
        return self.runtime

    def __exit__(self, exc_type, exc, tb) -> bool:
        # Intentionally a no-op: Harbor grades the task AFTER the agent
        # process exits, and declared services/jobs/sessions must remain
        # running inside the container for that grading pass. Do NOT stop
        # the container or kill in-container process trees here. Container
        # lifecycle (if any cleanup is ever needed) is owned by the
        # orchestration layer, after grading completes, not by this harness.
        return False


class _MissingModelClient:
    def call(self, messages, tools, *, cache_prefix_len):
        raise RuntimeError("Aether-2 Harbor runtime could not construct a production model client from the environment.")


def run_task_via_harbor(task_dir: Path, loop_fn: Callable[..., Any], *, deadline_ts: float) -> Any:
    resolved_task_dir = task_dir.resolve()
    instruction_path = _find_first_existing(
        resolved_task_dir / "instruction.txt",
        resolved_task_dir / "instruction.md",
        resolved_task_dir / "task.md",
        resolved_task_dir / "prompt.txt",
    )
    if instruction_path is None:
        raise FileNotFoundError(f"no instruction file found in {resolved_task_dir}")

    workspace_root = resolved_task_dir / "workspace"
    artifacts_dir = resolved_task_dir / "artifacts"
    _prepare_workspace_dir(workspace_root)
    _prepare_artifacts_dir(artifacts_dir)

    task = TaskSpec(
        task_id=resolved_task_dir.name,
        instruction=instruction_path.read_text(encoding="utf-8"),
        task_dir=resolved_task_dir,
        workspace_root=workspace_root,
        artifacts_dir=artifacts_dir,
    )
    with _build_runtime(task) as runtime:
        result = loop_fn(task, runtime.model_client, runtime.executor, deadline_ts=deadline_ts)
        result = _attach_grader_reward(result, runtime.executor)
    _sync_workspace_artifacts(workspace_root, artifacts_dir)
    _write_result_artifact(artifacts_dir, result)
    _assert_artifacts_synced(artifacts_dir)
    return result


def _attach_grader_reward(result: Any, executor: ContainerExecutor) -> Any:
    """Populate `grader_reward` on a `RunResult`-like object from Harbor's reward file, if present.

    Harbor (when present) writes its grader's reward to `/logs/verifier/reward.txt` inside the
    task container/workspace, AFTER the agent's own run. This is advisory-verifier-independent
    grader authority (see C6): `verifier_clean` never masquerades as this value, and this value
    is `None` when no reward file exists (e.g. local homolog runs with no grader).
    """
    if not hasattr(result, "grader_reward"):
        return result
    reward_value: float | None = None
    try:
        reward_path = executor.resolve_workspace_path("logs/verifier/reward.txt")
    except ValueError:
        reward_path = None
    if reward_path is not None and reward_path.exists():
        try:
            reward_value = float(reward_path.read_text(encoding="utf-8").strip())
        except (ValueError, OSError):
            reward_value = None
    if reward_value is None:
        return result
    try:
        from dataclasses import replace as _dc_replace

        return _dc_replace(result, grader_reward=reward_value)
    except TypeError:
        return result


def _build_runtime(task: TaskSpec) -> HarborRuntimeHandle:
    container_image = _task_container_image(task.task_dir)
    if container_image:
        return _build_container_runtime(task, container_image=container_image)
    return _build_local_runtime(task)


def _build_container_runtime(task: TaskSpec, *, container_image: str) -> HarborRuntimeHandle:
    container_name = f"aether2-{task.task_id}-{uuid.uuid4().hex[:10]}"
    run_command = _docker_run_command(task, container_name=container_name, container_image=container_image)
    completed = subprocess.run(run_command, capture_output=True, text=True, check=False)
    if completed.returncode != 0 and (task.task_dir / "Dockerfile").exists():
        build = subprocess.run(
            ["docker", "build", "-t", container_image, str(task.task_dir)],
            capture_output=True,
            text=True,
            check=False,
        )
        if build.returncode != 0:
            raise RuntimeError(f"failed to build task container: {build.stderr.strip()}")
        completed = subprocess.run(run_command, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"failed to start task container: {completed.stderr.strip()}")
    container_id = completed.stdout.strip()
    if not container_id:
        raise RuntimeError("failed to start task container: empty container id")

    executor = ContainerExecutor(
        workspace_root=task.workspace_root,
        backend=ContainerBackend(
            kind="docker",
            container_id=container_id,
            container_workspace_root="/app",
        ),
    )
    return HarborRuntimeHandle(
        HarborRuntime(
            model_client=_build_model_client(),
            executor=executor,
        ),
        container_id=container_id,
    )


def _docker_run_command(task: TaskSpec, *, container_name: str, container_image: str) -> list[str]:
    run_command = [
        "docker",
        "run",
        "-d",
        "--name",
        container_name,
        "-w",
        "/app",
        "-v",
        f"{task.workspace_root}:{'/app'}",
        container_image,
        "sleep",
        "infinity",
    ]
    return run_command


def _build_local_runtime(task: TaskSpec) -> HarborRuntimeHandle:
    executor = ContainerExecutor(workspace_root=task.workspace_root)
    return HarborRuntimeHandle(
        HarborRuntime(
            model_client=_build_model_client(),
            executor=executor,
        )
    )


def _build_model_client() -> Any:
    try:
        deployment_hint = str(
            os.environ.get("AETHER2_MODEL_TIER")
            or os.environ.get("AETHER2_MODEL")
            or os.environ.get("AZURE_OPENAI_GPT54_MINI_DEPLOYMENT")
            or os.environ.get("AZURE_OPENAI_GPT53_CODEX_DEPLOYMENT")
            or ""
        ).lower()
        if "5.3" in deployment_hint or "codex" in deployment_hint:
            route = make_azure_gpt53_codex_route_from_env(request_settings={"temperature": 0})
        else:
            route = make_azure_gpt54_mini_route_from_env(request_settings={"temperature": 0})
        return Aether2ModelClient(route)
    except Exception:
        return _MissingModelClient()


def _task_container_image(task_dir: Path) -> str | None:
    task_toml = task_dir / "task.toml"
    if not task_toml.exists():
        return None
    data = tomllib.loads(task_toml.read_text(encoding="utf-8"))
    environment = data.get("environment")
    if not isinstance(environment, dict):
        return None
    image = environment.get("docker_image")
    if not isinstance(image, str) or not image.strip():
        return None
    return image.strip()


def _find_first_existing(*paths: Path) -> Path | None:
    for path in paths:
        if path.exists() and path.is_file():
            return path
    return None


def _write_result_artifact(artifacts_dir: Path, result: Any) -> None:
    result_path = artifacts_dir / "result.json"
    payload = _json_safe(result)
    result_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _prepare_workspace_dir(workspace_root: Path) -> None:
    # Never delete pre-existing files: Harbor task fixtures may already be
    # staged in the workspace directory. Create-if-missing only.
    workspace_root.mkdir(parents=True, exist_ok=True)


def _prepare_artifacts_dir(artifacts_dir: Path) -> None:
    # Never delete pre-existing files: create-if-missing only (see
    # _prepare_workspace_dir).
    artifacts_dir.mkdir(parents=True, exist_ok=True)


def _sync_workspace_artifacts(workspace_root: Path, artifacts_dir: Path) -> None:
    for path in sorted(workspace_root.rglob("*")):
        if not path.is_file():
            continue
        relative_path = path.relative_to(workspace_root)
        destination = artifacts_dir / relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)


def _assert_artifacts_synced(artifacts_dir: Path) -> None:
    files = [path for path in artifacts_dir.rglob("*") if path.is_file()]
    if not files:
        raise RuntimeError(f"incomplete artifact sync-back: no files found under {artifacts_dir}")
    if not any(path.name == "result.json" for path in files):
        raise RuntimeError(f"incomplete artifact sync-back: missing result.json under {artifacts_dir}")
    if not any(_is_visible_synced_artifact(path, artifacts_dir) for path in files):
        raise RuntimeError(f"incomplete artifact sync-back: no visible synced task artifacts under {artifacts_dir}")
    for path in files:
        if path.stat().st_size <= 0:
            raise RuntimeError(f"incomplete artifact sync-back: empty artifact {path}")


def _is_visible_synced_artifact(path: Path, artifacts_dir: Path) -> bool:
    if path.name == "result.json":
        return False
    relative_parts = path.relative_to(artifacts_dir).parts
    return all(not part.startswith(".") for part in relative_parts)


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    if hasattr(value, "__dict__"):
        return _json_safe(vars(value))
    if isinstance(value, Path):
        return os.fspath(value)
    return str(value)


__all__ = ["HarborRuntime", "TaskSpec", "run_task_via_harbor"]
