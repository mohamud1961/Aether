"""Model-invisible receipt capture for Aether-2."""

from __future__ import annotations

import base64
import hashlib
import json
import math
from dataclasses import dataclass, fields, is_dataclass
from collections.abc import Mapping
from pathlib import Path
from types import SimpleNamespace
from typing import Any

__all__ = ["ReceiptWriter"]

_MAX_LABEL_LEN = 40


def _safe_action_name(action: Any) -> str:
    text = _label_for_path(action)
    safe = []
    for char in text:
        if char.isalnum() or char in {"_", "-", "."}:
            safe.append(char)
        else:
            safe.append("_")
    sanitized = "".join(safe)
    if len(sanitized) <= _MAX_LABEL_LEN:
        return sanitized
    digest = hashlib.sha256(sanitized.encode("utf-8")).hexdigest()[:8]
    return f"{sanitized[:_MAX_LABEL_LEN]}_{digest}"


def _type_name(value: Any) -> str:
    cls = value.__class__
    return f"{cls.__module__}.{cls.__qualname__}"


def _normalize_key(value: Any) -> str:
    normalized = _normalize_for_json(value)
    if isinstance(normalized, str):
        return normalized
    return json.dumps(normalized, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _stable_sort_key(value: Any) -> str:
    normalized = _normalize_for_json(value)
    return json.dumps(normalized, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _normalize_for_json(value: Any, _stack: set[int] | None = None) -> Any:
    if _stack is None:
        _stack = set()

    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if math.isfinite(value):
            return value
        return {"__type__": "builtins.float", "value": repr(value)}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes):
        return {"__type__": "builtins.bytes", "base64": base64.b64encode(value).decode("ascii")}
    if isinstance(value, bytearray):
        return {"__type__": "builtins.bytearray", "base64": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, memoryview):
        return {"__type__": "builtins.memoryview", "base64": base64.b64encode(value.tobytes()).decode("ascii")}
    if isinstance(value, SimpleNamespace):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            fields_map = {key: _normalize_for_json(val, _stack) for key, val in vars(value).items()}
            return {"__type__": _type_name(value), "fields": fields_map}
        finally:
            _stack.remove(marker)
    if is_dataclass(value) and not isinstance(value, type):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            fields_map = {}
            for field in fields(value):
                fields_map[field.name] = _normalize_for_json(getattr(value, field.name), _stack)
            return {"__type__": _type_name(value), "fields": fields_map}
        finally:
            _stack.remove(marker)
    if isinstance(value, Mapping):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            items: list[tuple[str, Any]] = []
            for key, item in value.items():
                items.append((_normalize_key(key), _normalize_for_json(item, _stack)))
            items.sort(key=lambda pair: pair[0])
            return {key: item for key, item in items}
        finally:
            _stack.remove(marker)
    if isinstance(value, tuple):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            return [_normalize_for_json(item, _stack) for item in value]
        finally:
            _stack.remove(marker)
    if isinstance(value, list):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            return [_normalize_for_json(item, _stack) for item in value]
        finally:
            _stack.remove(marker)
    if isinstance(value, set):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            normalized_items = [_normalize_for_json(item, _stack) for item in value]
            normalized_items.sort(key=_stable_sort_key)
            return normalized_items
        finally:
            _stack.remove(marker)
    if hasattr(value, "__dict__") and vars(value):
        marker = id(value)
        if marker in _stack:
            return {"__type__": _type_name(value), "cycle": True}
        _stack.add(marker)
        try:
            fields_map = {key: _normalize_for_json(val, _stack) for key, val in vars(value).items()}
            return {"__type__": _type_name(value), "fields": fields_map}
        finally:
            _stack.remove(marker)
    return {"__type__": _type_name(value), "repr": repr(value)}


def _label_for_path(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        for key in ("name", "tool", "tool_name", "action"):
            raw = value.get(key)
            if isinstance(raw, str) and raw.strip():
                return raw
        return json.dumps(_normalize_for_json(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, SimpleNamespace):
        for key in ("name", "tool", "tool_name", "action"):
            raw = getattr(value, key, None)
            if isinstance(raw, str) and raw.strip():
                return raw
        return json.dumps(_normalize_for_json(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    if hasattr(value, "name"):
        raw = getattr(value, "name")
        if isinstance(raw, str) and raw.strip():
            return raw
    return str(value)


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


@dataclass
class ReceiptWriter:
    """Write per-step receipts and raw payloads beneath a private audit root."""

    root: Path

    def __post_init__(self) -> None:
        self.root = Path(self.root)
        self.receipts_dir = self.root / "receipts"
        self.raw_dir = self.root / "raw"
        self.receipts_dir.mkdir(parents=True, exist_ok=True)
        self.raw_dir.mkdir(parents=True, exist_ok=True)

    def record_step(self, step_idx: int, request: Any, response: Any, action: Any, raw_output: Any) -> Path:
        action_name = _safe_action_name(action)
        receipt_id = f"{step_idx:04d}_action_{action_name}"
        receipt_path = self.receipts_dir / f"{receipt_id}.json"
        raw_step_dir = self.raw_dir / receipt_id

        def write_raw_value(path: Path, value: Any) -> None:
            if value is None:
                _write_text(path, "")
                return
            if isinstance(value, bytes):
                _write_bytes(path, value)
                return
            if isinstance(value, bytearray):
                _write_bytes(path, bytes(value))
                return
            if isinstance(value, memoryview):
                _write_bytes(path, value.tobytes())
                return
            if isinstance(value, str):
                _write_text(path, value)
                return
            if isinstance(value, Path):
                _write_text(path, str(value))
                return
            if isinstance(value, (int, bool)) or (isinstance(value, float) and math.isfinite(value)):
                _write_text(path, str(value))
                return
            _write_text(path, json.dumps(_normalize_for_json(value), indent=2, sort_keys=True, ensure_ascii=False))

        raw_payload: dict[str, Any]
        if isinstance(raw_output, Mapping):
            raw_payload = {}
            for key, value in raw_output.items():
                normalized_key = _normalize_key(key)
                raw_payload[normalized_key] = value
                write_raw_value(raw_step_dir / _safe_action_name(normalized_key), value)
        else:
            raw_payload = {"output": raw_output}
            write_raw_value(raw_step_dir / "output", raw_output)

        payload = {
            "action": _normalize_for_json(action),
            "raw_output": _normalize_for_json(raw_payload),
            "receipt_id": receipt_id,
            "request": _normalize_for_json(request),
            "response": _normalize_for_json(response),
            "step": step_idx,
        }
        _write_json(receipt_path, payload)
        return receipt_path

    def record_model_exchange(self, call_idx: int, request_messages: list[Any], response: Any) -> Path:
        """Write a full-fidelity model exchange (request messages + response) for trace forensics.

        Model-invisible: writes ``model_exchange_<N>.json`` beneath the receipts root, capturing
        the complete `request_messages` list verbatim plus the full response text and tool calls.
        """
        receipt_path = self.receipts_dir / f"model_exchange_{call_idx}.json"
        response_text = getattr(response, "text", None)
        response_tool_calls = getattr(response, "tool_calls", None)
        payload = {
            "call_idx": call_idx,
            "request_messages": _normalize_for_json(request_messages),
            "response": {
                "text": _normalize_for_json(response_text),
                "tool_calls": _normalize_for_json(response_tool_calls),
            },
        }
        _write_json(receipt_path, payload)
        return receipt_path

    def record_verifier_command(self, call_idx: int, tool_name: str, arguments: dict[str, Any], envelope: Any) -> Path:
        """Record one verifier inspection call (C7 audit trail), allowed or rejected.

        Written as `verifier_inspection_<N>.json` beneath the receipts root. Every command the
        fresh-context verifier attempts during Layer 2 -- whether it passes the read-only
        allowlist or is rejected -- is recorded here for a full audit trail (best-effort
        structural read-only enforcement is not perfect in a shell, so the audit trail is the
        backstop).
        """
        receipt_path = self.receipts_dir / f"verifier_inspection_{call_idx}.json"
        payload = {
            "call_idx": call_idx,
            "tool_name": tool_name,
            "arguments": _normalize_for_json(arguments),
            "envelope": _normalize_for_json(envelope),
        }
        _write_json(receipt_path, payload)
        return receipt_path
