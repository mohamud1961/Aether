"""Generic provider tool schemas and dispatch helpers."""

from __future__ import annotations

from typing import Any

TOOL_NAMES: list[str] = [
    "run_command",
    "start_job",
    "job_status",
    "session_start",
    "session_send",
    "session_read",
    "read_file",
    "write_file",
    "wait",
    "task_done",
]


def _schema(name: str, description: str, properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
                "additionalProperties": False,
            },
        },
    }


TOOL_SCHEMAS: list[dict[str, Any]] = [
    _schema(
        "run_command",
        "Run a foreground command in the task container and return its typed observation.",
        {
            "cmd": {
                "type": "string",
                "description": "Shell command to execute in the task container.",
            },
            "timeout_sec": {
                "type": "integer",
                "default": 120,
                "minimum": 1,
                "description": "Maximum runtime in seconds.",
            },
            "cwd": {
                "type": ["string", "null"],
                "description": "Optional working directory inside the task container.",
            },
        },
        ["cmd"],
    ),
    _schema(
        "start_job",
        "Start a detached job that keeps running after the current process exits.",
        {
            "cmd": {
                "type": "string",
                "description": "Shell command to launch as a detached job.",
            },
            "job_id": {
                "type": ["string", "null"],
                "description": "Optional stable identifier for the job registry entry.",
            },
            "cwd": {
                "type": ["string", "null"],
                "description": "Optional working directory for the detached job.",
            },
        },
        ["cmd"],
    ),
    _schema(
        "job_status",
        "Inspect a detached background job and report liveness and recent log tail.",
        {
            "job_id": {
                "type": "string",
                "description": "Identifier of the job registry entry to inspect.",
            },
        },
        ["job_id"],
    ),
    _schema(
        "session_start",
        "Start a persistent interactive session backed by a named PTY.",
        {
            "session_id": {
                "type": "string",
                "description": "Identifier for the persistent session.",
            },
            "command": {
                "type": "string",
                "description": "Command to run inside the interactive session.",
            },
        },
        ["session_id", "command"],
    ),
    _schema(
        "session_send",
        "Send literal keystrokes or control sequences to an interactive session.",
        {
            "session_id": {
                "type": "string",
                "description": "Identifier of the session that receives the keystrokes.",
            },
            "keys": {
                "type": "string",
                "description": "Keys to send, including control sequences such as Enter or C-c.",
            },
        },
        ["session_id", "keys"],
    ),
    _schema(
        "session_read",
        "Read the current screen contents of an interactive session without advancing it.",
        {
            "session_id": {
                "type": "string",
                "description": "Identifier of the session to read.",
            },
        },
        ["session_id"],
    ),
    _schema(
        "read_file",
        "Read a bounded slice of a file from the task workspace.",
        {
            "path": {
                "type": "string",
                "description": "Path to the file to read.",
            },
            "offset": {
                "type": ["integer", "null"],
                "minimum": 0,
                "description": "Optional starting offset in bytes or lines, depending on the implementation.",
            },
            "limit": {
                "type": ["integer", "null"],
                "minimum": 0,
                "description": "Optional maximum amount to read in bytes or lines, depending on the implementation.",
            },
        },
        ["path"],
    ),
    _schema(
        "write_file",
        "Write file content atomically to the task workspace.",
        {
            "path": {
                "type": "string",
                "description": "Path to the file to write.",
            },
            "content": {
                "type": "string",
                "description": "File content to write atomically.",
            },
        },
        ["path", "content"],
    ),
    _schema(
        "wait",
        "Sleep without issuing a model call and surface any state changes after the pause.",
        {
            "seconds": {
                "type": "integer",
                "minimum": 0,
                "maximum": 300,
                "description": "Number of seconds to sleep, capped at 300.",
            },
            "reason": {
                "type": "string",
                "description": "Short reason for the wait.",
            },
        },
        ["seconds", "reason"],
    ),
    _schema(
        "task_done",
        "Claim completion and trigger verification with declared evidence checks.",
        {
            "summary": {
                "type": "string",
                "description": "Free-text completion claim.",
            },
            "checks": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string"},
                "description": "Shell commands used as evidence for the completion claim.",
            },
        },
        ["summary", "checks"],
    ),
]


def dispatch(tool_name: str, args: dict[str, Any], ctx: Any) -> Any:
    """Dispatch a tool call to the matching method on ctx."""

    if tool_name not in TOOL_NAMES:
        raise KeyError(f"unknown tool: {tool_name}")
    handler = getattr(ctx, tool_name, None)
    if handler is None:
        raise AttributeError(f"context does not implement {tool_name}")
    return handler(**args)
