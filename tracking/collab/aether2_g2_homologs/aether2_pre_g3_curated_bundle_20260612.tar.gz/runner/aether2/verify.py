"""Fresh-context verification and replay checks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping
import json

from runner.kernel_layer2_audit import _clean_hidden_refs


@dataclass(frozen=True)
class CheckResult:
    command: str
    exit_code: int | None
    stdout: str
    stderr: str
    cwd: str
    duration_sec: float
    timed_out: bool = False
    error_kind: str | None = None
    error_reason_code: str | None = None


@dataclass(frozen=True)
class RequirementResult:
    requirement: str
    verdict: str
    evidence: str


@dataclass(frozen=True)
class DiscrepancyReport:
    requirements: tuple[RequirementResult, ...]
    reason_codes: tuple[str, ...]
    summary: str
    raw_response: str

    @property
    def has_discrepancies(self) -> bool:
        """True only when a requirement is positively `unsatisfied`.

        `unverifiable` verdicts are reported in `requirements`/`summary` for
        transparency but do NOT block finalization: the fresh-context
        verifier frequently cannot confirm interactive-session or
        background-job internals (it has no executor transcript access by
        design), so treating `unverifiable` as a discrepancy caused
        round-exhaustion on tasks that were in fact correct (anti-correlated
        with ground truth, per G2 fix-round-5 analysis).
        """
        if "verifier_parse_failed" in self.reason_codes:
            return True
        return any(item.verdict == "unsatisfied" for item in self.requirements)


VERIFIER_TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Run a read-only inspection command in the live task environment.",
            "parameters": {
                "type": "object",
                "properties": {
                    "cmd": {"type": "string"},
                    "timeout_sec": {"type": "integer", "default": 120},
                    "cwd": {"type": ["string", "null"]},
                },
                "required": ["cmd"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file from the live task workspace without modifying it.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "offset": {"type": ["integer", "null"]},
                    "limit": {"type": ["integer", "null"]},
                },
                "required": ["path"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "job_status",
            "description": "Inspect a detached job without modifying it.",
            "parameters": {
                "type": "object",
                "properties": {"job_id": {"type": "string"}},
                "required": ["job_id"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "session_read",
            "description": "Read the current contents of a session without sending input.",
            "parameters": {
                "type": "object",
                "properties": {"session_id": {"type": "string"}},
                "required": ["session_id"],
                "additionalProperties": False,
            },
        },
    },
]


def replay_checks(checks: list[str], executor: Any) -> list[CheckResult]:
    results: list[CheckResult] = []
    for command in checks:
        raw = executor.run(command, timeout_sec=120, cwd=None)
        results.append(
            CheckResult(
                command=command,
                exit_code=_read_field(raw, "exit_code"),
                stdout=str(_read_field(raw, "stdout", "")),
                stderr=str(_read_field(raw, "stderr", "")),
                cwd=str(_read_field(raw, "cwd", "")),
                duration_sec=float(_read_field(raw, "duration_sec", _read_field(raw, "duration", 0.0))),
                timed_out=bool(_read_field(raw, "timed_out", False)),
                error_kind=_read_error_field(raw, "kind"),
                error_reason_code=_read_error_field(raw, "reason_code"),
            )
        )
    return results


def verify_fresh_context(
    task: str,
    orientation: Mapping[str, Any],
    diff: Mapping[str, Any],
    claim: Mapping[str, Any],
    checks_results: list[CheckResult],
    action_digest: Mapping[str, Any],
    model_client: Any,
    inspection_ctx: Any | None = None,
) -> DiscrepancyReport:
    clean_orientation = _strip_transcript_fields(_clean_hidden_refs(dict(orientation)))
    clean_diff = _strip_transcript_fields(_clean_hidden_refs(dict(diff)))
    clean_claim = _strip_transcript_fields(_clean_hidden_refs(dict(claim)))
    clean_checks = [
        _strip_transcript_fields(_clean_hidden_refs(result.__dict__))
        for result in checks_results
    ]
    clean_action_digest = _strip_transcript_fields(_clean_hidden_refs(dict(action_digest)))
    payload = {
        "task": task,
        "orientation": clean_orientation,
        "workspace_diff": clean_diff,
        "claim": clean_claim,
        "checks_results": clean_checks,
        "action_digest": clean_action_digest,
    }
    messages = [
        {
            "role": "system",
            "content": (
                "You are a fresh-context verifier. Evaluate the claim requirement by requirement, "
                "using only the provided task, orientation, workspace diff, replayed checks, and action digest. "
                "Do not assume access to any executor transcript.\n\n"
                "Respond with a single JSON object and nothing else, using EXACTLY this schema "
                "(no other top-level keys are allowed):\n"
                "{\n"
                '  "requirements": [\n'
                '    {"requirement": "<short description of one task requirement>", '
                '"verdict": "satisfied" | "unsatisfied" | "unverifiable", '
                '"evidence": "<evidence for this verdict>"}\n'
                "    ... one entry per distinct requirement implied by the task ...\n"
                "  ],\n"
                '  "reason_codes": [<list of short machine-readable strings; empty list if no problems>],\n'
                '  "summary": "<one or two sentence overall summary>"\n'
                "}\n"
                'Do NOT use alternative keys such as "claim_satisfied", "verdict" at the top level, or "overall_evidence". '
                'Every requirement entry must use exactly the keys "requirement", "verdict", and "evidence", '
                'and "verdict" must be exactly one of "satisfied", "unsatisfied", or "unverifiable".'
            ),
        },
        {"role": "user", "content": json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)},
    ]
    response = _call_model(
        model_client,
        messages,
        VERIFIER_TOOL_SCHEMAS if inspection_ctx is not None else [],
    )
    messages_for_parse = list(messages)
    tool_calls = _extract_tool_calls(response)
    if inspection_ctx is not None and tool_calls:
        messages_for_parse.append(_assistant_message(response))
        for tool_call in tool_calls:
            tool_name = _tool_call_name(tool_call)
            if tool_name is None:
                continue
            arguments = _parse_tool_call_arguments(tool_call)
            handler = getattr(inspection_ctx, tool_name, None)
            if handler is None:
                continue
            result = handler(**arguments)
            messages_for_parse.append(
                {
                    "role": "tool",
                    "name": tool_name,
                    "tool_call_id": tool_call.get("id"),
                    "content": json.dumps(
                        _inspection_payload(result),
                        sort_keys=True,
                        separators=(",", ":"),
                        ensure_ascii=True,
                    ),
                }
            )
        response = _call_model(model_client, messages_for_parse, [])
    raw_text = _extract_text(response)
    parsed = _parse_report(raw_text)
    requirements = tuple(
        RequirementResult(
            requirement=str(item.get("requirement", "")),
            verdict=_normalize_verdict(str(item.get("verdict", "unverifiable"))),
            evidence=str(item.get("evidence", "")),
        )
        for item in parsed.get("requirements", [])
        if str(item.get("requirement", "")).strip()
    )
    return DiscrepancyReport(
        requirements=requirements,
        reason_codes=tuple(str(code) for code in parsed.get("reason_codes", [])),
        summary=str(parsed.get("summary", "")),
        raw_response=raw_text,
    )


def _call_model(model_client: Any, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> Any:
    if hasattr(model_client, "call"):
        return model_client.call(messages, tools, cache_prefix_len=0)
    raise TypeError("model_client must define call(messages, tools, *, cache_prefix_len)")


def _read_field(raw: Any, name: str, default: Any = None) -> Any:
    if isinstance(raw, Mapping):
        return raw.get(name, default)
    return getattr(raw, name, default)


def _extract_text(response: Any) -> str:
    if isinstance(response, str):
        return response
    if isinstance(response, Mapping):
        for key in ("output_text", "text", "content"):
            value = response.get(key)
            if isinstance(value, str) and value:
                return value
    if hasattr(response, "output_text") and isinstance(response.output_text, str):
        return response.output_text
    if hasattr(response, "text") and isinstance(response.text, str):
        return response.text
    if hasattr(response, "content") and isinstance(response.content, str):
        return response.content
    return json.dumps(response, sort_keys=True, default=str, ensure_ascii=True)


def _extract_tool_calls(response: Any) -> tuple[dict[str, Any], ...]:
    if isinstance(response, Mapping):
        tool_calls = response.get("tool_calls")
        if isinstance(tool_calls, list):
            return tuple(dict(item) for item in tool_calls if isinstance(item, Mapping))
    value = getattr(response, "tool_calls", ())
    if isinstance(value, tuple):
        return tuple(dict(item) for item in value if isinstance(item, Mapping))
    if isinstance(value, list):
        return tuple(dict(item) for item in value if isinstance(item, Mapping))
    return ()


def _assistant_message(response: Any) -> dict[str, Any]:
    message: dict[str, Any] = {"role": "assistant", "content": _extract_text(response)}
    tool_calls = _extract_tool_calls(response)
    if tool_calls:
        message["tool_calls"] = [dict(item) for item in tool_calls]
    return message


def _parse_report(raw_text: str) -> dict[str, Any]:
    fallback = {
        "requirements": [
            {
                "requirement": "verification_output_parse",
                "verdict": "unverifiable",
                "evidence": "Verifier output could not be parsed into the required JSON schema.",
            }
        ],
        "reason_codes": ["verifier_parse_failed"],
        "summary": "Verifier output could not be parsed.",
    }
    try:
        parsed = json.loads(raw_text)
    except Exception:
        return fallback
    if not isinstance(parsed, dict):
        return fallback
    if "requirements" not in parsed or "reason_codes" not in parsed or "summary" not in parsed:
        return fallback
    requirements = parsed.get("requirements", [])
    reason_codes = parsed.get("reason_codes", [])
    summary = parsed.get("summary", "")
    if not isinstance(requirements, list) or not isinstance(reason_codes, list) or not isinstance(summary, str):
        return fallback
    parsed["requirements"] = [item for item in requirements if isinstance(item, Mapping)]
    parsed["reason_codes"] = [str(item) for item in reason_codes]
    parsed["summary"] = summary
    return parsed


def _normalize_verdict(verdict: str) -> str:
    normalized = verdict.strip().lower()
    if normalized in {"satisfied", "unsatisfied", "unverifiable"}:
        return normalized
    return "unverifiable"


def _strip_transcript_fields(payload: Any) -> Any:
    if isinstance(payload, Mapping):
        cleaned: dict[str, Any] = {}
        for key, value in payload.items():
            if "transcript" in str(key).lower():
                continue
            cleaned[str(key)] = _strip_transcript_fields(value)
        return cleaned
    if isinstance(payload, list):
        return [_strip_transcript_fields(item) for item in payload]
    if isinstance(payload, tuple):
        return tuple(_strip_transcript_fields(item) for item in payload)
    return payload


def _read_error_field(raw: Any, name: str) -> str | None:
    error = _read_field(raw, "error", None)
    if error is None:
        return None
    if isinstance(error, Mapping):
        value = error.get(name)
    else:
        value = getattr(error, name, None)
    if value is None:
        return None
    return str(value)


def _tool_call_name(tool_call: Mapping[str, Any]) -> str | None:
    name = tool_call.get("name")
    if isinstance(name, str) and name:
        return name
    function = tool_call.get("function")
    if isinstance(function, Mapping):
        nested_name = function.get("name")
        if isinstance(nested_name, str) and nested_name:
            return nested_name
    return None


def _parse_tool_call_arguments(tool_call: Mapping[str, Any]) -> dict[str, Any]:
    arguments = tool_call.get("arguments")
    if isinstance(arguments, Mapping):
        return dict(arguments)
    if isinstance(arguments, str):
        if not arguments.strip():
            return {}
        try:
            parsed = json.loads(arguments)
        except (TypeError, ValueError):
            return {}
        if isinstance(parsed, dict):
            return parsed
    return {}


def _inspection_payload(result: Any) -> dict[str, Any]:
    payload = {
        "exit_code": _read_field(result, "exit_code"),
        "cwd": _read_field(result, "cwd", ""),
        "stdout_head": _read_field(result, "stdout_head", _read_field(result, "stdout", "")),
        "stdout_tail": _read_field(result, "stdout_tail", ""),
        "stderr_head": _read_field(result, "stderr_head", _read_field(result, "stderr", "")),
        "stderr_tail": _read_field(result, "stderr_tail", ""),
    }
    error = _read_field(result, "error", None)
    if error is not None:
        if isinstance(error, Mapping):
            payload["error"] = dict(error)
        else:
            payload["error"] = getattr(error, "__dict__", {"message": str(error)})
    return payload
