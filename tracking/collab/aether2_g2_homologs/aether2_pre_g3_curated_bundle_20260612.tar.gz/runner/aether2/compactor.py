"""Deterministic context rebasing."""

from __future__ import annotations

from typing import Any, Mapping
import json

from runner.aether2.context import ContextManager
from runner.aether2.prompts import HANDOFF_TEMPLATE


def should_rebase(window_used_frac: float, model_requested: bool) -> bool:
    return model_requested or window_used_frac >= 0.60


def build_fact_ledger(delta_state: Any) -> dict[str, Any]:
    files = getattr(delta_state, "files", {}) or {}
    artifact_registry = getattr(delta_state, "artifact_registry", {}) or {}
    written_files = [
        {"path": path, "sha256": digest}
        for path, digest in sorted(files.items())
    ]
    artifact_paths = sorted(str(path) for path in artifact_registry)
    return {
        "written_files": written_files,
        "artifacts": artifact_paths,
        "jobs": _sorted_registry(delta_state, "job_registry"),
        "sessions": _sorted_registry(delta_state, "session_registry"),
        "services": _sorted_registry(delta_state, "service_registry"),
        "processes": _sorted_registry(delta_state, "process_registry"),
        "installed_packages": _stable_sequence(getattr(delta_state, "installed_packages", []) or []),
        "nonzero_exits": _stable_sequence(getattr(delta_state, "nonzero_exits", []) or []),
    }


def rebase(context: ContextManager, model_client: Any) -> ContextManager:
    if context.prefix is None:
        raise ValueError("context prefix must be built before rebase")
    fact_ledger = build_fact_ledger(context.delta_state)
    handoff_messages = [
        {"role": "system", "content": HANDOFF_TEMPLATE},
        {"role": "user", "content": context.task_instruction},
    ]
    prompt_messages = [
        *handoff_messages,
        {
            "role": "user",
            "content": json.dumps(
                {
                    "fact_ledger": fact_ledger,
                    "last_turns": context.transcript[-10:],
                },
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=True,
            ),
        },
    ]
    response = _call_model(model_client, prompt_messages)
    handoff_text = _extract_text(response)
    rebased = ContextManager(delta_state=context.delta_state)
    rebased.build_prefix(
        system_prompt=context.system_prompt,
        task_instruction=context.task_instruction,
        orientation=context.orientation,
        tool_schemas=context.tool_schemas,
        extra_prefix_messages=[
            {
                "role": "system",
                "content": "[deterministic_fact_ledger]\n"
                + json.dumps(fact_ledger, sort_keys=True, separators=(",", ":"), ensure_ascii=True),
            },
            {"role": "assistant", "content": handoff_text},
            *context.transcript[-10:],
        ],
    )
    return rebased


def _call_model(model_client: Any, messages: list[dict[str, Any]]) -> Any:
    if hasattr(model_client, "call"):
        return model_client.call(messages, [], cache_prefix_len=0)
    raise TypeError("model_client must define call(messages, tools, *, cache_prefix_len)")


def _extract_text(response: Any) -> str:
    if isinstance(response, str):
        return response
    if isinstance(response, Mapping):
        for key in ("output_text", "text", "content", "summary"):
            value = response.get(key)
            if isinstance(value, str) and value:
                return value
        messages = response.get("messages")
        if isinstance(messages, list):
            for message in reversed(messages):
                if isinstance(message, Mapping) and isinstance(message.get("content"), str):
                    return str(message["content"])
    if hasattr(response, "output_text") and isinstance(response.output_text, str):
        return response.output_text
    if hasattr(response, "text") and isinstance(response.text, str):
        return response.text
    return json.dumps(response, sort_keys=True, default=str, ensure_ascii=True)


def _sorted_registry(delta_state: Any, name: str) -> dict[str, Any]:
    registry = getattr(delta_state, name, {}) or {}
    return {str(key): _stable_value(registry[key]) for key in sorted(registry)}


def _stable_sequence(values: Any) -> list[Any]:
    normalized = [_stable_value(value) for value in values if value is not None]
    return sorted(normalized, key=lambda value: json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True))


def _stable_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _stable_value(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [_stable_value(item) for item in value]
    if isinstance(value, tuple):
        return [_stable_value(item) for item in value]
    if isinstance(value, set):
        return sorted(_stable_value(item) for item in value)
    if hasattr(value, "to_dict") and callable(value.to_dict):
        try:
            return _stable_value(value.to_dict())
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        return _stable_value(vars(value))
    return str(value)
