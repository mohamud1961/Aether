"""Probe the local workspace and runtime into a compact, factual snapshot."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class OrientationSnapshot:
    cwd: str
    user: str
    is_root: bool
    workspace_root: str
    writable_paths: list[str]
    safe_file_listing: list[str]
    tool_presence: dict[str, str]
    package_managers: dict[str, str]
    network: str
    network_reachable: bool
    network_evidence: str
    runtimes: dict[str, str]
    processes: list[str]
    ports: list[str]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


NETWORK_PROBE_COMMANDS: tuple[tuple[str, str], ...] = (
    (
        "python3 -c \"import socket; s=socket.create_connection(('pypi.org', 443), 3); s.close(); print('reachable: pypi.org:443')\"",
        "python3 direct DNS+TCP probe",
    ),
    (
        "python -c \"import socket; s=socket.create_connection(('pypi.org', 443), 3); s.close(); print('reachable: pypi.org:443')\"",
        "python direct DNS+TCP probe",
    ),
    (
        "sh -lc 'curl -Is --max-time 3 https://pypi.org | head -n 1'",
        "curl HEAD probe",
    ),
)


def _read_text(result: Any) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        for key in ("stdout", "output", "text", "content", "result"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value
        stderr = result.get("stderr")
        if isinstance(stderr, str):
            return stderr
        return ""
    for attr in ("stdout", "output", "text", "content", "result"):
        value = getattr(result, attr, None)
        if isinstance(value, str) and value.strip():
            return value
    stderr = getattr(result, "stderr", None)
    if isinstance(stderr, str):
        return stderr
    return ""


def _exit_code(result: Any) -> int | None:
    if result is None:
        return None
    if isinstance(result, dict):
        for key in ("exit_code", "returncode", "code", "status"):
            value = result.get(key)
            if isinstance(value, int):
                return value
        return None
    for attr in ("exit_code", "returncode", "code", "status"):
        value = getattr(result, attr, None)
        if isinstance(value, int):
            return value
    return None


def _probe(executor: Any, command: str, *, cwd: str | None = None) -> tuple[str, bool]:
    raw = executor.run(command, timeout_sec=10, cwd=cwd)
    text = _read_text(raw).strip()
    code = _exit_code(raw)
    success = code == 0 if code is not None else bool(text)
    return text, success


def _probe_candidates(executor: Any, commands: list[str], *, cwd: str | None = None, missing_value: str = "") -> str:
    for command in commands:
        text, success = _probe(executor, command, cwd=cwd)
        if success:
            return text
    return missing_value


def _split_lines(text: str, *, limit: int = 40) -> list[str]:
    if not text:
        return []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return lines[:limit]


def _presence_value(text: str) -> str:
    text = text.strip()
    if not text:
        return "missing"
    return text.splitlines()[0].strip()


def _network_value(text: str) -> str:
    normalized = text.strip().lower()
    if normalized in {"reachable", "online", "connected", "yes"}:
        return "reachable"
    if normalized in {"blocked", "offline", "disconnected", "no"}:
        return "blocked"
    if normalized:
        return normalized.splitlines()[0]
    return "blocked"


def _probe_presence(executor: Any, commands: list[str], *, cwd: str | None = None) -> str:
    return _probe_candidates(executor, commands, cwd=cwd, missing_value="missing")


def _probe_network(executor: Any) -> tuple[bool, str]:
    last_evidence = "blocked"
    for command, label in NETWORK_PROBE_COMMANDS:
        text, success = _probe(executor, command)
        if success:
            evidence = text or f"reachable via {label}"
            return True, evidence
        if text and last_evidence == "blocked":
            last_evidence = text
    return False, last_evidence or "blocked"


def orient(executor: Any) -> OrientationSnapshot:
    cwd = _probe_candidates(executor, ["pwd"]) or ""
    user = _probe_candidates(executor, ["id -un", "whoami"]) or "unavailable"
    is_root = _probe_candidates(executor, ["id -u"]) == "0"
    workspace_root = _probe_candidates(
        executor,
        ["git rev-parse --show-toplevel", "pwd"],
        cwd=cwd or None,
    ) or cwd

    writable_paths: list[str] = []
    for path in [p for p in [cwd, workspace_root] if p]:
        writable_probe = _probe_candidates(
            executor,
            [
                'sh -lc \'[ -w "$PWD" ] && printf writable || printf read-only\'',
                'python3 -c "import os; print(\'writable\' if os.access(\'.\', os.W_OK) else \'read-only\')"',
            ],
            cwd=path,
        )
        if writable_probe == "writable" and path not in writable_paths:
            writable_paths.append(path)

    safe_file_listing = _split_lines(
        _probe_candidates(
            executor,
            [
                'python3 -c "import os; print(\'\\n\'.join(sorted(os.listdir(\'.\'))[:40]))"',
                "ls -1A",
            ],
            cwd=workspace_root or cwd or None,
        )
    )

    tool_presence = {
        "git": _probe_presence(executor, ["command -v git", "git --version"]),
        "curl": _probe_presence(executor, ["command -v curl", "curl --version"]),
        "python3": _probe_presence(executor, ["command -v python3", "python3 --version"]),
        "gcc": _probe_presence(executor, ["command -v gcc", "gcc --version"]),
        "make": _probe_presence(executor, ["command -v make", "make --version"]),
        "tmux": _probe_presence(executor, ["command -v tmux", "tmux -V"]),
        "node": _probe_presence(executor, ["command -v node", "node --version"]),
        "npm": _probe_presence(executor, ["command -v npm", "npm --version"]),
        "uv": _probe_presence(executor, ["command -v uv", "uv --version"]),
        "pip": _probe_presence(executor, ["command -v pip", "pip --version", "python3 -m pip --version"]),
    }

    package_managers = {
        "apt": _probe_presence(executor, ["command -v apt", "apt --version"]),
        "pip": _probe_presence(executor, ["command -v pip", "pip --version", "python3 -m pip --version"]),
        "npm": _probe_presence(executor, ["command -v npm", "npm --version"]),
        "uv": _probe_presence(executor, ["command -v uv", "uv --version"]),
    }

    network_reachable, network_evidence = _probe_network(executor)
    network = "reachable" if network_reachable else "blocked"

    runtimes = {
        "python3": _probe_presence(executor, ["python3 --version", "python3 -V"]),
        "python": _probe_presence(executor, ["python --version", "python -V"]),
        "node": _probe_presence(executor, ["node --version", "node -v"]),
        "npm": _probe_presence(executor, ["npm --version", "npm -v"]),
    }

    processes = _split_lines(
        _probe_candidates(
            executor,
            [
                "ps -eo comm= | head -n 20",
                "ps -A -o comm= | head -n 20",
            ],
        )
    )

    ports = _split_lines(
        _probe_candidates(
            executor,
            [
                "ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null || true",
                "netstat -ltn 2>/dev/null || true",
            ],
        )
    )

    return OrientationSnapshot(
        cwd=cwd,
        user=user,
        is_root=is_root,
        workspace_root=workspace_root,
        writable_paths=writable_paths,
        safe_file_listing=safe_file_listing,
        tool_presence=tool_presence,
        package_managers=package_managers,
        network=network,
        network_reachable=network_reachable,
        network_evidence=network_evidence,
        runtimes=runtimes,
        processes=processes,
        ports=ports,
    )
