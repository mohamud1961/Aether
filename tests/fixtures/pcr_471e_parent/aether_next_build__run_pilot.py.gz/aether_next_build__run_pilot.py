#!/usr/bin/env python3
"""Pilot runner: drive Aether-Next against official Terminal-Bench tasks.

Usage::

    python3.11 run_pilot.py \
        --tasks adaptive-rejection-sampler,path-tracing \
        --out results.json

Or as a module from the build dir::

    python3.11 -m run_pilot --tasks adaptive-rejection-sampler --out results.json

Env vars required for Azure models (defaults target GPT-5.4-Mini):

    AZURE_OPENAI_ENDPOINT
    AZURE_OPENAI_GPT54_MINI_DEPLOYMENT
    AZURE_OPENAI_GPT54_MINI_KEY
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

# Ensure the build dir is importable when run as a script.
_BUILD_DIR = str(Path(__file__).resolve().parent)
if _BUILD_DIR not in sys.path:
    sys.path.insert(0, _BUILD_DIR)

from aether_next.architect_v3_contract import architect_v3_provider_schema  # noqa: E402
from aether_next.providers.azure_model import make_azure_callable  # noqa: E402
from aether_next.pcr_runtime_manifest import build_pcr_runtime_manifest  # noqa: E402
from aether_next.evidence_finalization import executing_source_identity  # noqa: E402
from aether_next.run_adapter import ensure_certified_architect_mode  # noqa: E402
from aether_next.runners.docker_runner import (  # noqa: E402
    _resolve_certified_source_identity, run_tbench_task,
)
from aether_next.task_metadata_loader import declared_docker_image  # noqa: E402


_OFFICIAL_TASKS_DIR = str(
    Path(__file__).resolve().parent.parent / "official_tasks"
)

_PCR_CURRENT_RUNTIME_MANIFEST_PATH = (
    Path(__file__).resolve().parent
    / "evals" / "natural_solver_production_screen" / "CURRENT_RUNTIME_MANIFEST.json"
)
_PCR_EXECUTION_BODY_MANIFEST_PATH = (
    Path(__file__).resolve().parent
    / "evals" / "natural_solver_production_screen" / "INTEGRATED_EXECUTION_BODY_MANIFEST.json"
)



def _disabled_pcr_architect_model(
    messages: list[dict[str, str]],
    *,
    max_output_tokens: int = 8000,
) -> str:
    del messages, max_output_tokens
    raise RuntimeError("PCR V0 forbids Architect provider invocation")


def _hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _tree_hash(root: Path, *, include_suffixes: tuple[str, ...] = (".py", ".md", ".toml", ".json")) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if "__pycache__" in rel or rel.startswith("local_goal_runs/") or rel.startswith("verifier_only_eval_") or rel.startswith("architect_only_eval_") or rel.startswith("deterministic_integration_eval_"):
            continue
        if include_suffixes and path.suffix not in include_suffixes:
            continue
        h.update(rel.encode("utf-8") + b"\0")
        h.update(_hash_file(path).encode("ascii") + b"\0")
    return h.hexdigest()


def _git_info(root: Path) -> dict[str, Any]:
    def run(args: list[str]) -> str:
        return subprocess.check_output(["git", *args], cwd=str(root), stderr=subprocess.DEVNULL, text=True).strip()
    try:
        sha = run(["rev-parse", "HEAD"])
        branch = run(["branch", "--show-current"])
        dirty = bool(run(["status", "--porcelain"]))
        return {"git_available": True, "code_sha": sha, "branch": branch, "dirty": dirty}
    except Exception:
        return {"git_available": False, "code_sha": "", "branch": "", "dirty": None}


def _build_run_provenance(args: argparse.Namespace) -> dict[str, Any]:
    build_root = Path(__file__).resolve().parent
    git = _git_info(build_root)
    tree_hash = _tree_hash(build_root / "aether_next")
    prompt_hashes = {
        "run_args": hashlib.sha256(json.dumps(vars(args), sort_keys=True, default=str).encode("utf-8")).hexdigest(),
    }
    return {
        "schema_version": "aether_run_provenance.v1",
        "provenance_mode": args.provenance_mode,
        **git,
        "code_tree_hash": tree_hash,
        "prompt_hashes": prompt_hashes,
        "model_params": {
            "solver_deploy_env": args.solver_deploy_env,
            "architect_deploy_env": args.architect_deploy_env,
            "verifier_deploy_env": args.verifier_deploy_env,
            "endpoint_env": args.endpoint_env,
            "effort": args.effort,
            "solver_transport": args.solver_transport,
            "solver_responses_background": args.solver_responses_background,
            "solver_continuity_mode": args.solver_continuity_mode,
            "solver_compact_threshold": args.solver_compact_threshold,
            "solver_reasoning_context": args.solver_reasoning_context,
            "solver_working_state_mode": args.solver_working_state_mode,
            "solver_reanchor_mode": args.solver_reanchor_mode,
            "solver_provider_max_retries": args.solver_provider_max_retries,
            "solver_sdk_max_retries": args.solver_sdk_max_retries,
            "verifier_provider_max_retries": args.verifier_provider_max_retries,
            "verifier_sdk_max_retries": args.verifier_sdk_max_retries,
            "verifier_transport": args.verifier_transport,
            "verifier_responses_background": args.verifier_responses_background,
        },
    }


def _preflight_uncertified_production_provenance(
    args: argparse.Namespace,
    run_provenance: dict[str, Any],
    certified_source_identity: dict[str, Any] | None,
) -> None:
    """Reject source-unbound production runs before model factories exist.

    The historical ``code_tree_hash`` is a content fingerprint, not source
    authority. Production therefore requires either clean local Git custody or
    the externally certified source path. This closes the old no-Git/dirty
    path that could spend model calls only to be rejected at final admission.
    """
    if args.provenance_mode != "production" or certified_source_identity is not None:
        return
    code_sha = str(run_provenance.get("code_sha", "") or "").strip().lower()
    if (
        run_provenance.get("git_available") is not True
        or run_provenance.get("dirty") is not False
        or len(code_sha) != 40
        or any(ch not in "0123456789abcdef" for ch in code_sha)
    ):
        raise ValueError(
            "production source requires a clean Git checkout or --certified-source-identity"
        )


def _stamp_resolved_source_provenance(
    run_provenance: dict[str, Any],
    resolved_source_identity: dict[str, Any],
) -> None:
    """Make certified source authority explicit without changing legacy hash semantics."""
    commit = str(resolved_source_identity.get("commit", "") or "").strip().lower()
    tree = str(resolved_source_identity.get("tree", "") or "").strip().lower()
    authority = str(resolved_source_identity.get("identity_authority", "") or "").strip()
    if (
        len(commit) != 40
        or any(ch not in "0123456789abcdef" for ch in commit)
        or len(tree) != 40
        or any(ch not in "0123456789abcdef" for ch in tree)
        or not authority
    ):
        raise ValueError("resolved certified source identity is malformed")

    # ``code_tree_hash`` predates Git-tree custody. It is a filtered 64-hex
    # content fingerprint and remains untouched for backward-compatible replay.
    # Stamp its semantics explicitly and carry the actual Git tree separately.
    content_hash = str(run_provenance.get("code_tree_hash", "") or "").strip().lower()
    if len(content_hash) == 64 and all(ch in "0123456789abcdef" for ch in content_hash):
        run_provenance["code_content_hash"] = content_hash
        run_provenance["code_tree_hash_semantics"] = (
            "legacy_aether_next_filtered_content_sha256_not_git_tree"
        )
    run_provenance.update({
        "code_sha": commit,
        "code_sha_authority": authority,
        "source_commit": commit,
        "source_tree": tree,
        "source_identity_authority": authority,
    })
    source_manifest = resolved_source_identity.get("source_manifest")
    if isinstance(source_manifest, dict):
        aggregate = str(source_manifest.get("aggregate_sha256", "") or "").strip().lower()
        try:
            count = int(source_manifest.get("file_count", 0) or 0)
        except (TypeError, ValueError):
            count = 0
        if len(aggregate) == 64 and all(ch in "0123456789abcdef" for ch in aggregate) and count > 0:
            run_provenance["source_manifest_aggregate_sha256"] = aggregate
            run_provenance["source_manifest_file_count"] = count


def _load_certified_source_identity(path: str | None) -> dict[str, Any] | None:
    if not path:
        return None
    source = Path(path).resolve()
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"certified source identity is unreadable: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("certified source identity must be one JSON object")
    return dict(payload)


def _verify_sealed_manifest(
    manifest_path: Path,
    *,
    expected_manifest_sha256: str,
    expected_aggregate_sha256: str,
    expected_file_count: int,
    label: str,
) -> dict[str, Any]:
    try:
        raw = manifest_path.read_bytes()
        manifest = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} manifest is unavailable: {exc}") from exc
    if not isinstance(manifest, dict) or not isinstance(manifest.get("files"), list):
        raise ValueError(f"{label} manifest shape is invalid")
    manifest_sha = hashlib.sha256(raw).hexdigest()
    if manifest_sha != str(expected_manifest_sha256 or "").strip().lower():
        raise ValueError(f"{label} manifest file hash does not match certified source identity")
    rows = manifest["files"]
    if len(rows) != int(expected_file_count):
        raise ValueError(f"{label} manifest file count does not match certified source identity")
    findings: list[str] = []
    build_root = Path(__file__).resolve().parent
    for row in rows:
        if not isinstance(row, dict):
            findings.append("invalid_row")
            continue
        relative = str(row.get("path", "") or "").strip()
        target = build_root / relative
        if not relative or not target.is_file():
            findings.append(f"missing:{relative}")
            continue
        observed = {"bytes": target.stat().st_size, "sha256": _hash_file(target)}
        expected = {"bytes": int(row.get("bytes", -1)), "sha256": str(row.get("sha256", ""))}
        if observed != expected:
            findings.append(f"mismatch:{relative}")
    if findings:
        raise ValueError(f"{label} manifest does not match executing bytes: " + ",".join(findings[:20]))
    aggregate = hashlib.sha256(
        json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if aggregate != str(manifest.get("aggregate_sha256", "") or "").strip().lower():
        raise ValueError(f"{label} manifest self-aggregate is invalid")
    if aggregate != str(expected_aggregate_sha256 or "").strip().lower():
        raise ValueError(f"{label} aggregate does not match certified source identity")
    if int(manifest.get("file_count", -1)) != len(rows):
        raise ValueError(f"{label} manifest self file_count is invalid")
    return manifest


def _preflight_certified_source_identity(
    args: argparse.Namespace,
    certified: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if certified is None:
        return None
    if args.provenance_mode != "production":
        raise ValueError("certified source identity is qualified only for production provenance")
    if args.architect_mode != "pcr_v0":
        raise ValueError("certified source identity CLI is qualified only for PCR V0")
    observed = executing_source_identity(Path(__file__).resolve().parent)
    resolved = _resolve_certified_source_identity(observed, certified)

    try:
        runtime_files = int(certified.get("current_runtime_files", 0) or 0)
        body_files = int(certified.get("execution_body_files", 0) or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError("certified PCR sealed-manifest file counts are invalid") from exc
    if runtime_files <= 0 or body_files <= 0:
        raise ValueError("certified PCR sealed-manifest file counts must be positive")
    _verify_sealed_manifest(
        _PCR_CURRENT_RUNTIME_MANIFEST_PATH,
        expected_manifest_sha256=str(certified.get("current_runtime_manifest_sha256", "")),
        expected_aggregate_sha256=str(certified.get("current_runtime_aggregate_sha256", "")),
        expected_file_count=runtime_files,
        label="PCR current runtime",
    )
    _verify_sealed_manifest(
        _PCR_EXECUTION_BODY_MANIFEST_PATH,
        expected_manifest_sha256=str(certified.get("execution_body_manifest_sha256", "")),
        expected_aggregate_sha256=str(certified.get("execution_body_aggregate_sha256", "")),
        expected_file_count=body_files,
        label="PCR execution body",
    )
    return resolved


def _bind_pcr_runtime_manifest(
    args: argparse.Namespace,
    run_provenance: dict[str, Any],
    *,
    resolved_source_identity: dict[str, Any] | None = None,
    certified_source_identity: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Bind PCR model runs to the exact clean runtime/eval source closure."""
    if args.architect_mode != "pcr_v0":
        return None
    manifest = build_pcr_runtime_manifest(
        Path(__file__).resolve().parent,
        resolved_source_identity=resolved_source_identity,
    )
    if certified_source_identity is not None:
        expected_aggregate = str(
            certified_source_identity.get("pcr_runtime_manifest_aggregate_sha256", "") or ""
        ).strip().lower()
        try:
            expected_count = int(
                certified_source_identity.get("pcr_runtime_manifest_file_count", 0) or 0
            )
        except (TypeError, ValueError) as exc:
            raise ValueError("certified PCR runtime manifest file count is invalid") from exc
        if len(expected_aggregate) != 64 or any(ch not in "0123456789abcdef" for ch in expected_aggregate):
            raise ValueError("certified PCR runtime manifest aggregate is malformed")
        if expected_count <= 0:
            raise ValueError("certified PCR runtime manifest file count must be positive")
        if (
            str(manifest.get("aggregate_sha256", "") or "").strip().lower() != expected_aggregate
            or int(manifest.get("file_count", 0) or 0) != expected_count
        ):
            raise ValueError("certified PCR runtime closure does not match executing bytes")
    aggregate = str(manifest.get("aggregate_sha256", "") or "").strip()
    if not aggregate:
        raise ValueError("PCR runtime manifest has no aggregate identity")
    run_provenance["runtime_manifest_sha256"] = aggregate
    run_provenance["pcr_runtime_manifest_schema_version"] = str(
        manifest.get("schema_version", "") or ""
    )
    run_provenance["pcr_runtime_manifest_file_count"] = int(
        manifest.get("file_count", 0) or 0
    )
    if args.trace_dir:
        trace_root = Path(args.trace_dir).resolve()
        trace_root.mkdir(parents=True, exist_ok=True)
        manifest_path = trace_root / "PCR_RUNTIME_MANIFEST.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        run_provenance["pcr_runtime_manifest_path"] = str(manifest_path)
    return manifest


def _task_hash(task_dir: str) -> str:
    return _tree_hash(Path(task_dir), include_suffixes=())


def _task_image_tag(task_dir: str) -> str:
    task_path = Path(task_dir).resolve()
    safe_name = "".join(ch if ch.isalnum() else "-" for ch in task_path.name.lower()).strip("-")
    return f"aether-next-task-{safe_name}-{_task_hash(str(task_path))[:12]}"


def _build_task_image(task_dir: str, image_tag: str) -> None:
    task_path = Path(task_dir).resolve()
    dockerfile = task_path / "Dockerfile"
    if not dockerfile.exists():
        raise FileNotFoundError(
            f"no declared docker image and no Dockerfile found in {task_dir}"
        )
    inspect = subprocess.run(
        ["docker", "image", "inspect", image_tag],
        capture_output=True,
        text=True,
        errors="replace",
        timeout=60,
    )
    if inspect.returncode == 0:
        return
    build_timeout_s = int(os.environ.get("AETHER_TASK_IMAGE_BUILD_TIMEOUT_S", "1800"))
    build = subprocess.run(
        ["docker", "build", "-t", image_tag, str(task_path)],
        capture_output=True,
        text=True,
        errors="replace",
        timeout=max(1, build_timeout_s),
    )
    if build.returncode != 0:
        detail = (build.stdout + build.stderr).strip()[-4000:]
        raise RuntimeError(f"docker build failed for {task_path}: {detail}")


def _resolve_task_image(task_dir: str) -> str:
    """Resolve a real runnable image for TOML/YAML task layouts."""
    declared = declared_docker_image(task_dir)
    if declared:
        return declared
    image_tag = _task_image_tag(task_dir)
    _build_task_image(task_dir, image_tag)
    return image_tag


def _read_docker_image(task_dir: str) -> str:
    """Compatibility wrapper for tests and older callers."""
    return _resolve_task_image(task_dir)


def _print_summary(records: list[dict[str, Any]]) -> None:
    """Print a final summary table to stdout."""
    header = f"{'task':<40} {'reward':>7}  {'classifier_label'}"
    print("\n" + "=" * len(header))
    print(header)
    print("-" * len(header))
    for rec in records:
        task = rec.get("task", "?")[:40]
        reward = rec.get("reward", "?")
        label = rec.get("classifier_label", "?")
        print(f"{task:<40} {reward:>7}  {label}")
    print("=" * len(header))
    total = len(records)
    wins = sum(1 for r in records if r.get("reward", 0) == 1.0)
    print(f"Total: {wins}/{total} tasks rewarded.\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Pilot runner for Aether-Next on Terminal-Bench tasks.",
    )
    ap.add_argument(
        "--tasks",
        required=True,
        help="Comma-separated task names under official_tasks/.",
    )
    ap.add_argument(
        "--tasks-dir",
        default=_OFFICIAL_TASKS_DIR,
        help=f"Root directory containing task folders (default: {_OFFICIAL_TASKS_DIR}).",
    )
    ap.add_argument(
        "--solver-deploy-env",
        default="AZURE_OPENAI_GPT54_MINI_DEPLOYMENT",
        help="Env var name for solver deployment (default: AZURE_OPENAI_GPT54_MINI_DEPLOYMENT).",
    )
    ap.add_argument(
        "--solver-key-env",
        default="AZURE_OPENAI_GPT54_MINI_KEY",
        help="Env var name for solver API key (default: AZURE_OPENAI_GPT54_MINI_KEY).",
    )
    ap.add_argument(
        "--solver-transport",
        choices=["responses", "responses_tools", "chat_completions"],
        default="responses",
        help="Explicit Solver provider boundary. responses_tools is PCR-V0-only and forces one native pcr_turn call.",
    )
    ap.add_argument(
        "--solver-responses-background",
        choices=["true", "false"],
        default=None,
        help="Explicit Responses execution mode for the Solver; omit to use the provider default/env.",
    )
    ap.add_argument(
        "--solver-continuity-mode",
        choices=["explicit", "previous_response", "previous_response_compaction", "stateless_encrypted", "stateless_compaction"],
        default="explicit",
        help=(
            "PCR-only experimental cognitive-continuity treatment. explicit is the qualified baseline; "
            "all native modes remain experimental/unqualified until provider and semantic gates pass."
        ),
    )
    ap.add_argument(
        "--solver-reasoning-context",
        choices=["current_turn", "all_turns"],
        default=None,
        help=(
            "PCR current/all treatment. Requires pcr_v0 responses_tools, "
            "previous_response continuity, and working_state disabled."
        ),
    )
    ap.add_argument(
        "--solver-working-state-mode",
        choices=["legacy_optional", "disabled"],
        default="legacy_optional",
        help=(
            "PCR working-state contract. disabled is reserved for the "
            "current_turn/all_turns experiment carrier."
        ),
    )
    ap.add_argument(
        "--solver-compact-threshold",
        type=int,
        default=None,
        help="Positive server compaction threshold; valid only with a compaction Solver continuity mode.",
    )
    ap.add_argument(
        "--solver-provider-max-retries",
        type=int,
        default=None,
        help="Optional Aether-layer Solver provider retry count; omit for provider default.",
    )
    ap.add_argument(
        "--solver-sdk-max-retries",
        type=int,
        default=None,
        help="Optional OpenAI SDK Solver retry count; omit for SDK default.",
    )
    ap.add_argument(
        "--solver-reanchor-mode",
        choices=["current_full", "refined_m"],
        default="current_full",
        help=(
            "PCR-only model-facing reality packet. current_full is the qualified/default no-op; "
            "refined_m is experimental and allowed only with previous_response_compaction."
        ),
    )
    ap.add_argument(
        "--architect-deploy-env",
        default="AZURE_OPENAI_GPT54_MINI_DEPLOYMENT",
        help="Env var name for architect deployment (default: AZURE_OPENAI_GPT54_MINI_DEPLOYMENT).",
    )
    ap.add_argument(
        "--architect-key-env",
        default="AZURE_OPENAI_GPT54_MINI_KEY",
        help="Env var name for architect API key (default: AZURE_OPENAI_GPT54_MINI_KEY).",
    )
    ap.add_argument(
        "--verifier-deploy-env",
        default="AZURE_OPENAI_GPT54_MINI_DEPLOYMENT",
        help="Env var name for verifier deployment (default: AZURE_OPENAI_GPT54_MINI_DEPLOYMENT).",
    )
    ap.add_argument(
        "--verifier-key-env",
        default="AZURE_OPENAI_GPT54_MINI_KEY",
        help="Env var name for verifier API key (default: AZURE_OPENAI_GPT54_MINI_KEY).",
    )
    ap.add_argument(
        "--verifier-transport",
        choices=["chat_completions", "responses_tools"],
        default="chat_completions",
        help="Explicit Verifier provider boundary. responses_tools forces one native verifier_turn call.",
    )
    ap.add_argument(
        "--verifier-responses-background",
        choices=["true", "false"],
        default="false",
        help="Explicit Responses execution mode for native Verifier turns; qualification uses foreground false.",
    )
    ap.add_argument(
        "--verifier-provider-max-retries",
        type=int,
        default=None,
        help="Optional Aether-layer Verifier provider retry count; omit for provider default.",
    )
    ap.add_argument(
        "--verifier-sdk-max-retries",
        type=int,
        default=None,
        help="Optional OpenAI SDK Verifier retry count; omit for SDK default.",
    )
    ap.add_argument(
        "--endpoint-env",
        default="AZURE_OPENAI_ENDPOINT",
        help="Env var name for Azure endpoint (default: AZURE_OPENAI_ENDPOINT).",
    )
    ap.add_argument(
        "--effort",
        default="low",
        choices=["none", "low", "medium", "high", "xhigh"],
        help="Reasoning effort for model calls (default: low).",
    )
    ap.add_argument(
        "--max-steps",
        type=int,
        default=30,
        help="Max kernel steps per task (default: 30).",
    )
    ap.add_argument(
        "--run-timeout-s",
        type=int,
        default=1800,
        help="Timeout in seconds for Docker command/grader execution (default: 1800).",
    )
    ap.add_argument(
        "--network-scope",
        choices=["loopback_only", "external_unrestricted"],
        default=None,
        help="Optional explicit pre-container network scope. Omit to use public task metadata/default policy.",
    )
    ap.add_argument(
        "--trace-dir",
        default=None,
        help="Directory to write per-task JSON trace files for step-by-step audit. "
        "When set, each task emits <task>.trace.json with architect config, "
        "solver context/turn/observations, gate decisions, and reconfigurations.",
    )
    ap.add_argument(
        "--architect-mode",
        default="architect_v3",
        choices=["architect_v3", "pcr_v0"],
        help="Certified legacy Architect V3 or direct persistent PCR V0 runtime.",
    )
    ap.add_argument(
        "--vision-deploy-env",
        default="",
        help="Optional env var naming a vision-capable deployment; when set, "
        "the solver gains real image transcription via inspect_artifact.",
    )
    ap.add_argument(
        "--vision-key-env",
        default="",
        help="Env var for the vision deployment API key (defaults to the solver key env).",
    )
    ap.add_argument(
        "--snapshot-dir",
        default=None,
        help="Directory to write workspace snapshots for resumable replay. "
        "When set, the final container /app is copied to <dir>/<task>/final/.",
    )
    ap.add_argument(
        "--snapshot-steps",
        default="",
        help="Comma-separated step numbers at which to snapshot mid-run "
        "(e.g. '1,5,10'). Requires --snapshot-dir.",
    )
    ap.add_argument(
        "--provenance-mode",
        default="production",
        choices=["production", "test_untrusted"],
        help="Production/model-backed runs require resolvable code SHA or tree hash; local tests may use test_untrusted.",
    )
    ap.add_argument(
        "--certified-source-identity",
        default=None,
        help=(
            "Path to an externally certified PCR source-identity JSON object. "
            "Production PCR only; executing source, sealed runtime/body manifests, "
            "and PCR runtime closure must all match before model callables are built."
        ),
    )
    ap.add_argument(
        "--out",
        default="pilot_results.json",
        help="Output JSON file for results (default: pilot_results.json).",
    )

    args = ap.parse_args(argv)
    task_names = [t.strip() for t in args.tasks.split(",") if t.strip()]
    snap_steps = tuple(
        int(s) for s in args.snapshot_steps.split(",") if s.strip()
    ) if args.snapshot_steps else ()
    run_provenance = _build_run_provenance(args)
    try:
        certified_source_identity = _load_certified_source_identity(args.certified_source_identity)
        _preflight_uncertified_production_provenance(
            args, run_provenance, certified_source_identity
        )
        resolved_source_identity = _preflight_certified_source_identity(
            args, certified_source_identity
        )
        _bind_pcr_runtime_manifest(
            args, run_provenance,
            resolved_source_identity=resolved_source_identity,
            certified_source_identity=certified_source_identity,
        )
        if certified_source_identity is not None:
            if resolved_source_identity is None:
                raise ValueError("certified source identity did not resolve")
            _stamp_resolved_source_provenance(run_provenance, resolved_source_identity)
    except ValueError as exc:
        print(f"error: PCR runtime custody unavailable: {exc}", file=sys.stderr)
        return 2
    if certified_source_identity is not None:
        run_provenance["certified_source_identity_sha256"] = hashlib.sha256(
            json.dumps(certified_source_identity, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()

    if not task_names:
        print("error: no task names given", file=sys.stderr)
        return 1

    try:
        ensure_certified_architect_mode(args.architect_mode)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.verifier_transport == "responses_tools" and args.architect_mode != "pcr_v0":
        print("error: native verifier_turn transport is qualified only for PCR V0 production runs", file=sys.stderr)
        return 2
    if args.solver_continuity_mode != "explicit":
        if args.architect_mode != "pcr_v0" or args.solver_transport != "responses_tools":
            print(
                "error: native Solver continuity experiments require --architect-mode pcr_v0 "
                "and --solver-transport responses_tools",
                file=sys.stderr,
            )
            return 2
    if args.solver_continuity_mode in {"previous_response_compaction", "stateless_compaction"}:
        if args.solver_compact_threshold is None or args.solver_compact_threshold <= 0:
            print(
                f"error: {args.solver_continuity_mode} requires a positive --solver-compact-threshold",
                file=sys.stderr,
            )
            return 2
    elif args.solver_compact_threshold is not None:
        print(
            "error: --solver-compact-threshold is valid only with a compaction continuity mode",
            file=sys.stderr,
        )
        return 2
    if args.solver_reanchor_mode == "refined_m":
        if (
            args.architect_mode != "pcr_v0"
            or args.solver_transport != "responses_tools"
            or args.solver_continuity_mode != "previous_response_compaction"
        ):
            print(
                "error: --solver-reanchor-mode refined_m requires PCR V0 responses_tools "
                "with --solver-continuity-mode previous_response_compaction",
                file=sys.stderr,
            )
            return 2

    carrier_active = (
        args.solver_reasoning_context is not None
        or args.solver_working_state_mode != "legacy_optional"
    )
    if carrier_active and not (
        args.architect_mode == "pcr_v0"
        and args.solver_transport == "responses_tools"
        and args.solver_continuity_mode == "previous_response"
    ):
        print(
            "error: current/all carrier requires --architect-mode pcr_v0, "
            "--solver-transport responses_tools, and --solver-continuity-mode previous_response",
            file=sys.stderr,
        )
        return 2
    if (
        args.solver_reasoning_context is not None
        and args.solver_working_state_mode != "disabled"
    ):
        print(
            "error: --solver-reasoning-context requires --solver-working-state-mode disabled",
            file=sys.stderr,
        )
        return 2

    for retry_name in (
        "solver_provider_max_retries", "solver_sdk_max_retries",
        "verifier_provider_max_retries", "verifier_sdk_max_retries",
    ):
        value = getattr(args, retry_name)
        if value is not None and value < 0:
            print(f"error: --{retry_name.replace('_', '-')} must be >= 0", file=sys.stderr)
            return 2

    # Build model callables (reads env vars now, fails fast if missing).
    solver_model = make_azure_callable(
        deployment_env=args.solver_deploy_env,
        key_env=args.solver_key_env,
        endpoint_env=args.endpoint_env,
        effort=args.effort,
        role="solver",
        solver_protocol=("pcr_v0" if args.architect_mode == "pcr_v0" else "solver_v1"),
        transport=args.solver_transport,
        responses_background=(
            None
            if args.solver_responses_background is None
            else args.solver_responses_background == "true"
        ),
        pcr_continuity_mode=args.solver_continuity_mode,
        pcr_compact_threshold=args.solver_compact_threshold,
        pcr_reasoning_context=args.solver_reasoning_context,
        pcr_working_state_mode=args.solver_working_state_mode,
        max_retries=args.solver_provider_max_retries,
        sdk_max_retries=args.solver_sdk_max_retries,
    )
    vision_model = None
    if args.vision_deploy_env:
        from aether_next.providers.azure_model import make_azure_vision_callable
        vision_model = make_azure_vision_callable(
            deployment_env=args.vision_deploy_env,
            key_env=args.vision_key_env or args.solver_key_env,
            endpoint_env=args.endpoint_env,
        )

    architect_model = (
        _disabled_pcr_architect_model
        if args.architect_mode == "pcr_v0"
        else make_azure_callable(
            deployment_env=args.architect_deploy_env,
            key_env=args.architect_key_env,
            endpoint_env=args.endpoint_env,
            effort=args.effort,
            role="architect",
            structured_output_schema=architect_v3_provider_schema(),
            structured_output_name="aether_architect_v3",
        )
    )
    verifier_model = make_azure_callable(
        deployment_env=args.verifier_deploy_env,
        key_env=args.verifier_key_env,
        endpoint_env=args.endpoint_env,
        effort=args.effort,
        role="verifier",
        verifier_protocol=("pcr_v0" if args.architect_mode == "pcr_v0" else "verifier_v1"),
        transport=args.verifier_transport,
        responses_background=args.verifier_responses_background == "true",
        max_retries=args.verifier_provider_max_retries,
        sdk_max_retries=args.verifier_sdk_max_retries,
    )

    records: list[dict[str, Any]] = []

    def persist_results() -> None:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(records, fh, indent=2, default=str)

    for i, task_name in enumerate(task_names, 1):
        task_dir = os.path.join(args.tasks_dir, task_name)
        if not os.path.isdir(task_dir):
            print(f"[{i}/{len(task_names)}] SKIP {task_name}: directory not found", flush=True)
            records.append({
                "task": task_name,
                "image": "",
                "architect_mode": args.architect_mode,
                "reward": 0.0,
                "status": "error",
                "error": "task_dir_not_found",
                "error_detail": f"{task_dir} does not exist",
                "classifier_label": "environment_runner_failure",
                "classifier_confidence": "high",
                "classifier_detail": "task directory missing",
                "step": 0,
                "reconfigurations": 0,
                "model_parse_errors": [],
                "grader_exit": -1,
                "grader_stdout_tail": "",
                "grader_stderr_tail": "",
                "receipt_summary": [],
                "run_provenance": dict(run_provenance),
            })
            continue

        try:
            docker_image = _resolve_task_image(task_dir)
        except (FileNotFoundError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
            print(f"[{i}/{len(task_names)}] SKIP {task_name}: {exc}", flush=True)
            records.append({
                "task": task_name,
                "image": "",
                "reward": 0.0,
                "status": "error",
                "error": "task_image_resolution_error",
                "error_detail": str(exc),
                "classifier_label": "environment_runner_failure",
                "classifier_confidence": "high",
                "classifier_detail": str(exc),
                "step": 0,
                "reconfigurations": 0,
                "model_parse_errors": [],
                "grader_exit": -1,
                "grader_stdout_tail": "",
                "grader_stderr_tail": "",
                "receipt_summary": [],
            })
            continue

        print(f"[{i}/{len(task_names)}] RUN  {task_name}  image={docker_image}", flush=True)

        record_index = len(records)
        records.append({
            "task": task_name,
            "image": docker_image,
            "architect_mode": args.architect_mode,
            "reward": 0.0,
            "status": "running",
            "kernel_status": "running",
            "error": "attempt_in_progress",
            "error_detail": "task attempt started but no terminal result row has been written yet",
            "classifier_label": "attempt_in_progress",
            "classifier_confidence": "high",
            "classifier_detail": "non-terminal launch receipt; replace with completed/error row when run_tbench_task returns",
            "step": 0,
            "reconfigurations": 0,
            "model_parse_errors": [],
            "grader_exit": -1,
            "grader_stdout_tail": "",
            "grader_stderr_tail": "",
            "receipt_summary": [],
        })
        persist_results()

        def _record_progress(stage: str, detail: str) -> None:
            records[record_index]["running_stage"] = stage
            records[record_index]["running_detail"] = detail
            persist_results()

        try:
            record = run_tbench_task(
                task_dir=task_dir,
                image=docker_image,
                architect_model=architect_model,
                solver_model=solver_model,
                verifier_model=verifier_model,
                vision_model=vision_model,
                max_steps=args.max_steps,
                run_timeout_s=args.run_timeout_s,
                trace_dir=args.trace_dir,
                architect_mode=args.architect_mode,
                snapshot_dir=args.snapshot_dir,
                snapshot_steps=snap_steps,
                run_provenance={**run_provenance, "task_hash": _task_hash(task_dir)},
                certified_source_identity=certified_source_identity,
                progress_callback=_record_progress,
                network_scope=args.network_scope,
                solver_continuity_mode=args.solver_continuity_mode,
                solver_reanchor_mode=args.solver_reanchor_mode,
            )
        except Exception as exc:
            record = {
                "task": task_name,
                "image": docker_image,
                "architect_mode": args.architect_mode,
                "reward": 0.0,
                "status": "error",
                "error": type(exc).__name__,
                "error_detail": str(exc)[:4000],
                "classifier_label": "environment_runner_failure",
                "classifier_confidence": "high",
                "classifier_detail": f"run_tbench_task raised: {exc}",
                "step": 0,
                "reconfigurations": 0,
                "model_parse_errors": [],
                "grader_exit": -1,
                "grader_stdout_tail": "",
                "grader_stderr_tail": "",
                "receipt_summary": [],
            }

        record.setdefault("run_provenance", {**run_provenance, "task_hash": _task_hash(task_dir)})
        records[record_index] = record

        reward = record.get("reward", "?")
        label = record.get("classifier_label", "?")
        status = record.get("status", "?")
        print(
            f"[{i}/{len(task_names)}] DONE {task_name}  "
            f"reward={reward}  status={status}  classifier={label}",
            flush=True,
        )

        # Persist results incrementally so a crash preserves completed records.
        persist_results()

    out_path = Path(args.out)
    print(f"\nResults written to {out_path}", flush=True)

    _print_summary(records)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
