import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { join } from 'node:path';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { CheckpointManager } from '../../src/core/checkpoint.js';
import { Logger } from '../../src/logging/logger.js';
import { ensureDir, fileExists, readJson } from '../../src/util/fs.js';

describe('CheckpointManager', () => {
  let tempDir: string;
  let logger: Logger;
  let manager: CheckpointManager;

  beforeEach(async () => {
    tempDir = await mkdtemp(join(tmpdir(), 'aamf-test-'));
    logger = new Logger({ logDir: join(tempDir, 'logs'), level: 'error', console: false });
    manager = new CheckpointManager(tempDir, logger);
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true, force: true });
  });

  it('should create initial state on first load', async () => {
    const state = await manager.load('test-project');
    expect(state.projectName).toBe('test-project');
    expect(state.currentPhase).toBe(0);
    expect(state.completedPhases).toEqual([]);
    expect(state.completedTasks).toEqual([]);
    expect(state.version).toBe(1);
    expect(state.resumeCount).toBe(0);
  });

  it('should persist and reload state', async () => {
    const state = await manager.load('test-project');
    await manager.completePhase(1, '/output/phase1.md');
    
    // Create new manager, reload
    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.completedPhases).toContain(1);
    expect(reloaded.currentPhase).toBe(2);
    expect(reloaded.resumeCount).toBe(1); // incremented on reload
  });

  it('should track task completion', async () => {
    await manager.load('test-project');
    await manager.completeTask('task-001');
    await manager.completeTask('task-002');
    
    const state = manager.getState();
    expect(state.completedTasks).toContain('task-001');
    expect(state.completedTasks).toContain('task-002');
  });

  it('should track failed tasks', async () => {
    await manager.load('test-project');
    await manager.failTask('task-001', 'parity check failed', 1, false);
    
    const state = manager.getState();
    expect(state.failedTasks).toHaveLength(1);
    expect(state.failedTasks[0]?.taskId).toBe('task-001');
    expect(state.failedTasks[0]?.lastError).toBe('parity check failed');
  });

  it('should remove task from failed when completed', async () => {
    await manager.load('test-project');
    await manager.failTask('task-001', 'error', 1, false);
    await manager.completeTask('task-001');
    
    const state = manager.getState();
    expect(state.failedTasks).toHaveLength(0);
    expect(state.completedTasks).toContain('task-001');
  });

  it('should block tasks', async () => {
    await manager.load('test-project');
    await manager.blockTask('task-001');
    
    const state = manager.getState();
    expect(state.blockedTasks).toContain('task-001');
  });

  it('should track token usage', async () => {
    await manager.load('test-project');
    await manager.addTokenUsage('code-migrator', 4, 5000);
    await manager.addTokenUsage('code-migrator', 4, 3000);
    await manager.addTokenUsage('parity-verifier', 4, 2000);
    
    const state = manager.getState();
    expect(state.tokenUsage.total).toBe(10000);
    expect(state.tokenUsage.byAgent['code-migrator']).toBe(8000);
    expect(state.tokenUsage.byPhase[4]).toBe(10000);
  });

  it('should detect budget exceeded', async () => {
    await manager.load('test-project');
    await manager.addTokenUsage('agent', 1, 10000);
    
    expect(manager.isBudgetExceeded(5000)).toBe(true);
    expect(manager.isBudgetExceeded(20000)).toBe(false);
    expect(manager.isBudgetExceeded(undefined)).toBe(false);
  });

  it('should return correct resume point', async () => {
    await manager.load('test-project');
    await manager.completePhase(1, '/out/1');
    await manager.completePhase(2, '/out/2');
    await manager.setCurrentTask('task-005');
    
    const resume = manager.getResumePoint();
    expect(resume.phase).toBe(3);
    expect(resume.taskId).toBe('task-005');
  });

  it('should persist terminal exhaustion metadata', async () => {
    await manager.load('test-project');
    await manager.setTerminalExhaustion({
      reasonCode: 'task-retries-exhausted',
      taskId: 'task-001',
      check: 'code-migrator',
      summary: 'code-migrator failed after max retries',
    });

    const state = manager.getState();
    expect(state.terminalExhaustion?.reasonCode).toBe('task-retries-exhausted');
    expect(state.terminalExhaustion?.taskId).toBe('task-001');

    // Verify the data was written to disk (read raw JSON, not via CheckpointManager
    // which clears terminalExhaustion via prepareForResume on reload).
    const raw = await readJson<Record<string, unknown>>(join(tempDir, 'state', 'checkpoint.json'));
    const te = raw.terminalExhaustion as Record<string, unknown>;
    expect(te.reasonCode).toBe('task-retries-exhausted');
    expect(te.check).toBe('code-migrator');
  });

  it('should default cumulativeDurationMs to 0 when field is absent in stored checkpoint (backward compat)', async () => {
    // Write a checkpoint without cumulativeDurationMs (simulating an old checkpoint)
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 2,
      currentTask: null,
      completedPhases: [1],
      completedTasks: ['task-001'],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      // cumulativeDurationMs intentionally omitted
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.cumulativeDurationMs).toBe(0);
    expect(loaded.terminalExhaustion).toBeUndefined();
  });

  it('should initialize cumulativeDurationMs to 0 on fresh state and preserve on reload', async () => {
    const state = await manager.load('test-project');
    expect(state.cumulativeDurationMs).toBe(0);

    // Simulate accumulation then reload
    state.cumulativeDurationMs = 5000;
    await manager.save(state);

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.cumulativeDurationMs).toBe(5000);
  });

  it('should append durationMs to completedTaskDurationsMs when provided', async () => {
    await manager.load('test-project');
    await manager.completeTask('task-001', 1234);
    await manager.completeTask('task-002', 5678);

    const state = manager.getState();
    expect(state.completedTaskDurationsMs).toEqual([1234, 5678]);
  });

  it('should not append to completedTaskDurationsMs when durationMs is omitted', async () => {
    await manager.load('test-project');
    await manager.completeTask('task-001');

    const state = manager.getState();
    expect(state.completedTaskDurationsMs).toEqual([]);
  });

  it('should round-trip task duration through save and reload', async () => {
    await manager.load('test-project');
    await manager.completeTask('task-001', 9999);

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.completedTaskDurationsMs).toEqual([9999]);
  });

  it('should default completedTaskDurationsMs to [] when field is absent in stored checkpoint (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 2,
      currentTask: null,
      completedPhases: [1],
      completedTasks: ['task-001'],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      // completedTaskDurationsMs intentionally omitted
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.completedTaskDurationsMs).toEqual([]);
  });

  it('should write checkpoint atomically', async () => {    await manager.load('test-project');
    
    // Verify checkpoint file exists
    const exists = await fileExists(join(tempDir, 'state', 'checkpoint.json'));
    expect(exists).toBe(true);
    
    // Verify it's valid JSON
    const data = await readJson(join(tempDir, 'state', 'checkpoint.json'));
    expect(data).toBeDefined();
  });

  it('should remove task from blocked when completed', async () => {
    await manager.load('test-project');
    await manager.blockTask('task-001');
    await manager.completeTask('task-001');

    const state = manager.getState();
    expect(state.blockedTasks).not.toContain('task-001');
    expect(state.completedTasks).toContain('task-001');
  });

  it('should remove task from both failed and blocked when completed', async () => {
    await manager.load('test-project');
    await manager.failTask('task-001', 'some error', 1, false);
    await manager.blockTask('task-001');
    await manager.completeTask('task-001');

    const state = manager.getState();
    expect(state.failedTasks).toHaveLength(0);
    expect(state.blockedTasks).not.toContain('task-001');
    expect(state.completedTasks).toContain('task-001');
  });

  it('should not affect other blocked tasks when completing one', async () => {
    await manager.load('test-project');
    await manager.blockTask('task-001');
    await manager.blockTask('task-002');
    await manager.completeTask('task-001');

    const state = manager.getState();
    expect(state.blockedTasks).not.toContain('task-001');
    expect(state.blockedTasks).toContain('task-002');
    expect(state.completedTasks).toContain('task-001');
  });

  it('should handle completing a task that was never blocked', async () => {
    await manager.load('test-project');
    await manager.completeTask('task-001');

    const state = manager.getState();
    expect(state.blockedTasks).toHaveLength(0);
    expect(state.completedTasks).toContain('task-001');
  });

  // ─── metricsCount ─────────────────────────────────────────────────

  it('should initialize metricsCount to 0 on fresh state', async () => {
    const state = await manager.load('test-project');
    expect(state.metricsCount).toBe(0);
  });

  it('should preserve metricsCount on reload', async () => {
    const state = await manager.load('test-project');
    state.metricsCount = 42;
    await manager.save(state);

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.metricsCount).toBe(42);
  });

  it('should default metricsCount to 0 when field is absent in stored checkpoint (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 2,
      currentTask: null,
      completedPhases: [1],
      completedTasks: ['task-001'],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      // metricsCount intentionally omitted
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.metricsCount).toBe(0);
  });

  it('should default phase cursors when loading legacy checkpoint without phaseCursors (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 4,
      currentTask: 'task-001',
      completedPhases: [1, 2, 3],
      completedTasks: [],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.phaseCursors?.['4']?.tasks).toEqual({});
    expect(loaded.phaseCursors?.['5']?.iteration).toBe(0);
    expect(loaded.phaseCursors?.['6']?.completedAgents).toEqual([]);
    expect(loaded.phaseCursors?.['6']?.completedSuites).toEqual([]);
    expect(loaded.phaseCursors?.['7']?.issueIndex).toBe(0);
  });

  it('should default completedSuites to [] when loading legacy Phase4Cursor without it (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 6,
      currentTask: null,
      completedPhases: [1, 2, 3, 4, 5],
      completedTasks: [],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
      phaseCursors: {
        '6': { completedAgents: ['e2e-test-crafter'] },
      },
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.phaseCursors?.['6']?.completedAgents).toEqual(['e2e-test-crafter']);
    expect(loaded.phaseCursors?.['6']?.completedSuites).toEqual([]);
  });

  it('should ignore existing checkpoint state on fresh load', async () => {
    const initial = await manager.load('test-project');
    initial.currentPhase = 6;
    initial.completedTasks = ['task-001'];
    await manager.save(initial);

    const fresh = await manager.load('test-project', { fresh: true });
    expect(fresh.currentPhase).toBe(0);
    expect(fresh.completedTasks).toEqual([]);
    expect(fresh.phaseCursors).toEqual({});
  });

  // ─── token persistence & resume merge ─────────────────────────────

  it('should persist token usage data across save and reload', async () => {
    const state = await manager.load('test-project');
    state.tokenUsage = {
      total: 15000,
      byPhase: { 1: 5000, 2: 10000 },
      byAgent: { 'code-migrator': 12000, 'parity-verifier': 3000 },
    };
    await manager.save(state);

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.tokenUsage.total).toBe(15000);
    expect(reloaded.tokenUsage.byPhase[1]).toBe(5000);
    expect(reloaded.tokenUsage.byPhase[2]).toBe(10000);
    expect(reloaded.tokenUsage.byAgent['code-migrator']).toBe(12000);
    expect(reloaded.tokenUsage.byAgent['parity-verifier']).toBe(3000);
  });

  it('should round-trip TokenTracker data through checkpoint save and reload', async () => {
    const { TokenTracker } = await import('../../src/budget/token-tracker.js');

    // Build tracker state
    const tracker = new TokenTracker();
    tracker.record('agent-a', 1, 1000);
    tracker.record('agent-b', 2, 2000);
    tracker.record('agent-a', 2, 500);

    // Save to checkpoint
    const state = await manager.load('test-project');
    state.tokenUsage = tracker.toCheckpointData();
    await manager.save(state);

    // Reload and restore tracker
    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');

    const tracker2 = new TokenTracker();
    tracker2.loadFromCheckpoint(reloaded.tokenUsage);

    const data = tracker2.toCheckpointData();
    expect(data.total).toBe(3500);
    expect(data.byAgent['agent-a']).toBe(1500);
    expect(data.byAgent['agent-b']).toBe(2000);
    expect(data.byPhase[1]).toBe(1000);
    expect(data.byPhase[2]).toBe(2500);
  });

  // ─── phase0Fingerprint ───────────────────────────────────────────

  it('should initialize phase0Fingerprint to undefined on fresh state', async () => {
    const state = await manager.load('test-project');
    expect(state.phase0Fingerprint).toBeUndefined();
  });

  it('should preserve phase0Fingerprint on reload', async () => {
    const state = await manager.load('test-project');
    state.phase0Fingerprint = 'abc123';
    await manager.save(state);

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.phase0Fingerprint).toBe('abc123');
  });

  it('should default phase0Fingerprint to undefined when field is absent in stored checkpoint (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 2,
      currentTask: null,
      completedPhases: [1],
      completedTasks: ['task-001'],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
      // phase0Fingerprint intentionally omitted
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.phase0Fingerprint).toBeUndefined();
  });

  it('should initialize adjudication waiver and event lists on fresh state', async () => {
    const state = await manager.load('test-project');
    expect(state.adjudicationWaivers).toEqual([]);
    expect(state.adjudicationEvents).toEqual([]);
  });

  it('should persist adjudication waiver and event records across reload', async () => {
    await manager.load('test-project');
    await manager.recordAdjudicationWaiver({
      issueFingerprint: 'fp-123',
      decision: 'false_positive',
      scope: 'task',
      expiresAt: '2099-01-01T00:00:00.000Z',
      taskId: 'task-001',
    });
    await manager.appendAdjudicationEvent({
      decision: 'false_positive',
      issueFingerprint: 'fp-123',
      scope: 'task',
      expiresAt: '2099-01-01T00:00:00.000Z',
      taskId: 'task-001',
      rationale: 'Known test harness mismatch',
      confidence: 'high',
      evidence: ['parity diff isolated to generated timestamps'],
    });

    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.adjudicationWaivers).toHaveLength(1);
    expect(reloaded.adjudicationWaivers?.[0]?.issueFingerprint).toBe('fp-123');
    expect(reloaded.adjudicationWaivers?.[0]?.scope).toBe('task');
    expect(reloaded.adjudicationWaivers?.[0]?.expiresAt).toBe('2099-01-01T00:00:00.000Z');
    expect(reloaded.adjudicationEvents).toHaveLength(1);
    expect(reloaded.adjudicationEvents?.[0]?.decision).toBe('false_positive');
    expect(reloaded.adjudicationEvents?.[0]?.evidence).toEqual(['parity diff isolated to generated timestamps']);
  });

  it('should assign createdAt timestamps when adjudication records omit them', async () => {
    await manager.load('test-project');
    await manager.recordAdjudicationWaiver({
      issueFingerprint: 'fp-no-created-at',
      decision: 'false_positive',
    });
    await manager.appendAdjudicationEvent({
      decision: 'inconclusive',
    });

    const state = manager.getState();
    expect(state.adjudicationWaivers?.[0]?.createdAt).toBeDefined();
    expect(new Date(state.adjudicationWaivers?.[0]?.createdAt ?? '').toString()).not.toBe('Invalid Date');
    expect(state.adjudicationEvents?.[0]?.createdAt).toBeDefined();
    expect(new Date(state.adjudicationEvents?.[0]?.createdAt ?? '').toString()).not.toBe('Invalid Date');
  });

  it('should default adjudication fields for old checkpoints (backward compat)', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const oldState = {
      projectName: 'old-project',
      version: 1,
      currentPhase: 2,
      currentTask: null,
      completedPhases: [1],
      completedTasks: ['task-001'],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 1,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
      // adjudicationWaivers/adjudicationEvents intentionally omitted
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), oldState);

    const manager3 = new CheckpointManager(tempDir, logger);
    const loaded = await manager3.load('old-project');
    expect(loaded.adjudicationWaivers).toEqual([]);
    expect(loaded.adjudicationEvents).toEqual([]);
  });

  // ─── resetFromPhase ─────────────────────────────────────────────

  /** Stub nodeIdToPhase mapper for tests */
  const testNodeIdToPhase = (id: string): number => {
    const map: Record<string, number> = {
      'kb-index': 0,
      'task-graph-construction': 1,
      'kb-construction': 2,
      'budget-check-2': 2,
      'migration-planning': 3,
      'budget-check-3': 3,
      'iterative-migration': 4,
      'phase-4-teardown': 4,
      'budget-check-4': 4,
      'final-parity-loop': 5,
      'final-parity-iteration': 5,
      'e2e-test-plan': 6,
      'finalization': 6,
      'e2e-suite-writers': 6,
      'documentation-writer': 6,
      'idiomatic-refactor-gate': 7,
      'idiomatic-refactor-pipeline': 7,
      'completion': 8,
    };
    return map[id] ?? -1;
  };

  it('resetFromPhase should clear phases >= N and preserve earlier', async () => {
    const state = await manager.load('test-project');
    // Simulate phases 0-5 completed
    for (let p = 0; p <= 5; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    await manager.completeTask('task-001', 1000);
    await manager.completeTask('task-002', 2000);
    state.phase3aComplete = true;
    state.scaffoldComplete = true;
    await manager.save(state);

    await manager.resetFromPhase(4, testNodeIdToPhase);

    const reset = manager.getState();
    expect(reset.currentPhase).toBe(4);
    expect(reset.completedPhases).toEqual([0, 1, 2, 3]);
    expect(reset.currentTask).toBeNull();
    expect(reset.completedTasks).toEqual([]);
    expect(reset.failedTasks).toEqual([]);
    expect(reset.blockedTasks).toEqual([]);
    expect(reset.completedTaskDurationsMs).toEqual([]);
    // Phase 3 state preserved since fromPhase=4
    expect(reset.phase3aComplete).toBe(true);
    expect(reset.scaffoldComplete).toBe(true);
    // Phase outputs for 4+ cleared
    expect(reset.phaseOutputs[3]).toBe('/out/3');
    expect(reset.phaseOutputs[4]).toBeUndefined();
    expect(reset.phaseOutputs[5]).toBeUndefined();
  });

  it('resetFromPhase(0) should clear everything like a fresh start', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 3; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.phase0Fingerprint = 'abc123';
    state.phase3aComplete = true;
    await manager.save(state);

    await manager.resetFromPhase(0, testNodeIdToPhase);

    const reset = manager.getState();
    expect(reset.currentPhase).toBe(0);
    expect(reset.completedPhases).toEqual([]);
    expect(reset.phase0Fingerprint).toBeUndefined();
    expect(reset.phase3aComplete).toBe(false);
    expect(reset.scaffoldComplete).toBe(false);
  });

  it('resetFromPhase should throw if prerequisite phases are missing', async () => {
    await manager.load('test-project');
    await manager.completePhase(0, '/out/0');
    // Phase 1 not completed — trying to start from phase 3 should fail

    await expect(manager.resetFromPhase(3, testNodeIdToPhase)).rejects.toThrow(
      /Cannot --from-phase 3.*prerequisite phase\(s\) 1, 2/,
    );
  });

  it('resetFromPhase should filter flow checkpoint completedExecutionIds', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 5; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    // Simulate a flow checkpoint with namespaced completed execution IDs
    state.__flowCheckpoint = {
      flowId: 'aamf-migration',
      status: 'completed',
      startedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      completedExecutionIds: [
        'aamf-migration/kb-index',              // phase 0
        'aamf-migration/task-graph-construction', // phase 1
        'aamf-migration/kb-construction',       // phase 2
        'aamf-migration/budget-check-2',        // phase 2
        'aamf-migration/migration-planning',    // phase 3
        'aamf-migration/budget-check-3',        // phase 3
        'aamf-migration/iterative-migration',   // phase 4
        'aamf-migration/phase-4-teardown',       // phase 4
        'aamf-migration/budget-check-4',        // phase 4
        'aamf-migration/final-parity-loop',     // phase 5
      ],
      outputs: {},
      executionOutputs: {},
    };
    await manager.save(state);

    await manager.resetFromPhase(4, testNodeIdToPhase);

    const reset = manager.getState();
    const fc = reset.__flowCheckpoint as { completedExecutionIds: string[] };
    // Should keep phases 0-3 execution IDs, remove 4+
    expect(fc.completedExecutionIds).toEqual([
      'aamf-migration/kb-index',
      'aamf-migration/task-graph-construction',
      'aamf-migration/kb-construction',
      'aamf-migration/budget-check-2',
      'aamf-migration/migration-planning',
      'aamf-migration/budget-check-3',
    ]);
  });

  it('resetFromPhase should clear phase4FlowCheckpoint when resetting from phase <= 4', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 4; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.__phase4FlowCheckpoint = { flowId: 'phase4', status: 'completed' };
    await manager.save(state);

    await manager.resetFromPhase(4, testNodeIdToPhase);

    const reset = manager.getState();
    expect(reset.__phase4FlowCheckpoint).toBeUndefined();
  });

  it('resetFromPhase should clear phase-specific cursors', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 6; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.phaseCursors = {
      '4': { tasks: { 'task-1': { completedSubsteps: ['migrate', 'verify'] } } },
      '5': { iteration: 2, fixIndex: 3 },
      '6': { completedAgents: ['e2e-test-crafter'], completedSuites: ['suite-a'] },
      '7': { iteration: 1, issueIndex: 5 },
    };
    await manager.save(state);

    await manager.resetFromPhase(5, testNodeIdToPhase);

    const reset = manager.getState();
    // Phase 4 cursor preserved (fromPhase=5 > 4)
    expect(reset.phaseCursors?.['4']?.tasks['task-1']).toBeDefined();
    // Phase 5+ cursors reset
    expect(reset.phaseCursors?.['5']).toEqual({ iteration: 0, fixIndex: 0 });
    expect(reset.phaseCursors?.['6']).toEqual({ completedAgents: [], completedSuites: [] });
    expect(reset.phaseCursors?.['7']).toEqual({ iteration: 0, issueIndex: 0 });
  });

  it('resetFromPhase should persist the reset to disk', async () => {
    await manager.load('test-project');
    for (let p = 0; p <= 3; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }

    await manager.resetFromPhase(2, testNodeIdToPhase);

    // Reload from disk
    const manager2 = new CheckpointManager(tempDir, logger);
    const reloaded = await manager2.load('test-project');
    expect(reloaded.currentPhase).toBe(2);
    expect(reloaded.completedPhases).toContain(0);
    expect(reloaded.completedPhases).toContain(1);
    expect(reloaded.completedPhases).not.toContain(2);
    expect(reloaded.completedPhases).not.toContain(3);
  });

  it('resetFromPhase should clear adjudication state when resetting from phase <= 4', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 4; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    await manager.recordAdjudicationWaiver({
      issueFingerprint: 'fp-1',
      decision: 'false_positive',
    });
    await manager.appendAdjudicationEvent({
      decision: 'false_positive',
      issueFingerprint: 'fp-1',
    });

    await manager.resetFromPhase(4, testNodeIdToPhase);

    const reset = manager.getState();
    expect(reset.adjudicationWaivers).toEqual([]);
    expect(reset.adjudicationEvents).toEqual([]);
    expect(reset.terminalExhaustion).toBeUndefined();
  });

  it('resetFromPhase should reset flow checkpoint status and error', async () => {
    const state = await manager.load('test-project');
    for (let p = 0; p <= 5; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.__flowCheckpoint = {
      flowId: 'aamf-migration',
      status: 'failed',
      startedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      completedExecutionIds: [
        'aamf-migration/kb-index',
        'aamf-migration/task-graph-construction',
        'aamf-migration/iterative-migration',
        'aamf-migration/final-parity-loop',
      ],
      outputs: {},
      executionOutputs: {},
      error: 'Phase 5 terminal exhaustion',
    };
    await manager.save(state);

    await manager.resetFromPhase(4, testNodeIdToPhase);

    const reset = manager.getState();
    const fc = reset.__flowCheckpoint as Record<string, unknown>;
    expect(fc.status).toBe('running');
    expect(fc.error).toBeUndefined();
    // Phase 4+ execution IDs removed, phases 0-3 kept
    expect(fc.completedExecutionIds).toEqual([
      'aamf-migration/kb-index',
      'aamf-migration/task-graph-construction',
    ]);
  });

  it('fresh start with reuseKb should preserve KB phases and reset everything else', async () => {
    // Set up a prior run with phases 0-4 completed
    const state = await manager.load('test-project');
    for (let p = 0; p <= 4; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.phase0Fingerprint = 'abc123';
    state.scaffoldComplete = true;
    state.completedTasks = [{ taskId: 'task-1', attempts: 1, lastError: '', recoveryAttempted: false }];
    state.__flowCheckpoint = {
      flowId: 'aamf-migration',
      status: 'completed',
      completedExecutionIds: [
        'aamf-migration/kb-index',
        'aamf-migration/task-graph-construction',
        'aamf-migration/kb-construction',
        'aamf-migration/budget-check-2',
        'aamf-migration/migration-planning',
        'aamf-migration/budget-check-3',
      ],
      startedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await manager.save(state);

    // Fresh start with reuseKb
    const manager2 = new CheckpointManager(tempDir, logger);
    const reused = await manager2.load('test-project', { fresh: true, reuseKb: true });

    // KB phases preserved
    expect(reused.completedPhases).toContain(0);
    expect(reused.completedPhases).toContain(1);
    expect(reused.completedPhases).toContain(2);
    expect(reused.completedPhases).not.toContain(3);
    expect(reused.completedPhases).not.toContain(4);
    expect(reused.currentPhase).toBe(3);
    expect(reused.phase0Fingerprint).toBe('abc123');
    expect(reused.scaffoldComplete).toBe(true);

    // Phase outputs preserved for KB phases only
    expect(reused.phaseOutputs[0]).toBe('/out/0');
    expect(reused.phaseOutputs[1]).toBe('/out/1');
    expect(reused.phaseOutputs[2]).toBe('/out/2');
    expect(reused.phaseOutputs[3]).toBeUndefined();
    expect(reused.phaseOutputs[4]).toBeUndefined();

    // Migration state reset
    expect(reused.completedTasks).toEqual([]);
    expect(reused.failedTasks).toEqual([]);
    expect(reused.resumeCount).toBe(0);

    // Flow checkpoint filtered to KB steps only
    const fc = reused.__flowCheckpoint as Record<string, unknown>;
    const completedIds = fc.completedExecutionIds as string[];
    expect(completedIds).toContain('aamf-migration/kb-index');
    expect(completedIds).toContain('aamf-migration/task-graph-construction');
    expect(completedIds).toContain('aamf-migration/kb-construction');
    expect(completedIds).toContain('aamf-migration/budget-check-2');
    expect(completedIds).not.toContain('aamf-migration/migration-planning');
    expect(completedIds).not.toContain('aamf-migration/budget-check-3');
  });

  it('fresh start with reuseKb but no prior checkpoint should start from scratch', async () => {
    const state = await manager.load('test-project', { fresh: true, reuseKb: true });
    expect(state.completedPhases).toEqual([]);
    expect(state.currentPhase).toBe(0);
    expect(state.phase0Fingerprint).toBeUndefined();
  });

  it('fresh start without reuseKb should ignore prior state entirely', async () => {
    // Set up a prior run
    const state = await manager.load('test-project');
    for (let p = 0; p <= 2; p++) {
      await manager.completePhase(p, `/out/${p}`);
    }
    state.phase0Fingerprint = 'abc123';
    await manager.save(state);

    // Fresh start without reuseKb
    const manager2 = new CheckpointManager(tempDir, logger);
    const fresh = await manager2.load('test-project', { fresh: true });
    expect(fresh.completedPhases).toEqual([]);
    expect(fresh.currentPhase).toBe(0);
    expect(fresh.phase0Fingerprint).toBeUndefined();
  });

  // ─── resume preparation (prepareForResume) ────────────────────────

  it('should clear terminalExhaustion on resume', async () => {
    await manager.load('test-project');
    await manager.setTerminalExhaustion({
      reasonCode: 'parity-non-minor-exhausted',
      taskId: 'task-133-0',
      check: 'parity-verifier',
      summary: 'Parity still has non-minor issues after 7 attempt(s)',
    });
    const state = manager.getState();
    expect(state.terminalExhaustion).toBeDefined();

    // Resume: reload without fresh flag
    const manager2 = new CheckpointManager(tempDir, logger);
    const resumed = await manager2.load('test-project');
    expect(resumed.terminalExhaustion).toBeUndefined();
  });

  it('should reset failedTasks on resume so tasks get fresh retry budgets', async () => {
    await manager.load('test-project');
    await manager.failTask('task-197-0', 'Exit code: null', 3, false);
    await manager.failTask('task-133-0', 'parity exhaustion', 7, true);
    expect(manager.getState().failedTasks).toHaveLength(2);

    const manager2 = new CheckpointManager(tempDir, logger);
    const resumed = await manager2.load('test-project');
    expect(resumed.failedTasks).toEqual([]);
  });

  it('should reset flow checkpoint status from failed to running on resume', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const checkpoint = {
      projectName: 'test-flow-resume',
      version: 1,
      currentPhase: 4,
      currentTask: null,
      completedPhases: [0, 1, 2, 3],
      completedTasks: ['task-ok-0'],
      failedTasks: [{ taskId: 'task-bad-0', attempts: 7, lastError: 'parity exhausted', recoveryAttempted: true }],
      blockedTasks: ['task-blocked-0'],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 0,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
      __flowCheckpoint: {
        flowId: 'aamf-migration',
        status: 'failed',
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        completedExecutionIds: ['aamf-migration/kb-index', 'aamf-migration/task-graph-construction'],
        outputs: {},
        executionOutputs: {},
        error: 'Phase 4 terminal exhaustion',
      },
      __phase4FlowCheckpoint: {
        flowId: 'phase-4-sync-epoch',
        status: 'failed',
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        completedExecutionIds: [
          'phase-4-sync-epoch/epoch-0-start',
          // Completed task — all substeps present
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/migrate',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/commit',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/parity',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/parity-gate',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/minor-repass',
          // Failed task — only migrate/commit completed before parity-gate blew up
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/migrate',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/commit',
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/parity',
          // Blocked task
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-blocked-0/task-blocked-0/migrate',
        ],
        outputs: {
          'task-ok-0/migrate': { durationMs: 100 },
          'task-bad-0/migrate': { durationMs: 200 },
        },
        executionOutputs: {
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/migrate': { durationMs: 100 },
          'phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/migrate': { durationMs: 200 },
        },
        error: 'terminal exhaustion',
      },
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), checkpoint);

    const manager3 = new CheckpointManager(tempDir, logger);
    const resumed = await manager3.load('test-flow-resume');

    // Status should be reset to 'running', errors cleared
    const fc = resumed.__flowCheckpoint as Record<string, unknown>;
    expect(fc.status).toBe('running');
    expect(fc.error).toBeUndefined();

    const p4fc = resumed.__phase4FlowCheckpoint as Record<string, unknown>;
    expect(p4fc.status).toBe('running');
    expect(p4fc.error).toBeUndefined();

    // Top-level completedExecutionIds preserved
    expect(fc.completedExecutionIds).toEqual(['aamf-migration/kb-index', 'aamf-migration/task-graph-construction']);

    // Phase 4: only completed task substeps + non-task entries kept
    const p4Ids = p4fc.completedExecutionIds as string[];
    expect(p4Ids).toContain('phase-4-sync-epoch/epoch-0-start');
    expect(p4Ids).toContain('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/migrate');
    expect(p4Ids).toContain('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/parity-gate');
    // Failed/blocked task entries removed
    expect(p4Ids).not.toContain('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/migrate');
    expect(p4Ids).not.toContain('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-blocked-0/task-blocked-0/migrate');

    // executionOutputs for non-completed tasks also cleaned
    const p4execOutputs = p4fc.executionOutputs as Record<string, unknown>;
    expect(p4execOutputs).toHaveProperty('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-ok-0/task-ok-0/migrate');
    expect(p4execOutputs).not.toHaveProperty('phase-4-sync-epoch/epoch-0-tasks-batch-0/task-bad-0/task-bad-0/migrate');

    // failedTasks and blockedTasks cleared
    expect(resumed.failedTasks).toEqual([]);
    expect(resumed.blockedTasks).toEqual([]);
  });

  it('should not alter flow checkpoint when status is not failed', async () => {
    const { writeJson } = await import('../../src/util/fs.js');
    const checkpoint = {
      projectName: 'test-running-resume',
      version: 1,
      currentPhase: 4,
      currentTask: null,
      completedPhases: [0, 1, 2, 3],
      completedTasks: [],
      failedTasks: [],
      blockedTasks: [],
      phaseOutputs: {},
      tokenUsage: { total: 0, byPhase: {}, byAgent: {} },
      startedAt: new Date().toISOString(),
      lastCheckpoint: new Date().toISOString(),
      resumeCount: 0,
      cumulativeDurationMs: 0,
      completedTaskDurationsMs: [],
      metricsCount: 0,
      __flowCheckpoint: {
        flowId: 'aamf-migration',
        status: 'completed',
        completedExecutionIds: ['aamf-migration/kb-index'],
        outputs: {},
        executionOutputs: {},
      },
    };
    await ensureDir(join(tempDir, 'state'));
    await writeJson(join(tempDir, 'state', 'checkpoint.json'), checkpoint);

    const manager3 = new CheckpointManager(tempDir, logger);
    const resumed = await manager3.load('test-running-resume');
    const fc = resumed.__flowCheckpoint as Record<string, unknown>;
    expect(fc.status).toBe('completed');
  });
});
