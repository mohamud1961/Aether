import { describe, it, expect } from 'vitest';
import { MigrationConfigSchema } from '../../src/config/schema.js';

describe('MigrationConfigSchema', () => {
  const validConfig = {
    projectName: 'test-project',
    source: { path: './src', language: 'python' },
    target: { language: 'typescript', outputPath: './out' },
  };

  it('should accept minimal valid config', () => {
    const result = MigrationConfigSchema.safeParse(validConfig);
    expect(result.success).toBe(true);
  });

  it('should apply defaults', () => {
    const result = MigrationConfigSchema.parse(validConfig);
    expect(result.options.maxParallelAgents).toBe(3);
    expect(result.options.maxRetriesPerTask).toBe(3);
    expect(result.options.dryRun).toBe(false);
    expect(result.options.buildConcurrency).toBe(1);
    expect(result.options.executionMode).toBe('per-task');
    expect(result.options.waveControl?.maxConvergenceIterations).toBe(3);
    expect(result.options.continueOnBlocked).toBe(true);
    expect(result.options.maxBlockedTasks).toBe(1);
    expect(result.options.qualityPolicy).toBe('strict');
    expect(result.options.maxInfraRetries).toBe(3);
    expect(result.options.git?.enabled).toBe(true);
    expect(result.options.git?.autoInit).toBe(true);
    expect(result.options.git?.commitByAgent).toBe(true);
    expect(result.options.git?.commitPerTask).toBe(true);
    expect(result.options.git?.allowEmptyTaskCommits).toBe(true);
    expect(result.models.default).toBeUndefined();
    expect(result.models.failureRecovery).toBeUndefined();
    expect(result.agentBackend.cliCommand).toBe('copilot');
    expect(result.agentBackend.timeout).toBe(300000);
    expect(result.agentBackend.failureRecoveryModel).toBeUndefined();
  });

  it('should accept git automation overrides', () => {
    const result = MigrationConfigSchema.parse({
      ...validConfig,
      options: {
        git: {
          enabled: false,
          autoInit: false,
          commitByAgent: false,
          commitPerTask: true,
          authorName: 'Custom Bot',
          authorEmail: 'custom@example.com',
        },
      },
    });

    expect(result.options.git?.enabled).toBe(false);
    expect(result.options.git?.autoInit).toBe(false);
    expect(result.options.git?.commitByAgent).toBe(false);
    expect(result.options.git?.commitPerTask).toBe(true);
    expect(result.options.git?.authorName).toBe('Custom Bot');
    expect(result.options.git?.authorEmail).toBe('custom@example.com');
  });

  it('should default allowEmptyTaskCommits to true', () => {
    const result = MigrationConfigSchema.parse(validConfig);
    expect(result.options.git?.allowEmptyTaskCommits).toBe(true);
  });

  it('should accept allowEmptyTaskCommits set to false', () => {
    const result = MigrationConfigSchema.parse({
      ...validConfig,
      options: {
        git: {
          allowEmptyTaskCommits: false,
        },
      },
    });
    expect(result.options.git?.allowEmptyTaskCommits).toBe(false);
  });

  it('should default git authorName and authorEmail', () => {
    const result = MigrationConfigSchema.parse(validConfig);
    expect(result.options.git?.authorName).toBe('AAMF Migration Bot');
    expect(result.options.git?.authorEmail).toBe('aamf@local.invalid');
  });

  it('should reject invalid project name', () => {
    const result = MigrationConfigSchema.safeParse({
      ...validConfig,
      projectName: 'Invalid Name!',
    });
    expect(result.success).toBe(false);
  });

  it('should reject empty project name', () => {
    const result = MigrationConfigSchema.safeParse({
      ...validConfig,
      projectName: '',
    });
    expect(result.success).toBe(false);
  });

  it('should accept large maxParallelAgents values', () => {
    const result = MigrationConfigSchema.safeParse({
      ...validConfig,
      options: { maxParallelAgents: 20 },
    });
    expect(result.success).toBe(true);
  });

  it('should accept full config', () => {
    const full = {
      ...validConfig,
      source: { ...validConfig.source, entryPoints: ['main.py'], excludePatterns: ['venv'] },
      target: { ...validConfig.target, framework: 'express' },
      options: { maxParallelAgents: 5, tokenBudget: 1000000 },
      models: { default: 'gpt-4o' },
      agentBackend: { runtime: 'copilot', cliCommand: 'copilot', agentDir: '.github/agents', timeout: 300000 },
    };
    const result = MigrationConfigSchema.safeParse(full);
    expect(result.success).toBe(true);
  });

  it('should accept optional formatCommand and lintCommand', () => {
    const result = MigrationConfigSchema.parse({
      ...validConfig,
      target: {
        ...validConfig.target,
        formatCommand: 'cargo fmt --all',
        lintCommand: 'cargo clippy -- -D warnings',
      },
    });
    expect(result.target.formatCommand).toBe('cargo fmt --all');
    expect(result.target.lintCommand).toBe('cargo clippy -- -D warnings');
  });

  it('should default formatCommand and lintCommand to undefined', () => {
    const result = MigrationConfigSchema.parse(validConfig);
    expect(result.target.formatCommand).toBeUndefined();
    expect(result.target.lintCommand).toBeUndefined();
  });

  describe('Additional Validation', () => {
    it('should accept models.failureRecovery override', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        models: { failureRecovery: 'gpt-4.1' },
      });
      expect(result.models.failureRecovery).toBe('gpt-4.1');
    });

    it('should continue accepting agentBackend.failureRecoveryModel as a compatibility alias', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        agentBackend: { runtime: 'claude-code', failureRecoveryModel: 'claude-sonnet-4.5' },
      });
      expect(result.agentBackend.failureRecoveryModel).toBe('claude-sonnet-4.5');
    });

    it('should reject maxRetriesPerTask above 10', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { maxRetriesPerTask: 11 },
      });
      expect(result.success).toBe(false);
    });

    it('should reject maxRetriesPerTask of 0', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { maxRetriesPerTask: 0 },
      });
      expect(result.success).toBe(false);
    });

    it('should reject maxParallelAgents of 0', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { maxParallelAgents: 0 },
      });
      expect(result.success).toBe(false);
    });

    it('should accept empty source.path (string validation only)', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        source: { path: '', language: 'python' },
      });
      expect(result.success).toBe(true);
    });

    it('should reject projectName with spaces', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        projectName: 'has space',
      });
      expect(result.success).toBe(false);
    });

    it('should reject projectName with uppercase', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        projectName: 'HasUppercase',
      });
      expect(result.success).toBe(false);
    });

    it('should reject projectName with underscores', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        projectName: 'has_underscore',
      });
      expect(result.success).toBe(false);
    });

    it('should strip unknown fields from parsed result', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        foo: 'bar',
      });
      expect(result.success).toBe(true);
      if (result.success) {
        expect((result.data as Record<string, unknown>)['foo']).toBeUndefined();
      }
    });

    it('should reject buildConcurrency above 10', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { buildConcurrency: 11 },
      });
      expect(result.success).toBe(false);
    });

    it('should accept buildConcurrency of 0 (unlimited)', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { buildConcurrency: 0 },
      });
      expect(result.success).toBe(true);
    });

    it('should reject negative buildConcurrency', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { buildConcurrency: -1 },
      });
      expect(result.success).toBe(false);
    });

    it('should accept continueOnBlocked as false', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        options: { continueOnBlocked: false },
      });
      expect(result.options.continueOnBlocked).toBe(false);
    });

    it('should accept maxBlockedTasks', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        options: { maxBlockedTasks: 5 },
      });
      expect(result.options.maxBlockedTasks).toBe(5);
    });

    it('should accept valid qualityPolicy values', () => {
      for (const qualityPolicy of ['strict', 'balanced', 'deferred-strict'] as const) {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { qualityPolicy },
        });
        expect(result.options.qualityPolicy).toBe(qualityPolicy);
      }
    });

    it('should reject invalid qualityPolicy values', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { qualityPolicy: 'lenient' },
      });
      expect(result.success).toBe(false);
    });

    it('should reject maxInfraRetries above 10', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { maxInfraRetries: 11 },
      });
      expect(result.success).toBe(false);
    });

    it('should accept phaseTimeouts mapping phase numbers to ms values', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        agentBackend: { phaseTimeouts: { 1: 60000, 3: 120000 } },
      });
      expect(result.agentBackend.phaseTimeouts).toEqual({ 1: 60000, 3: 120000 });
    });

    it('should leave phaseTimeouts undefined when omitted', () => {
      const result = MigrationConfigSchema.parse(validConfig);
      expect(result.agentBackend.phaseTimeouts).toBeUndefined();
    });

    it('should default keepArtifacts to false when omitted', () => {
      const result = MigrationConfigSchema.parse(validConfig);
      expect(result.options.keepArtifacts).toBe(false);
    });

    describe('idiomaticRefactor option', () => {
      it('should leave idiomaticRefactor undefined when omitted', () => {
        const result = MigrationConfigSchema.parse(validConfig);
        expect(result.options.idiomaticRefactor).toBeUndefined();
      });

      it('should default enabled to false and maxIterations to 2 when idiomaticRefactor is {}', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { idiomaticRefactor: {} },
        });
        expect(result.options.idiomaticRefactor?.enabled).toBe(false);
        expect(result.options.idiomaticRefactor?.maxIterations).toBe(2);
      });

      it('should accept idiomaticRefactor: { enabled: true, maxIterations: 3 }', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { idiomaticRefactor: { enabled: true, maxIterations: 3 } },
        });
        expect(result.options.idiomaticRefactor?.enabled).toBe(true);
        expect(result.options.idiomaticRefactor?.maxIterations).toBe(3);
      });

      it('should accept idiomaticRefactor.maxIterations of 0 (unlimited)', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { idiomaticRefactor: { enabled: true, maxIterations: 0 } },
        });
        expect(result.options.idiomaticRefactor?.maxIterations).toBe(0);
      });
    });

    it('should default agentBackend.runtime to copilot', () => {
      const result = MigrationConfigSchema.parse(validConfig);
      expect(result.agentBackend.runtime).toBe('copilot');
    });

    it('should accept agentBackend.runtime of claude-code', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        agentBackend: { runtime: 'claude-code' },
      });
      expect(result.agentBackend.runtime).toBe('claude-code');
    });

    it('should reject invalid agentBackend.runtime value', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        agentBackend: { runtime: 'openai' },
      });
      expect(result.success).toBe(false);
    });

    it('should apply agentBackend defaults for copilot runtime', () => {
      const result = MigrationConfigSchema.parse(validConfig);
      expect(result.agentBackend.runtime).toBe('copilot');
      expect(result.agentBackend.cliCommand).toBe('copilot');
      expect(result.agentBackend.agentDir).toBe('.github/agents');
      expect(result.agentBackend.timeout).toBe(300000);
      expect(result.models.default).toBeUndefined();
      expect(result.agentBackend.model).toBeUndefined();
      expect(result.agentBackend.phaseTimeouts).toBeUndefined();
    });

    it('should apply agentBackend defaults for claude-code runtime', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        agentBackend: { runtime: 'claude-code' },
      });
      expect(result.agentBackend.runtime).toBe('claude-code');
      expect(result.agentBackend.cliCommand).toBe('claude');
      expect(result.agentBackend.agentDir).toBe('.claude/agents');
      expect(result.agentBackend.timeout).toBe(300000);
    });

    it('should accept explicit agentBackend config', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        models: { default: 'claude-sonnet-4-5' },
        agentBackend: {
          runtime: 'claude-code',
          cliCommand: 'claude',
          agentDir: '.claude/agents',
          timeout: 600000,
          phaseTimeouts: { 4: 120000 },
        },
      });
      expect(result.models.default).toBe('claude-sonnet-4-5');
      expect(result.agentBackend.timeout).toBe(600000);
    });

    it('should accept executionMode of wave-barrier', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        options: { executionMode: 'wave-barrier' },
      });
      expect(result.options.executionMode).toBe('wave-barrier');
      expect(result.options.waveControl).toEqual({ maxConvergenceIterations: 3 });
    });

    it('should reject invalid executionMode', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { executionMode: 'serial-wave' },
      });
      expect(result.success).toBe(false);
    });

    it('should accept waveControl.maxConvergenceIterations of 0 (unlimited)', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { waveControl: { maxConvergenceIterations: 0 } },
      });
      expect(result.success).toBe(true);
    });

    it('should reject waveControl.maxConvergenceIterations less than 0', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        options: { waveControl: { maxConvergenceIterations: -1 } },
      });
      expect(result.success).toBe(false);
    });

    describe('models routing', () => {
      it('should leave models.routing undefined when omitted', () => {
        const result = MigrationConfigSchema.parse(validConfig);
        expect(result.models.routing).toBeUndefined();
      });

      it('should default enabled to false when models.routing is {}', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          models: { routing: {} },
        });
        expect(result.models.routing?.enabled).toBe(false);
      });

      it('should default thresholds and caps correctly', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          models: { routing: {} },
        });
        const mr = result.models.routing;
        expect(mr?.heavyThreshold).toBe(40);
        expect(mr?.criticalThreshold).toBe(70);
        expect(mr?.maxEscalatedTasks).toBe(0);
        expect(mr?.maxEscalationCostUsd).toBe(0);
        expect(mr?.escalateOnRetryAttempt).toBe(2);
      });

      it('should accept models.routing with enabled: true and heavy', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          models: { routing: { enabled: true, heavy: 'claude-opus-4.5' } },
        });
        expect(result.models.routing?.enabled).toBe(true);
        expect(result.models.routing?.heavy).toBe('claude-opus-4.5');
      });

      it('should accept criticalAgents as an array of strings', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          models: { routing: { criticalAgents: ['code-migrator', 'parity-verifier'] } },
        });
        expect(result.models.routing?.criticalAgents).toEqual(['code-migrator', 'parity-verifier']);
      });

      it('should accept criticalTaskPatterns as an array of strings', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          models: { routing: { criticalTaskPatterns: ['task-00*'] } },
        });
        expect(result.models.routing?.criticalTaskPatterns).toEqual(['task-00*']);
      });

      it('should continue accepting options.modelRouting as a compatibility alias', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { modelRouting: { enabled: true, heavyModel: 'claude-opus-4.5' } },
        });
        expect(result.options.modelRouting?.enabled).toBe(true);
        expect(result.options.modelRouting?.heavyModel).toBe('claude-opus-4.5');
      });

    });

    describe('kbIndex option', () => {
      it('should leave kbIndex undefined when omitted', () => {
        const result = MigrationConfigSchema.parse(validConfig);
        expect(result.options.kbIndex).toBeUndefined();
      });

      it('should default kbIndex logLevel to debug when kbIndex is {}', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { kbIndex: {} },
        });
        expect(result.options.kbIndex?.logLevel).toBe('debug');
      });

      it('should leave embeddings undefined when omitted from kbIndex', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { kbIndex: {} },
        });
        expect(result.options.kbIndex?.embeddings).toBeUndefined();
      });

      it('should default embeddings.enabled to false when embeddings is {}', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: { kbIndex: { embeddings: {} } },
        });
        expect(result.options.kbIndex?.embeddings?.enabled).toBe(false);
      });

      it('should accept embeddings with all fields', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: {
            kbIndex: {
              embeddings: { enabled: true, model: 'BAAI/bge-small-en-v1.5', pythonBin: '/usr/bin/python3.11' },
            },
          },
        });
        const emb = result.options.kbIndex?.embeddings;
        expect(emb?.enabled).toBe(true);
        expect(emb?.model).toBe('BAAI/bge-small-en-v1.5');
        expect(emb?.pythonBin).toBe('/usr/bin/python3.11');
      });

      it('should default model to Qwen3-Embedding-0.6B and pythonBin to python3', () => {
        const result = MigrationConfigSchema.parse({
          ...validConfig,
          options: {
            kbIndex: { embeddings: { enabled: true } },
          },
        });
        const emb = result.options.kbIndex?.embeddings;
        expect(emb?.model).toBe('Qwen/Qwen3-Embedding-0.6B');
        expect(emb?.pythonBin).toBe('python3');
      });
    });
  });

  describe('Guidance', () => {
    it('should accept guidance as an array of strings', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        guidance: ['Do not use wrapper crates', 'Write native Rust code'],
      });
      expect(result.guidance).toEqual(['Do not use wrapper crates', 'Write native Rust code']);
    });

    it('should default guidance to undefined when omitted', () => {
      const result = MigrationConfigSchema.parse(validConfig);
      expect(result.guidance).toBeUndefined();
    });

    it('should reject guidance with empty strings', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        guidance: ['valid', ''],
      });
      expect(result.success).toBe(false);
    });

    it('should accept an empty guidance array', () => {
      const result = MigrationConfigSchema.parse({
        ...validConfig,
        guidance: [],
      });
      expect(result.guidance).toEqual([]);
    });

    it('should reject guidance when not an array', () => {
      const result = MigrationConfigSchema.safeParse({
        ...validConfig,
        guidance: 'single string',
      });
      expect(result.success).toBe(false);
    });
  });
});
