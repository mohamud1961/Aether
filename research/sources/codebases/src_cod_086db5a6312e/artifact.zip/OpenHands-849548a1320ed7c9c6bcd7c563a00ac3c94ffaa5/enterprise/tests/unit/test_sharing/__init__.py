"""Tests for sharing package."""
