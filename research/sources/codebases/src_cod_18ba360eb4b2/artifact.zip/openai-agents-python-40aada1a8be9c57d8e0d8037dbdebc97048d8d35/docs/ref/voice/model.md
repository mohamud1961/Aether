# `Model`

::: agents.voice.model
