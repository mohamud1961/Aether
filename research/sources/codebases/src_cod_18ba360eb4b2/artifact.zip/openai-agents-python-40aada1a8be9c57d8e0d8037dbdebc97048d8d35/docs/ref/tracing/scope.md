# `Scope`

::: agents.tracing.scope
